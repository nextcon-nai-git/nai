"use client"

import * as React from "react"
import { Loader2, Database, ShieldCheck, Zap, TrendingUp, Building2, Briefcase, FileSearch, Gavel, Scale, FolderTree, Network } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useToast } from "@/hooks/use-toast"
import { useUser, useFirestore } from "@/firebase"
import { doc, writeBatch, collection } from "firebase/firestore"
import { REAL_COMPANIES, REAL_CONTRACTS, CETESB_OPERATION_CARDS, BRITANIA_EXPERTISES } from "@/lib/real-data"
import { seedCetesbOrganizationalStructure } from "@/actions/seed-cetesb-org"

/**
 * @fileOverview Hub de Onboarding e Carga de Dados NAI.
 * Implementa a automação de injeção de contratos enterprise para operation_cards.
 */

export default function UnifiedImportCenter() {
  const { toast } = useToast()
  const { user } = useUser()
  const db = useFirestore()
  const [uploadingCetesb, setUploadingCetesb] = React.useState(false)
  const [uploadingOrg, setUploadingOrg] = React.useState(false)
  const [uploadingGlobal, setUploadingGlobal] = React.useState(false)
  const [uploadingBritania, setUploadingBritania] = React.useState(false)

  const handleCetesbOnboarding = async () => {
    if (!user || !db) return
    setUploadingCetesb(true)
    
    try {
      const batch = writeBatch(db)
      const now = new Date().toISOString()
      const companyId = "CETESB_080680"

      const cetesb = REAL_COMPANIES.find(c => c.id === companyId)
      if (cetesb) {
        batch.set(doc(db, "companies", companyId), {
          ...cetesb,
          updatedAt: now,
          onboarding_status: "COMPLETED",
          onboarding_at: now,
          compliance_score: 100
        }, { merge: true })
      }

      // Injeta na nova coleção unificada operation_cards
      CETESB_OPERATION_CARDS.forEach(card => {
        const docId = `${companyId}_${card.id}`;
        const taskRef = doc(db, "operation_cards", docId)
        batch.set(taskRef, {
          ...card,
          companyId: companyId,
          companyName: "CETESB",
          priority: card.category === "Medicina" || card.id.includes('billing') ? "critical" : "high",
          createdAt: now,
          dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
          progress: 0,
          responsible: "Engenharia Alocada Nextcon",
          id: docId
        }, { merge: true })
      })

      await batch.commit()
      toast({ 
        title: "Onboarding CETESB Concluído!", 
        description: "15 Cards Multi-site foram injetados no SGI operacional." 
      })
    } catch (e) {
      console.error(e)
      toast({ variant: "destructive", title: "Erro no Onboarding Enterprise" })
    } finally {
      setUploadingCetesb(false)
    }
  }

  const handleCetesbOrgSeed = async () => {
    setUploadingOrg(true);
    try {
      const res = await seedCetesbOrganizationalStructure();
      if (res.sucesso) {
        toast({ title: "Estrutura Org. Ativada", description: res.mensagem });
      } else {
        throw new Error(res.mensagem);
      }
    } catch (e: any) {
      toast({ variant: "destructive", title: "Erro no Seed Organizacional", description: e.message });
    } finally {
      setUploadingOrg(false);
    }
  };

  const handleBritaniaSync = async () => {
    if (!user || !db) return
    setUploadingBritania(true)
    
    try {
      const batch = writeBatch(db)
      const now = new Date().toISOString()
      const companyId = "BRITANIA_JOINVILLE"

      const britania = REAL_COMPANIES.find(c => c.id === companyId)
      if (britania) {
        batch.set(doc(db, "companies", companyId), { ...britania, updatedAt: now }, { merge: true })
      }

      BRITANIA_EXPERTISES.forEach(exp => {
        const expRef = doc(db, "companies", companyId, "legalExpertises", exp.id)
        batch.set(expRef, {
          ...exp,
          createdAt: now,
          type: "Perícia Médica"
        }, { merge: true })
      })

      await batch.commit()
      toast({ 
        title: "Base Britânia Atualizada", 
        description: "7 Perícias Judiciais reais foram sincronizadas com sucesso." 
      })
    } catch (e) {
      toast({ variant: "destructive", title: "Erro no Sync Britânia" })
    } finally {
      setUploadingBritania(false)
    }
  }

  const handleRealBaseImport = async () => {
    if (!user || !db) return
    setUploadingGlobal(true)
    
    try {
      const batch = writeBatch(db)
      const now = new Date().toISOString()

      REAL_COMPANIES.forEach(comp => {
        batch.set(doc(db, "companies", comp.id), { ...comp, id: comp.id, updatedAt: now }, { merge: true })
      })

      REAL_CONTRACTS.forEach(contract => {
        batch.set(doc(db, "companies", contract.companyId, "contracts", contract.id), { ...contract, createdAt: now }, { merge: true })
      })

      await batch.commit()
      toast({ title: "Base Global Sincronizada", description: "Empresas e contratos carregados com sucesso." })
    } catch (e) {
      console.error(e)
      toast({ variant: "destructive", title: "Erro na Carga Global" })
    } finally {
      setUploadingGlobal(false)
    }
  }

  return (
    <div className="max-w-6xl mx-auto space-y-10 pb-20 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
        <div className="space-y-2">
          <h1 className="text-4xl font-headline font-black text-primary uppercase tracking-tight">Onboarding & Carga NAI</h1>
          <p className="text-muted-foreground font-medium uppercase text-xs tracking-widest">Provisionamento de Contratos Enterprise e eSocial Compliance.</p>
        </div>
        <div className="flex flex-wrap gap-3">
          <Button 
            className="h-16 px-10 bg-accent text-primary hover:bg-accent/90 rounded-2xl shadow-2xl gap-3 font-black uppercase text-xs tracking-widest"
            onClick={handleCetesbOnboarding}
            disabled={uploadingCetesb}
          >
            {uploadingCetesb ? <Loader2 className="size-5 animate-spin" /> : <Building2 className="size-5" />}
            Onboarding CETESB
          </Button>
          <Button 
            variant="outline"
            className="h-16 px-8 border-primary text-primary hover:bg-primary/5 rounded-2xl shadow-lg gap-3 font-black uppercase text-xs tracking-widest"
            onClick={handleCetesbOrgSeed}
            disabled={uploadingOrg}
          >
            {uploadingOrg ? <Loader2 className="size-5 animate-spin" /> : <Network className="size-5" />}
            Estrutura Org. Cetesb
          </Button>
          <Button 
            className="h-16 px-10 bg-primary text-white hover:bg-primary/90 rounded-2xl shadow-2xl gap-3 font-black uppercase text-xs tracking-widest"
            onClick={handleBritaniaSync}
            disabled={uploadingBritania}
          >
            {uploadingBritania ? <Loader2 className="size-5 animate-spin" /> : <Scale className="size-5 text-accent" />}
            Sync Britânia
          </Button>
          <Button 
            variant="outline"
            className="h-16 px-8 border-slate-200 text-slate-500 hover:bg-slate-50 rounded-2xl gap-3 font-black uppercase text-xs tracking-widest"
            onClick={handleRealBaseImport}
            disabled={uploadingGlobal}
          >
            {uploadingGlobal ? <Loader2 className="size-5 animate-spin" /> : <Database className="size-5" />}
            Sync Base Global
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        <Card className="card-shadow border-none bg-white rounded-[2rem] overflow-hidden group hover:ring-2 ring-primary/5 transition-all">
          <CardHeader className="bg-primary/5 pb-8">
            <div className="p-3 bg-white rounded-2xl w-fit shadow-sm mb-4">
              <FolderTree className="size-6 text-primary" />
            </div>
            <CardTitle className="text-xl font-black text-primary uppercase">Hierarquia Física (PGR)</CardTitle>
            <CardDescription className="text-xs font-bold uppercase opacity-60">Prédio Principal e Anexo 1.</CardDescription>
          </CardHeader>
          <CardContent className="p-8 space-y-4">
            <p className="text-sm text-slate-500 leading-relaxed font-medium italic">
              "Estrutura mapeada até o nível de Andar e Setor, permitindo a vinculação de GHEs e inventários de riscos específicos por ambiente."
            </p>
          </CardContent>
        </Card>

        <Card className="card-shadow border-none bg-slate-900 text-white rounded-[2rem] overflow-hidden group relative">
          <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:scale-110 transition-transform"><Zap className="size-32 text-accent" /></div>
          <CardHeader className="pb-8">
            <div className="p-3 bg-white/10 rounded-2xl w-fit shadow-sm mb-4">
              <FileSearch className="size-6 text-accent" />
            </div>
            <CardTitle className="text-xl font-black uppercase">Hierarquia Multi-Tenant</CardTitle>
            <CardDescription className="text-xs font-bold uppercase text-white/40">Isolamento total por cliente/unidade.</CardDescription>
          </CardHeader>
          <CardContent className="p-8">
            <p className="text-sm text-slate-300 leading-relaxed font-medium">
              Provisionamento automático de diretórios para as 50 unidades da CETESB, cumprindo as exigências do TCESP.
            </p>
          </CardContent>
        </Card>

        <Card className="card-shadow border-none bg-emerald-50 rounded-[2rem] overflow-hidden group">
          <CardHeader className="pb-8">
            <div className="p-3 bg-white rounded-2xl w-fit shadow-sm mb-4">
              <ShieldCheck className="size-6 text-emerald-600" />
            </div>
            <CardTitle className="text-xl font-black text-emerald-900 uppercase">Compliance eSocial 2026</CardTitle>
            <CardDescription className="text-xs font-bold uppercase text-emerald-700/60">Gatilhos S-2220 e S-2240.</CardDescription>
          </CardHeader>
          <CardContent className="p-8">
            <p className="text-sm text-emerald-800/70 leading-relaxed font-medium">
              Vínculo direto de eventos por localidade operacional, permitindo auditoria técnica individualizada por filial.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
