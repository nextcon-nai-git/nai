
"use client"

import * as React from "react"
import { 
  Cpu, 
  ShieldCheck, 
  XCircle, 
  CheckCircle2, 
  Loader2, 
  Fingerprint, 
  AlertTriangle, 
  Lock, 
  Signal, 
  Zap,
  Activity,
  ShieldAlert,
  ArrowRight
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { useToast } from "@/hooks/use-toast"
import { useUser, useFirestore, useCollection, useMemoFirebase } from "@/firebase"
import { collection, query, orderBy, addDoc, serverTimestamp } from "firebase/firestore"
import { cn } from "@/lib/utils"
import { REAL_EMPLOYEES } from "@/lib/real-data"

export default function FieldControlOperational() {
  const { toast } = useToast()
  const { user } = useUser()
  const db = useFirestore()
  const [isGatekeeperLoading, setIsGatekeeperLoading] = React.useState(false)
  const [selectedEmp, setSelectedEmp] = React.useState("")
  const [area, setArea] = React.useState("obras_laguna")
  const [lastResult, setLastResult] = React.useState<{authorized: boolean, message: string, detail?: string} | null>(null)

  const accessLogsQuery = useMemoFirebase(() => {
    if (!db) return null
    return query(collection(db, "access_logs"), orderBy("timestamp", "desc"))
  }, [db])
  const { data: accessLogs } = useCollection(accessLogsQuery)

  const handleSimulateTurnstile = async () => {
    if (!selectedEmp || !db) return
    setIsGatekeeperLoading(true)
    setLastResult(null)
    
    try {
      const emp = REAL_EMPLOYEES.find(e => e.id === selectedEmp)
      
      // Simulação de Inteligência Firewall (S-2220 e S-2240)
      const isAsoVencido = emp?.status_esocial_s2240 === "Erro" || Math.random() > 0.7
      const hasTraining = Math.random() > 0.2

      let isAuthorized = true
      let message = "ACESSO LIBERADO"
      let detail = "Conformidade eSocial S-1.3 validada."

      if (isAsoVencido) {
        isAuthorized = false
        message = "ACESSO BLOQUEADO"
        detail = "Risco eSocial S-2220: ASO Vencido ou Inexistente."
      } else if (!hasTraining) {
        isAuthorized = false
        message = "ACESSO BLOQUEADO"
        detail = "Risco NR-01: Treinamento de Integração ausente para esta zona."
      }

      await addDoc(collection(db, "access_logs"), {
        employeeName: emp?.name,
        area: area.replace('_', ' ').toUpperCase(),
        status: isAuthorized ? "authorized" : "denied",
        reason: message,
        detail,
        timestamp: serverTimestamp()
      })

      setLastResult({ authorized: isAuthorized, message, detail })
      
      if (isAuthorized) {
        toast({ title: "Acesso Autorizado", description: `Catraca liberada para ${emp?.name}.` })
      } else {
        toast({ variant: "destructive", title: "Entrada Bloqueada!", description: detail })
      }
    } finally {
      setIsGatekeeperLoading(false)
    }
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <h1 className="text-3xl font-headline font-black text-primary tracking-tight uppercase leading-none text-balance">
            Firewall Físico IoT 2026
          </h1>
          <p className="text-muted-foreground font-medium uppercase text-[10px] tracking-widest flex items-center gap-2">
            <Cpu className="size-3 text-accent animate-pulse" /> 
            Prevenção Ativa de Acidentes e Multas eSocial.
          </p>
        </div>
        <Badge variant="outline" className="h-10 border-red-500/30 text-red-500 font-black uppercase text-[10px] gap-2 bg-red-500/5 px-4 flex items-center shadow-lg">
          <ShieldAlert className="size-4" /> ZERO ACIDENTES TARGET
        </Badge>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Terminal da Catraca */}
        <Card className="lg:col-span-1 card-shadow border-none bg-white rounded-[2.5rem] overflow-hidden">
          <div className="p-8 bg-[#090e24] text-white">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 bg-white/10 rounded-lg text-accent shadow-inner"><Fingerprint className="size-5" /></div>
              <h3 className="text-xl font-headline font-black uppercase">Terminal NAI Gate</h3>
            </div>
            <p className="text-white/40 text-[9px] font-black uppercase tracking-widest">Sincronizado via WebSocket IoT</p>
          </div>
          
          <CardContent className="p-8 space-y-8">
            <div className={cn(
              "h-56 rounded-[2.5rem] border-4 flex flex-col items-center justify-center text-center p-8 transition-all duration-500 shadow-2xl relative overflow-hidden",
              !lastResult ? "bg-slate-900 border-slate-800" : 
              lastResult.authorized ? "bg-emerald-950 border-emerald-500" : 
              "bg-red-950 border-red-500"
            )}>
              {!lastResult ? (
                <div className="space-y-4">
                  <div className="size-4 bg-blue-500 rounded-full animate-ping mx-auto" />
                  <p className="text-[#00f2ff] font-mono text-[10px] font-black uppercase tracking-[0.4em]">Aproximar Crachá...</p>
                </div>
              ) : (
                <div className="space-y-4 animate-in zoom-in-95">
                  {lastResult.authorized ? <CheckCircle2 className="size-16 text-emerald-400 mx-auto" /> : <XCircle className="size-16 text-red-500 mx-auto" />}
                  <div className="space-y-1">
                    <p className={cn("font-black text-lg uppercase tabular-nums", lastResult.authorized ? "text-emerald-400" : "text-red-400")}>
                      {lastResult.message}
                    </p>
                    <p className="text-[9px] text-white/40 font-bold uppercase tracking-widest max-w-[200px] mx-auto leading-tight italic">
                      "{lastResult.detail}"
                    </p>
                  </div>
                </div>
              )}
            </div>

            <div className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest ml-1">Simular Colaborador</label>
                <Select value={selectedEmp} onValueChange={setSelectedEmp}>
                  <SelectTrigger className="h-14 bg-slate-50 border-none rounded-2xl font-bold shadow-inner"><SelectValue placeholder="Selecione um Perfil..." /></SelectTrigger>
                  <SelectContent>
                    {REAL_EMPLOYEES.map(e => <SelectItem key={e.id} value={e.id}>{e.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest ml-1">Zona de Acesso</label>
                <Select value={area} onValueChange={setArea}>
                  <SelectTrigger className="h-14 bg-slate-50 border-none rounded-2xl font-bold shadow-inner"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="obras_laguna">Canteiro - Ed. Laguna (NR-18)</SelectItem>
                    <SelectItem value="espaco_confinado">Área Crítica - NR-33</SelectItem>
                    <SelectItem value="escritorio">Administrativo</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Button 
              onClick={handleSimulateTurnstile} 
              disabled={isGatekeeperLoading || !selectedEmp} 
              className="w-full h-16 bg-primary text-white font-black uppercase text-xs tracking-widest rounded-2xl shadow-xl gap-3 hover:scale-[1.02] active:scale-95 transition-all"
            >
              {isGatekeeperLoading ? <Loader2 className="size-5 animate-spin" /> : <Zap className="size-5 text-accent" />}
              Bipar RFID na Catraca
            </Button>
          </CardContent>
        </Card>

        {/* Histórico de Bloqueios */}
        <Card className="lg:col-span-2 card-shadow border-none bg-white rounded-[2.5rem] overflow-hidden flex flex-col">
          <CardHeader className="bg-slate-50 border-b py-6 px-8 flex flex-row items-center justify-between">
            <div className="space-y-1">
              <CardTitle className="text-lg font-black text-primary uppercase">Firewall Live Status</CardTitle>
              <CardDescription className="text-[10px] font-bold uppercase text-slate-400">Cruzamento: Portaria vs eSocial S-1.3.</CardDescription>
            </div>
            <Badge variant="outline" className="h-8 gap-2 border-emerald-100 text-emerald-700 font-black uppercase text-[10px] bg-emerald-50 px-3">
              <div className="size-2 bg-emerald-500 rounded-full animate-ping" /> Motor NAI Ativo
            </Badge>
          </CardHeader>
          <CardContent className="p-0 flex-1 overflow-y-auto max-h-[650px] scrollbar-thin">
            <Table>
              <TableHeader className="bg-slate-50/50 text-[10px] uppercase font-black">
                <TableRow>
                  <TableHead className="pl-8">Colaborador</TableHead>
                  <TableHead>Local / Risco</TableHead>
                  <TableHead>Status Firewall</TableHead>
                  <TableHead className="pr-8 text-right">Diagnóstico</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {accessLogs?.map((log) => (
                  <TableRow key={log.id} className="hover:bg-slate-50/50 transition-colors">
                    <TableCell className="pl-8 py-5">
                      <p className="font-black text-xs text-primary uppercase leading-tight">{log.employeeName}</p>
                      <p className="text-[8px] text-slate-400 font-bold uppercase mt-1">
                        {log.timestamp ? new Date(log.timestamp.seconds * 1000).toLocaleTimeString('pt-BR') : '--:--'}
                      </p>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="text-[8px] font-black uppercase border-primary/10 text-primary/60 px-2 h-5">
                        {log.area}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge className={cn(
                        "text-[8px] font-black uppercase border-none px-3 h-6",
                        log.status === 'authorized' ? "bg-emerald-100 text-emerald-700" : "bg-red-100 text-red-700"
                      )}>
                        {log.status === 'authorized' ? "Aprovado" : "Bloqueado"}
                      </Badge>
                    </TableCell>
                    <TableCell className="pr-8 text-right">
                      <div className="space-y-0.5">
                        <p className={cn("text-[10px] font-bold leading-tight", log.status === 'authorized' ? "text-emerald-600" : "text-red-600 italic")}>
                          {log.detail}
                        </p>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
                {(!accessLogs || accessLogs.length === 0) && (
                  <TableRow><TableCell colSpan={4} className="py-32 text-center opacity-30 font-black uppercase text-sm tracking-[0.4em]">Aguardando Fluxo no Perímetro</TableCell></TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
