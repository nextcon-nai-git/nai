'use client';

import { useUser } from '@/firebase';
import { usePathname, useRouter } from 'next/navigation';
import { Loader2 } from 'lucide-react';
import * as React from 'react';
import { TopNav } from '@/components/layout/top-nav';
import { AppSidebar } from '@/components/layout/app-sidebar';
import { SidebarProvider, SidebarInset } from '@/components/ui/sidebar';
import { NaiFloatingWidget } from '@/components/commercial/nai-floating-widget';

/**
 * @fileOverview Gatekeeper de Autenticação e Splash Screen - Fix Hidratação.
 */
export function AppContent({ children }: { children: React.ReactNode }) {
  const { user, isUserLoading } = useUser();
  const pathname = usePathname();
  const router = useRouter();
  const [mounted, setMounted] = React.useState(false);

  React.useEffect(() => {
    setMounted(true);
  }, []);

  React.useEffect(() => {
    if (mounted && !isUserLoading) {
      if (!user && pathname !== '/login') {
        router.replace('/login');
      } else if (user && pathname === '/login') {
        router.replace('/');
      }
    }
  }, [user, isUserLoading, pathname, router, mounted]);

  // Evita erros de hidratação renderizando apenas após o mount
  if (!mounted) return null;

  const isLoginPage = pathname === '/login';

  // Splash Screen Resiliente
  if (isUserLoading && !isLoginPage) {
    return (
      <div className="fixed inset-0 flex flex-col items-center justify-center bg-[#001F3F] z-[9999]">
        <div className="size-24 rounded-[2.5rem] bg-[#090e24] flex items-center justify-center text-white font-black text-5xl shadow-2xl border-2 border-white/10 animate-bounce">
          N
        </div>
        <div className="mt-8 flex flex-col items-center gap-2">
          <div className="flex items-center gap-3">
            <Loader2 className="h-4 w-4 animate-spin text-accent" />
            <span className="text-[10px] font-black text-white/60 uppercase tracking-[0.4em]">NextCon Intelligence</span>
          </div>
          <p className="text-[8px] font-bold text-white/20 uppercase tracking-widest">Iniciando Protocolos 2026...</p>
        </div>
      </div>
    );
  }

  if (isLoginPage) {
    return <div className="min-h-screen w-full bg-white">{children}</div>;
  }

  if (!user) return null;

  return (
    <SidebarProvider>
      <div className="flex h-screen w-full bg-background overflow-hidden relative">
        <AppSidebar />
        <SidebarInset className="flex flex-col h-full overflow-hidden">
          <TopNav />
          <main className="flex-1 overflow-y-auto p-6 md:p-10 scrollbar-thin">
            <div className="max-w-7xl mx-auto animate-in fade-in duration-500">
              {children}
            </div>
          </main>
        </SidebarInset>
        <NaiFloatingWidget />
      </div>
    </SidebarProvider>
  );
}
