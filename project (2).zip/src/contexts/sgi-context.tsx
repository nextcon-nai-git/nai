'use client';

import * as React from "react"
import { useUser } from "@/firebase"

interface SgiContextType {
  activeClientId: string
  setActiveClientId: (id: string) => void
  isGlobalView: boolean
}

const SgiContext = React.createContext<SgiContextType | undefined>(undefined)

/**
 * Provider global para o Sistema de Gestão Integrada (SGI).
 * Gerencia o isolamento multi-tenant de forma reativa e segura.
 */
export function SgiProvider({ children }: { children: React.ReactNode }) {
  const { role, companyId, isUserLoading } = useUser();
  const [activeClientId, setActiveClientId] = React.useState<string>("all")

  const isGlobalAdmin = React.useMemo(() => 
    ['SUPER_ADMIN', 'ADMIN', 'ENGINEER'].includes(role || ''), 
  [role]);

  // Sincroniza o contexto com o perfil do usuário de forma reativa
  React.useEffect(() => {
    if (!isUserLoading) {
      if (!isGlobalAdmin && companyId) {
        // Trava o contexto na empresa do usuário (Isolamento Cliente)
        setActiveClientId(companyId);
      } else if (!isGlobalAdmin && !companyId) {
        // Usuário sem vínculo não tem acesso a dados
        setActiveClientId("unauthorized");
      } else if (isGlobalAdmin && activeClientId === "unauthorized") {
        // Reset para admin se estivesse travado
        setActiveClientId("all");
      }
    }
  }, [role, companyId, isUserLoading, isGlobalAdmin, activeClientId]);

  const value = React.useMemo(() => ({
    activeClientId,
    setActiveClientId: (id: string) => {
      // Apenas admins podem trocar de cliente manualmente
      if (isGlobalAdmin) {
        setActiveClientId(id);
      }
    },
    isGlobalView: activeClientId === "all"
  }), [activeClientId, isGlobalAdmin]);

  return (
    <SgiContext.Provider value={value}>
      {children}
    </SgiContext.Provider>
  )
}

export function useSgi() {
  const context = React.useContext(SgiContext)
  if (context === undefined) {
    throw new Error("useSgi deve ser usado dentro de um SgiProvider")
  }
  return context;
}
