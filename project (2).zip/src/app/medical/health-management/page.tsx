
"use client"

import * as React from "react"
import { Building2, Zap, Thermometer, FileCheck, TrendingUp, Brain, Users, Activity, HeartPulse, ShieldCheck, Lock, History } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { useFirestore, useCollection, useMemoFirebase } from "@/firebase"
import { collection, query, orderBy, limit } from "firebase/firestore"
import { AttendanceTab } from "@/components/medical/tabs/AttendanceTab"
import { StructuredRecordTab } from "@/components/medical/tabs/StructuredRecordTab"
import { ProfessionalEvolutionTab } from "@/components/medical/tabs/ProfessionalEvolutionTab"
import { PsychosocialTab } from "@/components/medical/tabs/PsychosocialTab"
import { NewAttendanceModal } from "@/components/medical/modals/NewAttendanceModal"
import { cn } from "@/lib/utils"

/**
 * @fileOverview Gestão de Saúde Unificada - Auditoria Firestore Absoluta.
 */

export default function HealthManagementUnified() {
  const db = useFirestore()
  const [activeTab, setActiveTab] = React.useState("clinical_records")

  // Listener Real-time para Atendimentos de Enfermagem
  const attendancesQuery = useMemoFirebase(() => {
    if (!db) return null
    return query(collection(db, "nursing_attendances"), orderBy("createdAt", "desc"), limit(100))
  }, [db])
  const { data: attendances, isLoading: loadingAttendances } = useCollection(attendancesQuery)

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-1 text-left">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-primary text-white rounded-xl shadow-xl shadow-primary/20"><HeartPulse size={24} /></div>
            <h1 className="text-3xl font-headline font-black text-primary tracking-tight uppercase leading-none">Saúde & Prontuário Digital</h1>
          </div>
          <p className="text-muted-foreground font-medium uppercase text-[10px] tracking-widest mt-2 flex items-center gap-2">
            <ShieldCheck className="size-3 text-emerald-600" /> Compliance PEP & LGPD 2026 | Protocolo NAI Health.
          </p>
        </div>
        <div className="flex gap-2">
          <NewAttendanceModal />
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-3">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <div className="overflow-x-auto pb-4 scrollbar-thin">
              <TabsList className="flex w-fit bg-muted/50 p-1.5 rounded-2xl h-16">
                <TabsTrigger value="clinical_records" className="rounded-xl gap-2 text-[10px] font-black uppercase tracking-widest px-8 text-accent data-[state=active]:bg-white data-[state=active]:shadow-lg">
                  <FileCheck className="size-4" /> Prontuário (PEP)
                </TabsTrigger>
                <TabsTrigger value="attendance" className="rounded-xl gap-2 text-[10px] font-black uppercase tracking-widest px-8 data-[state=active]:bg-white data-[state=active]:shadow-lg">
                  <Thermometer className="size-4" /> Atendimento
                </TabsTrigger>
                <TabsTrigger value="evolution" className="rounded-xl gap-2 text-[10px] font-black uppercase tracking-widest px-8 data-[state=active]:bg-white data-[state=active]:shadow-lg">
                  <TrendingUp className="size-4" /> Evolução Técnica
                </TabsTrigger>
                <TabsTrigger value="psychosocial" className="rounded-xl gap-2 text-[10px] font-black uppercase tracking-widest px-8 data-[state=active]:bg-white data-[state=active]:shadow-lg">
                  <Brain className="size-4" /> Risco Psicossocial
                </TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="clinical_records" className="mt-8 animate-in slide-in-from-bottom-4 duration-500">
              <StructuredRecordTab />
            </TabsContent>

            <TabsContent value="attendance" className="mt-8 animate-in slide-in-from-bottom-4 duration-500">
              <AttendanceTab attendances={attendances || []} loading={loadingAttendances} />
            </TabsContent>

            <TabsContent value="evolution" className="mt-8 animate-in slide-in-from-bottom-4 duration-500">
              <ProfessionalEvolutionTab />
            </TabsContent>

            <TabsContent value="psychosocial" className="mt-8 animate-in slide-in-from-bottom-4 duration-500">
              <PsychosocialTab />
            </TabsContent>
          </Tabs>
        </div>

        <div className="lg:col-span-1 space-y-6">
          <Card className="bg-[#090e24] text-white p-8 rounded-[2.5rem] relative overflow-hidden shadow-2xl group">
             <div className="absolute top-0 right-0 p-6 opacity-10 group-hover:scale-110 transition-transform duration-1000"><Lock className="size-32 text-accent" /></div>
             <div className="relative z-10 space-y-6 text-left">
                <Badge className="bg-emerald-50 text-primary border-none text-[8px] font-black uppercase tracking-widest">LGPD Auditor</Badge>
                <h3 className="text-lg font-black uppercase tracking-tight font-headline">Segurança de Dados</h3>
                <p className="text-xs text-white/60 leading-relaxed font-medium">
                  Todos os acessos a dados médicos são criptografados e registrados em log de auditoria permanente conforme Resolução CFM 2.314.
                </p>
                <div className="pt-6 border-t border-white/5 space-y-3">
                   <div className="flex items-center gap-3">
                      <History className="size-4 text-accent" />
                      <span className="text-[9px] font-bold uppercase text-white/40">Sincronização Cloud Ativa</span>
                   </div>
                   <Button variant="outline" className="w-full h-10 border-white/10 text-white font-black uppercase text-[9px] rounded-xl hover:bg-white/5">
                      Ver Log de Auditoria
                   </Button>
                </div>
             </div>
          </Card>

          <Card className="card-shadow border-none bg-white rounded-[2.5rem] p-8 flex flex-col gap-4">
             <div className="flex items-center gap-3">
                <div className="p-2 bg-primary rounded-lg text-white shadow-sm"><ShieldCheck className="size-4" /></div>
                <h4 className="text-sm font-black text-primary uppercase">Sigilo Médico</h4>
             </div>
             <p className="text-[10px] text-primary/70 leading-relaxed font-medium italic text-left">
               "O acesso ao Prontuário Eletrônico do Paciente (PEP) é restrito a profissionais de saúde devidamente habilitados e com certificados ativos."
             </p>
          </Card>
        </div>
      </div>
    </div>
  )
}

