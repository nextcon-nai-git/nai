"use client";

import * as React from "react";
import { useState, useTransition, useOptimistic, useRef } from "react";
import { 
  Brain, 
  Sparkles, 
  Activity, 
  ShieldAlert, 
  Zap, 
  HardHat, 
  ChevronRight, 
  Loader2, 
  Stethoscope, 
  Building2,
  Info,
  CheckCircle2,
  AlertTriangle,
  Timer,
  Scale,
  Dna,
  Gauge,
  ClipboardList
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Checkbox } from "@/components/ui/checkbox";
import { cn } from "@/lib/utils";
import { useSgi } from "@/contexts/sgi-context";
import { useUser, useDoc, useMemoFirebase, useFirestore } from "@/firebase";
import { doc } from "firebase/firestore";

// Tipagens Estruturais do Ecossistema NAI 2026
type SeverityLevel = "NENHUM" | "BAIXO" | "MÉDIO" | "ALTO" | "CRÍTICO";

interface BodyZone {
  id: string;
  name: string;
  level: SeverityLevel;
  clicks: number;
}

interface RiskItem {
  id: string;
  nr: string;
  description: string;
  severity: SeverityLevel;
  status: "AUDITADO" | "PENDENTE";
}

const BORG_SCALE = [
  { value: 0, label: "Repouso Total", color: "bg-slate-100 text-slate-500" },
  { value: 2, label: "Muito Leve", color: "bg-emerald-50 text-emerald-600" },
  { value: 4, label: "Moderado", color: "bg-blue-50 text-blue-600" },
  { value: 6, label: "Pesado", color: "bg-amber-50 text-amber-600" },
  { value: 8, label: "Muito Pesado", color: "bg-orange-50 text-orange-600" },
  { value: 10, label: "Esforço Máximo", color: "bg-red-50 text-red-600 animate-pulse" },
];

export default function BiomechanicsPage() {
  const { user } = useUser();
  const db = useFirestore();
  const { activeClientId } = useSgi();
  const [isPending, startTransition] = useTransition();

  const profileRef = useMemoFirebase(() => {
    if (!db || !user) return null;
    return doc(db, "users", user.uid);
  }, [db, user]);
  const { data: profile } = useDoc(profileRef);

  // 1. Estados de Mapeamento
  const [bodyZones, setBodyZones] = useState<Record<string, BodyZone>>({
    head: { id: "head", name: "Craniana / Cervical", level: "NENHUM", clicks: 0 },
    neck: { id: "neck", name: "Pescoço / Escapular", level: "NENHUM", clicks: 0 },
    leftShoulder: { id: "leftShoulder", name: "Ombro Esquerdo", level: "NENHUM", clicks: 0 },
    rightShoulder: { id: "rightShoulder", name: "Ombro Direito", level: "NENHUM", clicks: 0 },
    thoracic: { id: "thoracic", name: "Coluna Torácica", level: "NENHUM", clicks: 0 },
    lumbar: { id: "lumbar", name: "Região Lombar", level: "NENHUM", clicks: 0 },
    leftArm: { id: "leftArm", name: "Braço Esquerdo", level: "NENHUM", clicks: 0 },
    rightArm: { id: "rightArm", name: "Braço Direito", level: "NENHUM", clicks: 0 },
    leftHand: { id: "leftHand", name: "Mão / Punho Esquerdo", level: "NENHUM", clicks: 0 },
    rightHand: { id: "rightHand", name: "Mão / Punho Direito", level: "NENHUM", clicks: 0 },
    leftKnee: { id: "leftKnee", name: "Joelho Esquerdo", level: "NENHUM", clicks: 0 },
    rightKnee: { id: "rightKnee", name: "Joelho Direito", level: "NENHUM", clicks: 0 },
    leftFootAnkle: { id: "leftFootAnkle", name: "Pés e Tornozelos (E)", level: "NENHUM", clicks: 0 },
    rightFootAnkle: { id: "rightFootAnkle", name: "Pés e Tornozelos (D)", level: "NENHUM", clicks: 0 },
    legs: { id: "legs", name: "Membros Inferiores (Geral)", level: "NENHUM", clicks: 0 },
  });

  const [borgValue, setBorgValue] = useState(0);
  const [checklist, setChecklist] = useState({
    repetitiveness: false,
    static_posture: false,
    heavy_lifting: false,
    vibration: false,
    extreme_temp: false,
    compression: false
  });

  const [risks, setRisks] = useState<RiskItem[]>([
    { id: "1", nr: "NR-17", description: "Queixa difusa de lombalgia na linha de empacotamento.", severity: "ALTO", status: "PENDENTE" },
    { id: "2", nr: "NR-12", description: "Ponto de esmagamento sem enclausuramento técnico.", severity: "CRÍTICO", status: "PENDENTE" }
  ]);

  const [optimisticRisks, setOptimisticRisks] = useOptimistic(
    risks,
    (state, newRisk: RiskItem) => [newRisk, ...state]
  );

  const [aiText, setAiText] = useState("");
  const [isAiStreaming, setIsAiStreaming] = useState(false);
  const streamRef = useRef<HTMLDivElement>(null);

  // Score de Risco Consolidado (Cálculo NAI 2026)
  const consolidatedRiskScore = React.useMemo(() => {
    let score = 0;
    // Peso das zonas de dor
    const activePains = Object.values(bodyZones).filter(z => z.level !== "NENHUM").length;
    score += activePains * 5;
    
    // Peso Escala de Borg
    score += (borgValue * 3);
    
    // Peso Checklist
    const activeChecks = Object.values(checklist).filter(v => v === true).length;
    score += activeChecks * 10;

    return Math.min(score, 100);
  }, [bodyZones, borgValue, checklist]);

  const handleZoneClick = (zoneId: string) => {
    setBodyZones((prev) => {
      const zone = prev[zoneId];
      const nextClicks = (zone.clicks + 1) % 5;
      const levels: SeverityLevel[] = ["NENHUM", "BAIXO", "MÉDIO", "ALTO", "CRÍTICO"];
      const nextLevel = levels[nextClicks];
      return {
        ...prev,
        [zoneId]: { ...zone, clicks: nextClicks, level: nextLevel },
      };
    });
  };

  const getZoneColorClass = (level: SeverityLevel) => {
    switch (level) {
      case "BAIXO": return "fill-emerald-500/40 stroke-emerald-400 hover:fill-emerald-500/60";
      case "MÉDIO": return "fill-amber-500/40 stroke-amber-400 hover:fill-amber-500/60";
      case "ALTO": return "fill-orange-500/50 stroke-orange-400 hover:fill-orange-500/70";
      case "CRÍTICO": return "fill-red-600/60 stroke-red-500 hover:fill-red-600/80 animate-pulse";
      default: return "fill-slate-100 stroke-slate-200 hover:fill-slate-200";
    }
  };

  const getSeverityBadge = (level: SeverityLevel) => {
    switch (level) {
      case "BAIXO": return "bg-emerald-500/10 text-emerald-400 border-emerald-500/20";
      case "MÉDIO": return "bg-amber-500/10 text-amber-400 border-amber-500/20";
      case "ALTO": return "bg-orange-500/10 text-orange-400 border-orange-500/20";
      case "CRÍTICO": return "bg-red-500/10 text-red-400 border-red-500/20 animate-pulse";
      default: return "bg-slate-800 text-slate-500 border-slate-700";
    }
  };

  const runAIEpidemiology = async () => {
    setIsAiStreaming(true);
    setAiText("");
    
    const activePains = Object.values(bodyZones).filter(z => z.level !== "NENHUM");
    const borg = BORG_SCALE.find(b => b.value === borgValue);
    
    let report = `### PARECER EPIDEMIOLÓGICO NAI (CONSOLIDADO)\n\n`;
    report += `**Score de Risco Global:** ${consolidatedRiskScore}% \n`;
    report += `**Escala de Borg (CR10):** ${borgValue} - ${borg?.label} \n\n`;
    
    if (consolidatedRiskScore < 20) {
      report += "Análise: Unidade operando em regime de baixo estresse biomecânico. Nenhuma ação corretiva imediata requerida para eSocial S-2240.";
    } else {
      report += `Diagnóstico: Detectado nível de fadiga muscular elevado (${activePains.length} zonas ativas). \n`;
      if (checklist.repetitiveness) report += `• ALERTA: Alta repetitividade identificada (Nexo LER/DORT).\n`;
      if (checklist.heavy_lifting) report += `• CRÍTICO: Sobrecarga lombar por levantamento de peso detectada.\n`;
      
      report += "\n**PRESCRIÇÃO NAI 2026:** \n";
      report += "1. Implementar rodízio obrigatório de postos a cada 60 minutos.\n";
      report += "2. Realizar análise Ergonômica de Processo (AET) no setor em até 5 dias úteis.\n";
      report += "3. Agendar triagem médica para colaboradores com Borg > 6.";
    }

    const words = report.split(" ");
    let currentText = "";
    for (const word of words) {
      await new Promise((res) => setTimeout(res, 40));
      currentText += word + " ";
      setAiText(currentText);
    }
    setIsAiStreaming(false);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4 text-left">
        <div className="space-y-1">
          <h1 className="text-3xl font-headline font-black text-primary tracking-tight uppercase leading-none">Módulo de Auditoria Biomecânica</h1>
          <p className="text-muted-foreground font-medium uppercase text-[10px] tracking-widest mt-2 flex items-center gap-2">
            <Activity className="size-3 text-accent" /> Vigilância Epidemiológica Preditiva & Saúde 4.0.
          </p>
        </div>
        <div className="flex items-center gap-4 bg-white border px-4 py-2 rounded-xl shadow-sm">
           <div className="text-[10px] font-black uppercase text-slate-400">Score Global: <span className={cn("ml-1 font-black", consolidatedRiskScore > 70 ? "text-red-600" : "text-primary")}>{consolidatedRiskScore}%</span></div>
           <div className="h-4 w-px bg-slate-200" />
           <Badge variant="outline" className="text-[8px] font-black uppercase border-emerald-100 text-emerald-700 bg-emerald-50">Sincronizado e-Social</Badge>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* AVATAR CLÍNICO */}
        <div className="lg:col-span-4 space-y-6">
          <Card className="card-shadow border-none bg-white rounded-[2.5rem] overflow-hidden flex flex-col items-center">
            <CardHeader className="w-full bg-slate-50 border-b py-6 px-8 flex flex-row items-center justify-between">
              <div className="text-left">
                <CardTitle className="text-sm font-black text-primary uppercase">Avatar de Vigilância</CardTitle>
                <CardDescription className="text-[9px] font-bold uppercase tracking-widest">Mapeamento Anatômico 2026.</CardDescription>
              </div>
            </CardHeader>
            <CardContent className="p-8 w-full flex flex-col items-center">
              <div className="w-full max-w-[280px] py-6 transition-transform duration-500">
                <svg viewBox="0 0 200 520" className="w-full h-auto drop-shadow-2xl">
                  {/* Cabeça */}
                  <circle cx="100" cy="50" r="22" className={cn("cursor-pointer transition-all duration-300 stroke-2", getZoneColorClass(bodyZones.head.level))} onClick={() => handleZoneClick("head")} />
                  {/* Pescoço */}
                  <rect x="93" y="74" width="14" height="16" rx="4" className={cn("cursor-pointer transition-all duration-300 stroke-2", getZoneColorClass(bodyZones.neck.level))} onClick={() => handleZoneClick("neck")} />
                  {/* Ombros */}
                  <circle cx="62" cy="105" r="11" className={cn("cursor-pointer transition-all duration-300 stroke-2", getZoneColorClass(bodyZones.leftShoulder.level))} onClick={() => handleZoneClick("leftShoulder")} />
                  <circle cx="138" cy="105" r="11" className={cn("cursor-pointer transition-all duration-300 stroke-2", getZoneColorClass(bodyZones.rightShoulder.level))} onClick={() => handleZoneClick("rightShoulder")} />
                  {/* Tronco */}
                  <path d="M 75,102 L 125,102 L 120,200 L 80,200 Z" className={cn("cursor-pointer transition-all duration-300 stroke-2", getZoneColorClass(bodyZones.thoracic.level))} onClick={() => handleZoneClick("thoracic")} />
                  {/* Braços */}
                  <path d="M 48,112 C 35,160 30,210 40,240 C 42,246 48,242 46,234 C 38,210 44,160 54,116 Z" className={cn("cursor-pointer transition-all duration-300 stroke-2", getZoneColorClass(bodyZones.leftArm.level))} onClick={() => handleZoneClick("leftArm")} />
                  <path d="M 152,112 C 165,160 170,210 160,240 C 158,246 152,242 154,234 C 162,210 156,160 146,116 Z" className={cn("cursor-pointer transition-all duration-300 stroke-2", getZoneColorClass(bodyZones.rightArm.level))} onClick={() => handleZoneClick("rightArm")} />
                  
                  {/* MÃOS */}
                  <circle cx="40" cy="245" r="8" className={cn("cursor-pointer transition-all duration-300 stroke-2", getZoneColorClass(bodyZones.leftHand.level))} onClick={() => handleZoneClick("leftHand")} />
                  <circle cx="160" cy="245" r="8" className={cn("cursor-pointer transition-all duration-300 stroke-2", getZoneColorClass(bodyZones.rightHand.level))} onClick={() => handleZoneClick("rightHand")} />

                  {/* Lombar */}
                  <rect x="82" y="205" width="36" height="45" rx="6" className={cn("cursor-pointer transition-all duration-300 stroke-2", getZoneColorClass(bodyZones.lumbar.level))} onClick={() => handleZoneClick("lumbar")} />
                  
                  {/* Pernas Base */}
                  <path d="M 82,256 L 98,256 L 90,460 C 88,470 74,470 76,450 L 84,330 Z M 102,256 L 118,256 L 116,330 L 124,450 C 126,470 112,470 110,460 Z" className={cn("cursor-pointer transition-all duration-300 stroke-2", getZoneColorClass(bodyZones.legs.level))} onClick={() => handleZoneClick("legs")} />
                  
                  {/* JOELHOS */}
                  <circle cx="84" cy="350" r="9" className={cn("cursor-pointer transition-all duration-300 stroke-2", getZoneColorClass(bodyZones.leftKnee.level))} onClick={() => handleZoneClick("leftKnee")} />
                  <circle cx="116" cy="350" r="9" className={cn("cursor-pointer transition-all duration-300 stroke-2", getZoneColorClass(bodyZones.rightKnee.level))} onClick={() => handleZoneClick("rightKnee")} />

                  {/* PÉS E TORNOZELOS (Unificado) */}
                  <circle cx="78" cy="478" r="9" className={cn("cursor-pointer transition-all duration-300 stroke-2", getZoneColorClass(bodyZones.leftFootAnkle.level))} onClick={() => handleZoneClick("leftFootAnkle")} />
                  <circle cx="122" cy="478" r="9" className={cn("cursor-pointer transition-all duration-300 stroke-2", getZoneColorClass(bodyZones.rightFootAnkle.level))} onClick={() => handleZoneClick("rightFootAnkle")} />
                </svg>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* ESCALA DE BORG E CHECKLIST */}
        <div className="lg:col-span-8 space-y-6">
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* ESCALA DE BORG */}
            <Card className="card-shadow border-none bg-white rounded-[2.5rem] overflow-hidden">
               <CardHeader className="bg-slate-50 border-b p-6 text-left">
                  <CardTitle className="text-xs font-black uppercase text-primary flex items-center gap-2">
                    <Gauge className="size-4 text-accent" /> Percepção de Esforço (Borg CR10)
                  </CardTitle>
               </CardHeader>
               <CardContent className="p-6">
                  <div className="grid grid-cols-2 gap-2">
                    {BORG_SCALE.map((item) => (
                      <button 
                        key={item.value}
                        onClick={() => setBorgValue(item.value)}
                        className={cn(
                          "p-3 rounded-xl border-2 transition-all text-left flex flex-col gap-1",
                          borgValue === item.value ? "border-primary bg-primary/5 shadow-md" : "border-slate-50 bg-slate-50 hover:border-primary/10"
                        )}
                      >
                         <span className="text-[10px] font-black uppercase opacity-40">Nível {item.value}</span>
                         <span className="text-xs font-bold text-primary">{item.label}</span>
                      </button>
                    ))}
                  </div>
               </CardContent>
            </Card>

            {/* CHECKLIST ERGONÔMICO NAI */}
            <Card className="card-shadow border-none bg-white rounded-[2.5rem] overflow-hidden">
               <CardHeader className="bg-slate-50 border-b p-6 text-left">
                  <CardTitle className="text-xs font-black uppercase text-primary flex items-center gap-2">
                    <ClipboardList className="size-4 text-accent" /> Agravos Operacionais (NR-17)
                  </CardTitle>
               </CardHeader>
               <CardContent className="p-6 space-y-3">
                  {[
                    { id: 'repetitiveness', label: "Alta Repetitividade (LER/DORT)" },
                    { id: 'static_posture', label: "Postura Estática Prolongada" },
                    { id: 'heavy_lifting', label: "Levantamento de Carga Excessiva" },
                    { id: 'vibration', label: "Exposição a Vibrações (Corpo Inteiro)" },
                    { id: 'compression', label: "Compressão Mecânica de Tecidos" },
                  ].map((item) => (
                    <div 
                      key={item.id} 
                      className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl border border-transparent hover:border-primary/10 cursor-pointer group"
                      onClick={() => setChecklist(prev => ({ ...prev, [item.id]: !prev[item.id as keyof typeof checklist] }))}
                    >
                      <Checkbox 
                        checked={checklist[item.id as keyof typeof checklist]} 
                        className="size-4 rounded-md border-slate-300"
                      />
                      <span className="text-[11px] font-bold text-slate-600 uppercase group-hover:text-primary transition-colors">{item.label}</span>
                    </div>
                  ))}
               </CardContent>
            </Card>
          </div>

          <Card className="card-shadow border-none bg-white rounded-[2.5rem] overflow-hidden p-2">
             <div className="bg-[#001F3F] p-6 rounded-[2rem] text-white flex flex-col md:flex-row items-center justify-between gap-6">
                <div className="flex items-center gap-4">
                  <div className="size-14 rounded-2xl bg-white/10 flex items-center justify-center border border-white/20">
                     <Brain className="size-8 text-accent" />
                  </div>
                  <div className="text-left">
                    <p className="text-[9px] font-black uppercase text-accent tracking-[0.3em]">Neural Analytics v2.7</p>
                    <h3 className="text-xl font-black uppercase tracking-tight">Audit Insight Engine</h3>
                  </div>
                </div>
                <Button 
                  onClick={runAIEpidemiology} 
                  disabled={isAiStreaming} 
                  className="h-14 px-10 bg-accent text-primary font-black uppercase text-[10px] tracking-widest rounded-xl shadow-2xl hover:scale-105 active:scale-95 transition-all gap-2"
                >
                  {isAiStreaming ? <Loader2 className="size-4 animate-spin" /> : <Sparkles className="size-4" />}
                  Compilar Auditoria Preditiva
                </Button>
             </div>

             {(aiText || isAiStreaming) && (
               <div className="p-8 animate-in slide-in-from-top-4 duration-500 text-left">
                  <div className="p-6 bg-slate-50 rounded-3xl border-2 border-dashed border-primary/10 relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-4 opacity-5"><Zap className="size-32 text-primary" /></div>
                    <p className="text-sm font-medium leading-relaxed italic text-slate-700 whitespace-pre-line relative z-10">
                      {aiText}
                      {isAiStreaming && <span className="inline-block w-1.5 h-3.5 bg-primary ml-1 animate-pulse" />}
                    </p>
                    <div ref={streamRef} />
                  </div>
               </div>
             )}
          </Card>
        </div>
      </div>
    </div>
  );
}

