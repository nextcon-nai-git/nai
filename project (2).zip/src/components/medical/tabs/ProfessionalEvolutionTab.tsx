"use client";

import * as React from "react";
import { 
  Stethoscope, 
  Activity, 
  Brain, 
  HeartPulse, 
  Thermometer, 
  CheckCircle2, 
  Save, 
  type LucideIcon, 
  Loader2, 
  Clock, 
  Play, 
  Square,
  ClipboardList
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { useFirestore, useUser, useCollection, useMemoFirebase } from "@/firebase";
import { collection, query, where, orderBy, limit } from "firebase/firestore";

interface ChecklistItem {
  id: string;
  label: string;
  ref: string;
}

interface ProfessionalConfig {
  title: string;
  role: string;
  icon: LucideIcon;
  color: string;
  bg: string;
  contractHours: number;
  checklist: ChecklistItem[];
}

const PROFESSIONAL_EVOLUTION: Record<string, ProfessionalConfig> = {
  medico: {
    title: "Médica do Trabalho",
    role: "SESMT CETESB (8h)",
    icon: Stethoscope,
    color: "text-blue-600",
    bg: "bg-blue-50",
    contractHours: 8,
    checklist: [
      { id: "m1", label: "Validar ASOs pendentes e emitir pareceres de aptidão.", ref: "NR-07" },
      { id: "m2", label: "Coordenar investigação de nexo causal em afastamentos B91.", ref: "NR-01" },
      { id: "m3", label: "Realizar busca ativa de doenças ocupacionais via indicadores.", ref: "Epidemiologia" },
      { id: "m4", label: "Participar de reunião do comitê de gestão de riscos.", ref: "Estratégico" }
    ]
  },
  enfermeiro: {
    title: "Enfermeira do Trabalho",
    role: "SESMT CETESB (8h)",
    icon: HeartPulse,
    color: "text-red-600",
    bg: "bg-red-50",
    contractHours: 8,
    checklist: [
      { id: "e1", label: "Implementar SAE (Sistematização da Assistência de Enf.).", ref: "COFEN" },
      { id: "e2", label: "Gerenciar estoque de medicamentos e validade de insumos.", ref: "Logística" },
      { id: "e3", label: "Auditar registros de triagem realizados pelos técnicos.", ref: "Qualidade" },
      { id: "e4", label: "Promover campanha mensal de saúde preventiva (SIPAT).", ref: "Educação" }
    ]
  },
  engenheiro: {
    title: "Engenheiro de Segurança",
    role: "SESMT CETESB (4h)",
    icon: Activity,
    color: "text-emerald-600",
    bg: "bg-emerald-50",
    contractHours: 4,
    checklist: [
      { id: "f1", label: "Realizar Blitz Postural nos postos de armação/carpintaria.", ref: "NR-17" },
      { id: "f2", label: "Atualizar Análise Ergonômica Preliminar (AEP) do setor A.", ref: "GRO" },
      { id: "f3", label: "Treinar equipe sobre levantamento e transporte de cargas.", ref: "Treinamento" },
      { id: "f4", label: "Acompanhar retorno ao trabalho de pós-cirúrgicos.", ref: "Reabilitação" }
    ]
  }
};

type ProfessionalRole = keyof typeof PROFESSIONAL_EVOLUTION;

export function ProfessionalEvolutionTab() {
  const { toast } = useToast();
  const db = useFirestore();
  const { user } = useUser();
  const [activeProfessional, setActiveProfessional] = React.useState<ProfessionalRole>("medico");
  const [checklistProgress, setChecklistProgress] = React.useState<Record<string, boolean>>({});
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [timerActive, setTimerActive] = React.useState(false);
  const [startTime, setStartTime] = React.useState<Date | null>(null);
  const [elapsedSeconds, setElapsedSeconds] = React.useState(0);

  // Contador de atendimentos reais do dia
  const attendanceQuery = useMemoFirebase(() => {
    if (!db) return null;
    const today = new Date().toISOString().split('T')[0];
    return query(
      collection(db, "atendimentos_aso"),
      where("data_emissao", ">=", today),
      limit(100)
    );
  }, [db]);
  const { data: dailyAttendances } = useCollection(attendanceQuery);

  React.useEffect(() => {
    let interval: any;
    if (timerActive) {
      interval = setInterval(() => {
        setElapsedSeconds(prev => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [timerActive]);

  const handleToggleCheck = (id: string) => {
    setChecklistProgress(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const getPercent = (profKey: ProfessionalRole) => {
    const items = PROFESSIONAL_EVOLUTION[profKey].checklist;
    const checked = items.filter(item => checklistProgress[item.id]).length;
    return Math.round((checked / items.length) * 100);
  };

  const handleToggleTimer = () => {
    if (!timerActive) {
      setStartTime(new Date());
      setTimerActive(true);
      toast({ title: "Plantão Iniciado", description: `Início do controle de horas para ${PROFESSIONAL_EVOLUTION[activeProfessional].title}.` });
    } else {
      setTimerActive(false);
      toast({ title: "Plantão Pausado", description: "O tempo de atividade foi registrado no cache local." });
    }
  };

  const formatTime = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const currentPercent = getPercent(activeProfessional);
  const attendanceCount = dailyAttendances?.length || 0;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 animate-in slide-in-from-bottom-4 duration-500">
      <div className="lg:col-span-1 space-y-3">
        <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest ml-4 mb-4">Time SESMT Alocado</p>
        {(Object.keys(PROFESSIONAL_EVOLUTION) as ProfessionalRole[]).map((key) => {
          const prof = PROFESSIONAL_EVOLUTION[key];
          const Icon = prof.icon;
          const isActive = activeProfessional === key;
          const progress = getPercent(key);
          
          return (
            <Card 
              key={key} 
              className={cn(
                "cursor-pointer border-none shadow-sm transition-all duration-300 rounded-2xl overflow-hidden",
                isActive ? "ring-2 ring-primary bg-white scale-[1.02] shadow-lg" : "bg-slate-50 opacity-60 hover:opacity-100"
              )}
              onClick={() => setActiveProfessional(key)}
            >
              <CardContent className="p-4 flex items-center gap-4">
                <div className={cn("p-2.5 rounded-xl", isActive ? "bg-primary text-white" : prof.bg + " " + prof.color)}>
                  <Icon className="size-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-black text-primary uppercase truncate leading-none">{prof.title}</p>
                  <p className="text-[8px] font-bold text-slate-400 mt-1 uppercase">Meta: {prof.contractHours}h/dia</p>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      <div className="lg:col-span-3 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="border-none shadow-sm bg-white rounded-3xl p-6 flex flex-col justify-between">
            <div className="space-y-2">
              <p className="text-[9px] font-black uppercase text-slate-400 tracking-widest">Tempo em Atividade</p>
              <h3 className="text-2xl font-black text-primary font-mono">{formatTime(elapsedSeconds)}</h3>
            </div>
            <Button 
              size="sm" 
              onClick={handleToggleTimer}
              className={cn(
                "mt-4 rounded-xl font-black uppercase text-[9px] gap-2 h-9",
                timerActive ? "bg-red-50 text-red-600 hover:bg-red-100" : "bg-emerald-50 text-emerald-700 hover:bg-emerald-100"
              )}
            >
              {timerActive ? <Square className="size-3" /> : <Play className="size-3" />}
              {timerActive ? "Encerrar Registro" : "Iniciar Plantão"}
            </Button>
          </Card>

          <Card className="border-none shadow-sm bg-white rounded-3xl p-6 flex flex-col justify-between">
            <div className="space-y-2">
              <p className="text-[9px] font-black uppercase text-slate-400 tracking-widest">Atendimentos (Hoje)</p>
              <h3 className="text-2xl font-black text-blue-600">{attendanceCount} Pacientes</h3>
            </div>
            <Badge className="mt-4 bg-blue-50 text-blue-700 border-none font-black text-[8px] w-fit">Live Sync</Badge>
          </Card>

          <Card className="border-none shadow-sm bg-white rounded-3xl p-6 flex flex-col justify-between">
            <div className="space-y-2">
              <p className="text-[9px] font-black uppercase text-slate-400 tracking-widest">Conformidade Plantão</p>
              <h3 className="text-2xl font-black text-emerald-600">{currentPercent}%</h3>
            </div>
            <div className="mt-4 h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
               <div className="h-full bg-emerald-500 transition-all" style={{ width: `${currentPercent}%` }} />
            </div>
          </Card>
        </div>

        <Card className="card-shadow border-none bg-white rounded-[2.5rem] overflow-hidden">
          <CardHeader className="bg-primary text-white p-8">
            <div className="flex justify-between items-start">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-white/10 rounded-2xl">
                  {React.createElement(PROFESSIONAL_EVOLUTION[activeProfessional].icon, { className: "size-8 text-accent" })}
                </div>
                <div>
                  <CardTitle className="text-2xl font-headline font-black uppercase tracking-tight">
                    {PROFESSIONAL_EVOLUTION[activeProfessional].title}
                  </CardTitle>
                  <CardDescription className="text-white/60 font-bold uppercase text-[10px] tracking-widest mt-1">
                    Checklist de Atividade Diária - SESMT
                  </CardDescription>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-8 space-y-6">
            <div className="space-y-4">
              {PROFESSIONAL_EVOLUTION[activeProfessional].checklist.map((item) => (
                <div 
                  key={item.id} 
                  className={cn(
                    "flex items-center gap-4 p-5 rounded-2xl border-2 transition-all cursor-pointer group",
                    checklistProgress[item.id] ? "bg-emerald-50 border-emerald-100" : "bg-white border-slate-50 hover:border-primary/10 shadow-sm"
                  )}
                  onClick={() => handleToggleCheck(item.id)}
                >
                  <Checkbox 
                    checked={!!checklistProgress[item.id]} 
                    onCheckedChange={() => handleToggleCheck(item.id)}
                    className="size-5 rounded-md border-slate-300"
                  />
                  <div className="flex-1">
                    <p className={cn("text-sm font-bold", checklistProgress[item.id] ? "text-emerald-800" : "text-primary")}>
                      {item.label}
                    </p>
                    <Badge variant="outline" className="text-[8px] font-black border-none bg-slate-100 text-slate-400 mt-1">Ref: {item.ref}</Badge>
                  </div>
                  {checklistProgress[item.id] && <CheckCircle2 className="size-5 text-emerald-500" />}
                </div>
              ))}
            </div>

            <div className="pt-6 border-t border-dashed flex flex-col sm:flex-row justify-between items-center gap-4">
              <p className="text-[10px] text-slate-400 italic font-medium max-w-sm">
                "Este registro é auditado e serve como base para a medição mensal do contrato CETESB."
              </p>
              <Button 
                disabled={isSubmitting || currentPercent < 100}
                className="h-14 px-10 bg-primary text-white font-black uppercase text-[10px] rounded-2xl shadow-xl gap-2"
              >
                {isSubmitting ? <Loader2 className="size-4 animate-spin" /> : <ClipboardList className="size-4 text-accent" />}
                Protocolar Atividade SESMT
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
