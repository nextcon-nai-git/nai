"use client"

import * as React from "react"
import { 
  DollarSign, 
  ArrowUpRight, 
  Database, 
  Download,
  Plus,
  CheckCircle2,
  TrendingUp,
  BarChart3,
  Scale,
  Sparkles,
  Loader2,
  Briefcase,
  Layers,
  TrendingDown,
  Brain,
  Key,
  FileUp,
  RefreshCw,
  MoreVertical,
  Building2,
  Settings2,
  UserCheck,
  Stethoscope,
  HeartPulse,
  Activity,
  FileText
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { useToast } from "@/hooks/use-toast"
import { analyzeFiscalScenario } from "@/ai/flows/fiscal-intelligence-flow"
import { useFirestore, useDoc, useMemoFirebase, useCollection, useUser } from "@/firebase"
import { doc, collectionGroup, query, orderBy, collection } from "firebase/firestore"
import { updateDocumentNonBlocking } from "@/firebase/non-blocking-updates"
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import { cn } from "@/lib/utils"
import { CETESB_SESMT_TEAM } from "@/lib/real-data"

const mockSmallTrend = [
  { v: 10 }, { v: 20 }, { v: 15 }, { v: 30 }, { v: 25 }, { v: 40 }
];

export default function FinancialModule() {
  const [activeTab, setActiveTab] = React.useState("contracts")
  const { toast } = useToast()
  const { user } = useUser()
  const db = useFirestore()
  const [isAnalyzingFiscal, setIsAnalyzingFiscal] = React.useState(false)
  const [fiscalAiResult, setFiscalFiscalAiResult] = React.useState<any>(null)
  
  const [ibptToken, setIbptToken] = React.useState("")
  const [isSavingToken, setIsSavingToken] = React.useState(false)

  const profileRef = useMemoFirebase(() => {
    if (!db || !user) return null
    return doc(db, "users", user.uid)
  }, [db, user])
  const { data: profile } = useDoc(profileRef)

  const isGlobalAdmin = React.useMemo(() => {
    if (!profile) return false;
    const role = (profile.role || '').toUpperCase();
    const companyId = profile.companyId;
    return ['SUPER_ADMIN', 'ENGINEER', 'DOCTOR', 'ADMIN'].includes(role) && (!companyId || companyId === "");
  }, [profile]);

  const contractsQuery = useMemoFirebase(() => {
    if (!db || !profile) return null
    if (isGlobalAdmin) return query(collectionGroup(db, "contracts"), orderBy("value", "desc"))
    if (profile.companyId) return query(collection(db, "companies", profile.companyId, "contracts"), orderBy("value", "desc"))
    return null;
  }, [db, profile, isGlobalAdmin])

  const { data: contracts, isLoading: loadingContracts } = useCollection(contractsQuery)

  const totalContractValue = React.useMemo(() => {
    return (contracts || []).reduce((acc, curr) => acc + (Number(curr.value) || 0), 0)
  }, [contracts])

  const handleAiFiscalAnalysis = async () => {
    setIsAnalyzingFiscal(true)
    try {
      const result = await analyzeFiscalScenario({
        companySegment: "Serviços de Engenharia e Saúde",
        location: profile?.companyName || "Unidade Local",
        monthlyRevenue: totalContractValue || 150000
      })
      setFiscalFiscalAiResult(result)
      toast({ title: "Análise Fiscal Concluída" })
    } catch (e) {
      toast({ variant: "destructive", title: "Erro na IA Fiscal" })
    } finally {
      setIsAnalyzingFiscal(false)
    }
  }

  const handleSaveIbptToken = () => {
    if (!db || !profile?.companyId || !ibptToken) return
    setIsSavingToken(true)
    const compRef = doc(db, "companies", profile.companyId)
    updateDocumentNonBlocking(compRef, {
      "fiscal_config.ibpt_token": ibptToken,
      "fiscal_config.last_ibpt_update": new Date().toISOString()
    })
    setTimeout(() => {
      setIsSavingToken(false)
      toast({ title: "Token IBPT Ativado", description: "Sincronização automática de impostos habilitada." })
    }, 800)
  }

  const summary = [
    { title: "Gestão Ativa", amount: totalContractValue.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }), trend: "Acumulado", icon: Briefcase, color: "text-blue-600", bg: "bg-blue-50" },
    { title: "ROI Segurança", amount: "+R$ 142k", trend: "Previsto 2026", icon: TrendingDown, color: "text-accent", bg: "bg-accent/5" },
    { title: "A Receber", amount: "R$ 142.500", trend: "Parcelado", icon: ArrowUpRight, color: "text-blue-600", bg: "bg-blue-50" },
    { title: "Sincronização", amount: isGlobalAdmin ? "Rede Global" : "Unidade", trend: "Multiapp", icon: Layers, color: "text-purple-600", bg: "bg-purple-50" },
  ]

  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <h1 className="text-3xl font-headline font-black text-primary tracking-tight uppercase leading-none">ERP Financeiro Nextcon</h1>
          <p className="text-muted-foreground font-medium uppercase text-[9px] tracking-widest">Inteligência Fiscal e Governança Bancária 2026.</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2 border-primary text-primary h-11 px-6 rounded-xl font-bold uppercase text-[10px]" onClick={() => setActiveTab("sesmt")}>
            <UserCheck className="size-4" /> Gestão SESMT
          </Button>
          <Button className="bg-accent text-primary hover:bg-accent/90 gap-2 h-11 px-6 shadow-lg font-black uppercase text-[10px] tracking-widest rounded-xl">
            <Plus className="size-4" /> Lançar Avulso
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {summary.map((item, idx) => {
          const Icon = item.icon;
          return (
            <Card key={item.title} className="border-none shadow-sm bg-white rounded-2xl overflow-hidden group hover:ring-2 ring-primary/5 transition-all relative">
              <div className="absolute inset-0 opacity-10 pointer-events-none">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={idx % 2 === 0 ? mockSmallTrend : [...mockSmallTrend].reverse()}>
                    <Area type="monotone" dataKey="v" stroke="#001F3F" fill="#001F3F" strokeWidth={1} dot={false} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
              <CardContent className="pt-6 relative z-10">
                <div className="flex items-center justify-between mb-4">
                  <div className={`p-2.5 rounded-xl ${item.bg}`}>
                    <Icon className={`h-5 w-5 ${item.color}`} />
                  </div>
                  <Badge variant="outline" className="text-[8px] font-black uppercase tracking-tighter">{item.trend}</Badge>
                </div>
                <p className="text-[9px] font-black uppercase text-slate-400 tracking-widest mb-1">{item.title}</p>
                <h2 className="text-xl font-black text-primary font-headline tabular-nums">{item.amount}</h2>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <div className="overflow-x-auto pb-2 scrollbar-thin">
          <TabsList className="flex w-fit bg-muted/50 p-1.5 rounded-2xl h-16">
            <TabsTrigger value="contracts" className="rounded-xl gap-2 text-[10px] font-black uppercase tracking-widest px-6 shrink-0">
              <Briefcase className="size-4" /> Contratos Globais
            </TabsTrigger>
            <TabsTrigger value="sesmt" className="rounded-xl gap-2 text-[10px] font-black uppercase tracking-widest px-6 shrink-0">
              <UserCheck className="size-4" /> Alocados SESMT
            </TabsTrigger>
            <TabsTrigger value="fiscal" className="rounded-xl gap-2 text-[10px] font-black uppercase tracking-widest px-6 shrink-0 text-accent">
              <Scale className="size-4" /> Governança 2026
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="sesmt" className="mt-8 space-y-6">
          <Card className="card-shadow border-none bg-white rounded-[2.5rem] overflow-hidden">
            <CardHeader className="bg-slate-50 border-b p-8">
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle className="text-lg font-black text-primary uppercase">Guarda de Contratos SESMT (PJ)</CardTitle>
                  <CardDescription className="text-[10px] font-bold uppercase tracking-widest">Controle de alocação e horas contratadas por especialista.</CardDescription>
                </div>
                <Badge className="bg-primary text-white font-black uppercase text-[10px] px-4 h-8">CETESB 2026</Badge>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader className="bg-slate-50/50 text-[10px] uppercase font-black">
                  <TableRow>
                    <TableHead className="pl-8">Profissional / Cargo</TableHead>
                    <TableHead>Contrato ID</TableHead>
                    <TableHead>Jornada Diária</TableHead>
                    <TableHead>Regime</TableHead>
                    <TableHead className="pr-8 text-right">Arquivo</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {CETESB_SESMT_TEAM.map((prof) => (
                    <TableRow key={prof.id} className="hover:bg-slate-50/50 transition-colors">
                      <TableCell className="pl-8 py-6">
                        <div className="flex items-center gap-4">
                          <div className={cn(
                            "size-10 rounded-xl flex items-center justify-center text-white shadow-inner",
                            prof.role === 'DOCTOR' ? "bg-blue-600" : prof.role === 'ENGINEER' ? "bg-emerald-600" : "bg-red-600"
                          )}>
                            {prof.role === 'DOCTOR' ? <Stethoscope size={18} /> : prof.role === 'ENGINEER' ? <Activity size={18} /> : <HeartPulse size={18} />}
                          </div>
                          <div>
                            <p className="font-black text-xs text-primary uppercase">{prof.name}</p>
                            <p className="text-[9px] text-slate-400 font-bold uppercase">{prof.specialty}</p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="font-mono text-xs text-primary">{prof.contractId}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="bg-slate-50 border-slate-200 text-slate-600 font-black h-6 px-3">{prof.dailyHours}h / dia</Badge>
                      </TableCell>
                      <TableCell>
                        <span className="text-[10px] font-bold text-slate-500 uppercase">{prof.contractType}</span>
                      </TableCell>
                      <TableCell className="pr-8 text-right">
                        <Button variant="ghost" size="sm" className="h-9 px-4 rounded-xl border border-dashed border-slate-200 text-[9px] font-black uppercase gap-2 hover:bg-primary/5">
                           <FileText className="size-3.5" /> Ver PDF
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="contracts" className="mt-8">
          <Card className="card-shadow border-none bg-white rounded-[2.5rem] overflow-hidden">
            <CardHeader className="bg-slate-50 border-b py-6 px-8 flex flex-row items-center justify-between">
              <div>
                <CardTitle className="text-lg font-black text-primary uppercase">Faturamento Global</CardTitle>
                <CardDescription className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Status dos contratos vigentes.</CardDescription>
              </div>
              <Button variant="outline" size="sm" className="h-10 text-[9px] font-black uppercase border-primary/10">Faturar Lote</Button>
            </CardHeader>
            <CardContent className="p-0">
              {loadingContracts ? (
                <div className="p-20 text-center flex flex-col items-center gap-4">
                  <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Sincronizando Faturamento...</p>
                </div>
              ) : contracts && contracts.length > 0 ? (
                <Table>
                  <TableHeader className="bg-slate-50/50 text-[10px] uppercase font-black">
                    <TableRow>
                      <TableHead className="pl-8">Cliente / Unidade</TableHead>
                      <TableHead>Valor Mensal</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right pr-8">Ação</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {contracts.map((item, i) => (
                      <TableRow key={i} className="hover:bg-slate-50 transition-colors">
                        <TableCell className="pl-8">
                          <p className="font-black text-xs text-primary uppercase">{item.companyName || "Cliente"}</p>
                          <p className="text-[9px] text-slate-400 uppercase font-bold">{item.title}</p>
                        </TableCell>
                        <TableCell className="font-black text-xs text-primary tabular-nums">
                          {item.value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                        </TableCell>
                        <TableCell>
                          <Badge className="bg-accent/10 text-accent text-[8px] font-black uppercase border-none px-3">Ativo</Badge>
                        </TableCell>
                        <TableCell className="text-right pr-8">
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-400"><MoreVertical className="size-4" /></Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="p-32 text-center opacity-20 flex flex-col items-center gap-4">
                  <Building2 size={64} className="text-primary" />
                  <p className="font-black uppercase text-xs tracking-widest">Nenhum contrato ativo localizado</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
