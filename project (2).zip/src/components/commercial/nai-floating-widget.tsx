
"use client";

import * as React from "react";
import { X, Sparkles, Zap, Loader2, ArrowRight, Bot, ShoppingCart, HardHat, Stethoscope } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import Link from "next/link";
import Image from "next/image";
import { Button } from "@/components/ui/button";

const NAI_AVATAR_URL = "https://firebasestorage.googleapis.com/v0/b/studio-8439299034-125c7.firebasestorage.app/o/logo%2FAvatar%20Nextcon%20NAI.png?alt=media&token=1bd23213-6ca1-427b-bbb2-41fa944ae861";

const AGENT_CONFIG = {
  header: {
    title: "NAI",
    subtitle: "Inteligência Estratégica em SST"
  },
  skills: [
    {
      id: "comercial",
      title: "1. Comercial - Gerador de Propostas",
      desc: "Orçamentos inteligentes e análise estratégica de viabilidade SST.",
      icon: ShoppingCart,
      color: "text-accent"
    },
    {
      id: "seguranca",
      title: "2. Segurança do Trabalho",
      desc: "Análise técnica de PGR, GRO e Normas Regulamentadoras (NRs).",
      icon: HardHat,
      color: "text-orange-600"
    },
    {
      id: "engenharia",
      title: "3. Engenharia de Segurança",
      desc: "Gestão de PCMSO, ASO Digital e Vigilância Epidemiológica.",
      icon: Stethoscope,
      color: "text-blue-600"
    }
  ],
  welcome_msg: "Olá! Sou a NAI. Estou aqui para estruturar sua conformidade técnica e comercial com o mais alto rigor normativo de 2026."
};

export function NaiFloatingWidget() {
  const [isOpen, setIsOpen] = React.useState(false);

  const handleToggle = () => setIsOpen(!isOpen);

  return (
    <div className="fixed bottom-6 right-6 z-[100] flex flex-col items-end gap-4">
      {isOpen && (
        <Card className="w-[380px] border-none shadow-2xl rounded-[2.5rem] overflow-hidden animate-in slide-in-from-bottom-4 duration-300 bg-white">
          <CardHeader className="bg-primary text-white p-8 relative overflow-hidden">
            <div className="absolute top-0 right-0 p-4 opacity-10"><Bot className="size-32" /></div>
            <button onClick={() => setIsOpen(false)} className="absolute top-6 right-6 p-1.5 hover:bg-white/10 rounded-xl transition-colors z-20">
              <X className="size-5" />
            </button>
            <div className="flex items-center gap-5 relative z-10">
              <div className="size-14 rounded-2xl bg-[#090e24] flex items-center justify-center border-2 border-white/20 overflow-hidden relative shadow-2xl">
                <Image 
                  src={NAI_AVATAR_URL} 
                  alt="NAI" 
                  fill
                  className="object-cover" 
                  priority
                />
              </div>
              <div>
                <CardTitle className="text-lg font-black uppercase tracking-tight font-headline">{AGENT_CONFIG.header.title}</CardTitle>
                <CardDescription className="text-[10px] font-black text-accent uppercase tracking-[0.2em]">{AGENT_CONFIG.header.subtitle}</CardDescription>
              </div>
            </div>
          </CardHeader>

          <CardContent className="p-8 max-h-[500px] overflow-y-auto scrollbar-thin space-y-8 text-left">
            <div className="bg-slate-50 p-5 rounded-[2rem] rounded-tl-none border-l-4 border-accent shadow-inner relative">
              <Sparkles className="absolute -top-2 -right-2 size-5 text-accent animate-pulse" />
              <p className="text-xs italic text-slate-600 font-bold leading-relaxed">
                "{AGENT_CONFIG.welcome_msg}"
              </p>
            </div>

            <div className="space-y-4">
              <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest ml-1">Especialidades Ativas:</p>
              {AGENT_CONFIG.skills.map((skill) => {
                const Icon = skill.icon;
                return (
                  <div key={skill.id} className="p-4 bg-white border border-slate-100 rounded-2xl shadow-sm hover:border-primary/20 transition-all group flex gap-4 items-start">
                    <div className={cn("p-2.5 rounded-xl bg-slate-50 transition-colors group-hover:bg-primary group-hover:text-white shadow-inner", skill.color)}>
                      <Icon className="size-5" />
                    </div>
                    <div>
                      <h4 className="text-[11px] font-black text-primary uppercase mb-1">{skill.title}</h4>
                      <p className="text-[10px] text-slate-400 font-medium leading-tight">{skill.desc}</p>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="pt-6 border-t border-dashed space-y-4">
              <Button asChild className="w-full h-14 bg-primary text-white font-black uppercase text-[10px] tracking-widest rounded-2xl shadow-xl gap-2 hover:scale-[1.02] transition-transform">
                <Link href="/knowledge-base" onClick={() => setIsOpen(false)}>
                  Falar com o Cérebro IA <ArrowRight className="size-3" />
                </Link>
              </Button>
              <p className="text-[8px] font-black text-slate-300 text-center uppercase tracking-[0.3em]">Nextcon Intelligence v2.6</p>
            </div>
          </CardContent>
        </Card>
      )}

      <button 
        onClick={handleToggle} 
        className={cn(
          "h-16 px-8 rounded-full shadow-2xl transition-all duration-500 flex items-center gap-3 hover:scale-105 active:scale-90 group overflow-hidden border-2 border-white/20", 
          isOpen ? "bg-primary text-white" : "gradient-nextcon text-white"
        )}
      >
        <div className="relative size-10 rounded-full overflow-hidden border-2 border-white/20 bg-[#090e24] flex items-center justify-center shrink-0">
          <Image src={NAI_AVATAR_URL} alt="NAI" fill className="object-cover" sizes="40px" />
          {!isOpen && <span className="absolute top-0 right-0 size-2.5 bg-accent rounded-full border-2 border-primary animate-ping" />}
        </div>
        <span className="font-black uppercase text-xs tracking-widest">{isOpen ? "Fechar" : "NAI"}</span>
      </button>
    </div>
  );
}
