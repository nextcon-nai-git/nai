
"use client";

import * as React from "react";
import { Stethoscope, Activity, Droplet, Scale, Accessibility, Bone, Search, Baby, HeartPulse, Brain } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { REAL_CLINICAL_RECORDS } from "@/lib/real-data";

const iconMap: Record<string, any> = {
  Activity, Droplet, Scale, Accessibility, Bone, Search, Baby, HeartPulse, Brain
};

export function StructuredRecordTab() {
  const [selectedPatientId, setSelectedPatientId] = React.useState<string>(REAL_CLINICAL_RECORDS[0].patientId);
  const activeClinicalRecord = REAL_CLINICAL_RECORDS.find(r => r.patientId === selectedPatientId);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 animate-in slide-in-from-right-4 duration-500">
      <div className="lg:col-span-1 space-y-3">
        <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest ml-4 mb-4">Escolha do Paciente</p>
        {REAL_CLINICAL_RECORDS.map((record) => (
          <button
            key={record.patientId}
            onClick={() => setSelectedPatientId(record.patientId)}
            className={cn(
              "w-full text-left p-5 rounded-[2rem] transition-all flex flex-col gap-1 border-2",
              selectedPatientId === record.patientId 
                ? "bg-white border-primary shadow-xl ring-4 ring-primary/5" 
                : "bg-slate-50 border-transparent opacity-60 hover:opacity-100"
            )}
          >
            <p className="text-xs font-black text-primary uppercase leading-tight">{record.name}</p>
            <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Idade: {record.age} | Sexo: {record.sex}</p>
          </button>
        ))}
      </div>

      <div className="lg:col-span-3 space-y-6">
        <Card className="card-shadow border-none bg-white rounded-[3rem] overflow-hidden">
          <CardHeader className="bg-[#001F3F] text-white p-10 relative overflow-hidden">
            <div className="absolute top-0 right-0 p-8 opacity-10"><Stethoscope className="size-48 text-accent" /></div>
            <div className="relative z-10">
              <div className="flex items-center gap-4 mb-4">
                <div className="size-16 rounded-[1.5rem] bg-white/10 flex items-center justify-center text-3xl font-black border border-white/20">
                  {activeClinicalRecord?.name.substring(0, 2).toUpperCase()}
                </div>
                <div>
                  <h2 className="text-3xl font-headline font-black uppercase tracking-tight">{activeClinicalRecord?.name}</h2>
                  <Badge className="bg-accent text-primary font-black uppercase text-[10px] mt-1 h-6 px-3">Linhas de Cuidado Ativas NAI</Badge>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-10">
            <div className="space-y-8">
              {activeClinicalRecord?.lines.map((line, idx) => {
                const Icon = iconMap[line.icon] || Activity;
                return (
                  <div key={idx} className="group animate-in slide-in-from-bottom-2" style={{ animationDelay: `${idx * 100}ms` }}>
                    <div className="flex gap-6 items-start">
                      <div className="p-4 bg-slate-50 rounded-2xl text-primary group-hover:bg-primary group-hover:text-white transition-all shadow-inner shrink-0">
                        <Icon className="size-6" />
                      </div>
                      <div className="flex-1 space-y-3">
                        <div className="flex items-center gap-3">
                          <h4 className="text-sm font-black text-primary uppercase tracking-tight leading-none">{line.category}</h4>
                          <Badge variant="outline" className="text-[8px] font-black uppercase border-primary/10 text-slate-400">Linha de Cuidado Ativa</Badge>
                        </div>
                        <div className="p-4 bg-slate-50/50 rounded-2xl border border-slate-100 space-y-2">
                          <div className="flex gap-2">
                            <span className="text-[9px] font-black uppercase text-slate-400">Métrica:</span>
                            <span className="text-[11px] font-bold text-primary">{line.metric}</span>
                          </div>
                          <div className="flex gap-2 items-start">
                            <span className="text-[9px] font-black uppercase text-accent shrink-0 mt-0.5">Conduta NAI:</span>
                            <span className="text-[11px] font-medium text-slate-600 leading-relaxed italic">"{line.conduct}"</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    {idx < activeClinicalRecord.lines.length - 1 && (
                      <div className="h-8 w-px bg-slate-100 ml-9 my-2" />
                    )}
                  </div>
                )
              })}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
