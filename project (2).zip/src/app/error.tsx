
'use client';

import * as React from 'react';
import { Button } from '@/components/ui/button';
import { AlertCircle, RefreshCcw, ShieldAlert, Zap } from 'lucide-react';

/**
 * Error boundary agressivo para a plataforma NAI v2.7.
 * Implementa isolamento de falhas (Sandboxing) para componentes de IA.
 */
export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  React.useEffect(() => {
    // Log silencioso para o servidor de telemetria interna
    if (process.env.NODE_ENV !== 'production') {
      console.error('Sandboxed Failure:', error);
    }
  }, [error]);

  const handleReset = () => {
    if (reset && typeof reset === 'function') {
      try {
        reset();
      } catch (e) {
        window.location.reload();
      }
    } else {
      window.location.reload();
    }
  };

  const isAiFailure = error?.message?.includes('Genkit') || error?.message?.includes('AI');

  return (
    <div className="flex min-h-[60vh] w-full flex-col items-center justify-center p-10 text-center animate-in fade-in zoom-in-95 duration-500">
      <div className="relative mb-8">
        <div className="size-24 bg-red-50 rounded-[2.5rem] flex items-center justify-center text-red-600 shadow-inner">
          <AlertCircle size={48} />
        </div>
        <div className="absolute -top-2 -right-2 p-2 bg-white rounded-xl shadow-lg border border-red-100">
          <ShieldAlert size={20} className="text-red-500" />
        </div>
      </div>
      
      <div className="space-y-4 max-w-lg">
        <h2 className="text-3xl font-black text-primary uppercase font-headline tracking-tighter leading-none">
          {isAiFailure ? 'Instabilidade Neural' : 'Interrupção de Fluxo'}
        </h2>
        <p className="text-slate-500 text-sm leading-relaxed font-medium italic">
          {isAiFailure 
            ? 'O motor de processamento assíncrono da NAI encontrou uma barreira. Os dados foram salvos no cache de resiliência e a tarefa será reprocessada.' 
            : 'Detectamos uma instabilidade no carregamento deste painel. O isolamento de falhas evitou que o restante do sistema fosse afetado.'}
        </p>
      </div>

      <div className="mt-10 flex flex-col sm:flex-row gap-4">
        <Button variant="outline" onClick={() => window.location.reload()} className="h-14 px-8 rounded-2xl border-primary text-primary font-black uppercase text-[10px] tracking-widest gap-2 shadow-sm">
          <RefreshCcw size={16} /> Reiniciar Portal
        </Button>
        <Button onClick={handleReset} className="h-14 px-10 bg-primary text-white font-black uppercase text-[10px] tracking-widest rounded-2xl shadow-xl shadow-primary/20 gap-2">
          <Zap size={16} className="text-accent" /> Tentar Recuperação Local
        </Button>
      </div>

      <div className="mt-12 p-6 bg-slate-50 rounded-[2rem] border-2 border-dashed border-slate-200 max-w-xl w-full">
         <p className="text-[9px] font-black uppercase text-slate-400 tracking-widest mb-2">Diagnóstico Técnico:</p>
         <p className="text-[10px] font-mono text-red-500 break-all opacity-70">
           {error?.message || 'CRITICAL_SGI_SANDBOX_FAILURE'}
         </p>
      </div>
    </div>
  );
}
