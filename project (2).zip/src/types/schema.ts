/**
 * NEXTCON PLATFORM - ENTERPRISE SCHEMA 2026
 * Core data structures for the Risk & Life Operating System.
 * Optimized for multi-tenant subcollections.
 */

export type RiskCategory = 'fisico' | 'quimico' | 'biológico' | 'ergonomico' | 'acidente';
export type TaskStatus = 'to_review' | 'sent' | 'approved' | 'implementation' | 'started' | 'todo' | 'doing' | 'review' | 'done' | 'archived' | 'efficacy_check';
export type Priority = 'low' | 'medium' | 'high' | 'critical';
export type TaskType = 'pgr' | 'pcmso' | 'ltcat' | 'treinamento' | 'esocial' | 'iot_check' | 'vistoria' | 'comercial' | 'rnc' | 'ambiental' | 'emergencia' | 'faturamento';

export type EsocialStatus = 'Pendente' | 'Processando' | 'Enviado' | 'Erro' | 'Bloqueado Firewall';

export interface ActionResult<T = any> {
  sucesso: boolean;
  mensagem?: string;
  erro?: string;
  dados?: T;
  relatorioId?: string;
  analise?: T;
  orcamento?: T;
  link_meet?: string;
  id_consulta?: string;
  simulado?: boolean;
}

export interface UserProfile {
  id: string;
  name: string;
  role: 'SUPER_ADMIN' | 'CLIENT_ADMIN' | 'ENGINEER' | 'DOCTOR' | 'PROVIDER';
  email: string;
  companyId?: string;
  companyName?: string;
  certificate_info?: any;
  servedCompanies?: string[];
  crm?: string;
  ufCrm?: string;
}

export interface OpsTask {
  id: string;
  title: string;
  type: TaskType;
  status: TaskStatus;
  priority: Priority;
  companyId: string;
  companyName: string;
  progress?: number;
  lastComment?: string;
  cnae?: string;
  riskDegree?: number;
  isInvoiced?: boolean;
  location?: string;
  tags?: string[];
  checklist?: Array<{ text: string; checked: boolean; mandatory?: boolean }>;
  createdAt: string;
  dueDate: string;
}

/**
 * Payload completo para o evento eSocial S-2220 (Monitoramento da Saúde do Trabalhador)
 */
export interface S2220Event {
  evtMonit: {
    id: string;
    ideEmpregador: {
      tpInsc: 1;
      nrInsc: string; // CNPJ Limpo
    };
    ideTrabalhador: {
      cpfTrab: string;
      matricula: string;
    };
    aso: {
      dtAso: string;
      tpAso: 1 | 2 | 3 | 4 | 5;
      resAso: 1 | 2;
      exame: Array<{
        dtExm: string;
        procExm: string;
        indResult: 1 | 2 | 3 | 4;
        ordExme: 1;
      }>;
      medico: {
        nmMed: string;
        nrCrm: string;
        ufCrm: string;
      };
    };
  };
}

export interface AsoAttendance extends S2220Event {
  id: string;
  employeeId: string;
  employeeName: string;
  companyId: string;
  data_emissao: string;
  resultado: 'Apto' | 'Inapto';
  status_esocial: EsocialStatus;
  signature_info?: any;
  protocolo_governo?: string;
  createdAt: any;
}

export interface MedicalAppointment {
  id: string;
  colaborador_id: string;
  colaborador_nome: string;
  companyId: string;
  data_hora: string;
  tipo: string;
  status: 'Agendado' | 'Em Espera' | 'Em Atendimento' | 'Concluído';
  check_in_realizado: boolean;
  check_in_at?: string;
}

export interface Employee {
  id: string;
  name: string;
  cpf: string;
  companyId: string;
  job_role: {
    title: string;
    cbo?: string;
  };
  status: 'active' | 'leave' | 'fired';
  createdAt: string;
  lastAsoDate?: string;
  nextAsoDate?: string;
  fitnessStatus?: 'Apto' | 'Inapto' | 'Pendente';
  healthRisks?: string[];
  isHeightWork?: boolean; // Tag para validação NR-35
}
