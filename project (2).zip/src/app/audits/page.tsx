"use client"

import * as React from "react"
import { 
  ClipboardCheck, 
  Layers, 
  Calendar, 
  CheckCircle2, 
  AlertTriangle, 
  Plus, 
  ArrowRight,
  ShieldCheck,
  Building2,
  FileText,
  Search,
  Zap,
  Filter,
  Loader2,
  User,
  Activity,
  PlayCircle,
  Save,
  ChevronRight,
  X,
  ClipboardList,
  Target
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger,
  DialogFooter
} from "@/components/ui/dialog"
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet"
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { ScrollArea } from "@/components/ui/scroll-area"
import { useUser, useFirestore, useCollection, useMemoFirebase, useDoc } from "@/firebase"
import { collection, query, orderBy, doc, where, collectionGroup } from "firebase/firestore"
import { addDocumentNonBlocking, updateDocumentNonBlocking } from "@/firebase/non-blocking-updates"
import { cn } from "@/lib/utils"
import { useSgi } from "@/contexts/sgi-context"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { z } from "zod"
import { useToast } from "@/hooks/use-toast"
import { ISO_CHECKLISTS } from "@/lib/iso-checklists"

const auditFormSchema = z.object({
  companyId: z.string().min(1, "Selecione a unidade"),
  scope: z.enum(["ISO 9001:2015", "ISO 14001:2015", "ISO 45001:2018"]),
  auditorName: z.string().min(3, "Informe o auditor"),
  date: z.string().min(1, "Selecione a data"),
  status: z.enum(["planned", "in_progress", "finished"]),
})

type AuditFormValues = z.infer<typeof auditFormSchema>

export default function IsoAudits() {
  const { toast } = useToast()
  const { user, role, companyId: userCompanyId } = useUser()
  const db = useFirestore()
  const { activeClientId } = useSgi()
  
  const [isCreateOpen, setIsCreateOpen] = React.useState(false)
  const [executingAudit, setExecutingAudit] = React.useState<any | null>(null)
  const [isSubmitting, setIsSubmitting] = React.useState(false)
  const [searchTerm, setSearchTerm] = React.useState("")
  const [checklistResponses, setChecklistResponses] = React.useState<Record<string, boolean>>({})

  const profileRef = useMemoFirebase(() => {
    if (!db || !user) return null
    return doc(db, "users", user.uid)
  }, [db, user])
  const { data: profile } = useDoc(profileRef)

  const isGlobalAdmin = React.useMemo(() => ['SUPER_ADMIN', 'ADMIN', 'ENGINEER'].includes(role || ''), [role])

  const auditsQuery = useMemoFirebase(() => {
    if (!db || activeClientId === "unauthorized") return null
    
    if (activeClientId === "all") {
      if (!isGlobalAdmin) return null;
      return query(collectionGroup(db, "audits"), orderBy("date", "desc"))
    }
    
    return query(collection(db, "companies", activeClientId, "audits"), orderBy("date", "desc"))
  }, [db, activeClientId, isGlobalAdmin])

  const { data: audits, isLoading } = useCollection(auditsQuery)

  const companiesQuery = useMemoFirebase(() => {
    if (!db || !role) return null;
    if (isGlobalAdmin) {
      return query(collection(db, "companies"), orderBy("name", "asc"));
    }
    if (userCompanyId) {
      return query(collection(db, "companies"), where("__name__", "==", userCompanyId));
    }
    return null;
  }, [db, isGlobalAdmin, userCompanyId, role]);

  const { data: companies } = useCollection(companiesQuery)

  const form = useForm<AuditFormValues>({
    resolver: zodResolver(auditFormSchema),
    defaultValues: {
      companyId: "",
      scope: "ISO 9001:2015",
      auditorName: "",
      date: new Date().toISOString().split('T')[0],
      status: "planned",
    },
  })

  React.useEffect(() => {
    if (profile?.companyId) {
      form.setValue("companyId", profile.companyId)
    }
  }, [profile, form])

  async function handleCreateAudit(values: AuditFormValues) {
    if (!db) return
    setIsSubmitting(true)
    try {
      const company = companies?.find(c => c.id === values.companyId)
      const auditRef = collection(db, "companies", values.companyId, "audits")
      
      await addDocumentNonBlocking(auditRef, {
        ...values,
        companyName: company?.name || "Unidade Técnica",
        createdAt: new Date().toISOString(),
        createdBy: user?.uid,
        companyId: values.companyId 
      })

      toast({ title: "Auditoria Protocolada", description: `Plano de inspeção ${values.scope} agendado.` })
      setIsCreateOpen(false)
      form.reset()
    } catch (e) {
      toast({ variant: "destructive", title: "Erro ao Salvar" })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleStartExecution = (audit: any) => {
    setExecutingAudit(audit)
    setChecklistResponses(audit.results || {})
    if (audit.status === 'planned' && db && audit.companyId) {
      updateDocumentNonBlocking(doc(db, "companies", audit.companyId, "audits", audit.id), {
        status: "in_progress"
      })
    }
  }

  const handleFinishAudit = async () => {
    if (!db || !executingAudit) return
    setIsSubmitting(true)
    try {
      await updateDocumentNonBlocking(doc(db, "companies", executingAudit.companyId, "audits", executingAudit.id), {
        status: "finished",
        results: checklistResponses,
        finishedAt: new Date().toISOString()
      })
      toast({ title: "Auditoria Finalizada", description: "O relatório de conformidade foi protocolado." })
      setExecutingAudit(null)
    } finally {
      setIsSubmitting(false)
    }
  }

  const filteredAudits = React.useMemo(() => {
    if (!audits) return []
    const term = searchTerm.toLowerCase()
    return audits.filter(a => 
      (a.companyName || "").toLowerCase().includes(term) || 
      (a.auditorName || "").toLowerCase().includes(term) ||
      (a.scope || "").toLowerCase().includes(term)
    )
  }, [audits, searchTerm])

  const activeChecklist = executingAudit ? ISO_CHECKLISTS[executingAudit.scope] : null

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1 text-left">
          <h1 className="text-3xl font-headline font-black text-primary tracking-tight uppercase leading-none">Gestão de Auditorias ISO</h1>
          <p className="text-muted-foreground font-medium uppercase text-[10px] tracking-widest flex items-center gap-2">
            <Layers className="size-3 text-accent" /> Checklists Normativos | Ciclo PDCA 2026.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Badge variant="outline" className="h-11 border-primary text-primary font-black uppercase text-[10px] bg-white px-4 flex items-center shadow-sm">
            <Building2 className="size-4 mr-2" />
            {activeClientId === 'all' ? "REDE GLOBAL" : (companies?.find(c => c.id === activeClientId)?.name || "UNIDADE ATIVA")}
          </Badge>
          
          <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
            <DialogTrigger asChild>
              <Button className="gradient-nextcon text-white h-11 px-8 rounded-xl font-black uppercase text-[10px] tracking-widest shadow-lg gap-2">
                <Plus className="size-4 text-accent" /> Nova Auditoria
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[550px] rounded-[2.5rem] border-none shadow-2xl p-0 overflow-hidden bg-white text-left">
              <DialogHeader className="p-8 bg-primary text-white space-y-2">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-white/10 rounded-lg text-accent"><ClipboardCheck className="size-5" /></div>
                  <DialogTitle className="text-xl font-headline font-black uppercase">Agendar Auditoria</DialogTitle>
                </div>
                <DialogDescription className="text-white/60 font-medium italic">
                  Defina o escopo normativo para iniciar o ciclo de conformidade.
                </DialogDescription>
              </DialogHeader>
              <div className="p-8">
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(handleCreateAudit)} className="space-y-5">
                    <FormField
                      control={form.control}
                      name="companyId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-[10px] font-black uppercase text-slate-400">Unidade Cliente</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value} disabled={!isGlobalAdmin && !!profile?.companyId}>
                            <FormControl><SelectTrigger className="h-12 bg-slate-50 border-none rounded-xl font-bold shadow-inner"><SelectValue placeholder="Selecione..." /></SelectTrigger></FormControl>
                            <SelectContent>
                              {companies?.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="scope"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-[10px] font-black uppercase text-slate-400">Escopo da Norma</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl><SelectTrigger className="h-12 bg-slate-50 border-none rounded-xl font-bold shadow-inner"><SelectValue /></SelectTrigger></FormControl>
                              <SelectContent>
                                <SelectItem value="ISO 9001:2015">ISO 9001:2015 (Qualidade)</SelectItem>
                                <SelectItem value="ISO 14001:2015">ISO 14001:2015 (Ambiental)</SelectItem>
                                <SelectItem value="ISO 45001:2018">ISO 45001:2018 (SSO)</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="date"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-[10px] font-black uppercase text-slate-400">Data Prevista</FormLabel>
                            <FormControl><Input type="date" {...field} className="h-12 bg-slate-50 border-none rounded-xl font-bold shadow-inner" /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="auditorName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-[10px] font-black uppercase text-slate-400">Nome do Auditor</FormLabel>
                          <FormControl><Input placeholder="Ex: Lucas Nextcon" {...field} className="h-12 bg-slate-50 border-none rounded-xl font-bold uppercase shadow-inner" /></FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Button type="submit" disabled={isSubmitting} className="w-full h-14 bg-primary text-white font-black uppercase text-xs tracking-widest rounded-2xl shadow-xl gap-3">
                      {isSubmitting ? <Loader2 className="size-5 animate-spin" /> : <CheckCircle2 className="size-5 text-accent" />}
                      Agendar Ciclo Normativo
                    </Button>
                  </form>
                </Form>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </header>

      <Card className="card-shadow border-none bg-white rounded-[2.5rem] overflow-hidden">
        <CardHeader className="bg-slate-50 border-b p-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="text-left w-full">
            <CardTitle className="text-lg font-black text-primary uppercase">Protocolos de Auditoria</CardTitle>
            <CardDescription className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Execute os checklists específicos de cada norma ISO.</CardDescription>
          </div>
          <div className="relative w-full md:w-80">
            <Search className="absolute left-3 top-2.5 size-4 text-slate-300" />
            <Input 
              placeholder="Filtrar por unidade ou norma..." 
              className="pl-10 h-10 border-none bg-white shadow-sm text-xs rounded-xl" 
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
            />
          </div>
        </CardHeader>
        <CardContent className="p-0 overflow-x-auto">
          {isLoading ? (
            <div className="py-24 flex flex-col items-center justify-center gap-4 text-primary">
              <Loader2 className="size-12 animate-spin opacity-20" />
              <p className="text-[10px] font-black uppercase tracking-widest">Sincronizando Base ISO...</p>
            </div>
          ) : (
            <Table>
              <TableHeader className="bg-slate-50/50">
                <TableRow>
                  <TableHead className="pl-8 text-[9px] font-black uppercase py-4">Unidade / Data</TableHead>
                  <TableHead className="text-[9px] font-black uppercase">Norma de Referência</TableHead>
                  <TableHead className="text-[9px] font-black uppercase">Auditor</TableHead>
                  <TableHead className="text-[9px] font-black uppercase text-center">Status</TableHead>
                  <TableHead className="pr-8 text-right">Ação</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredAudits.map((audit: any) => (
                  <TableRow key={audit.id} className="hover:bg-slate-50/50 transition-colors">
                    <TableCell className="pl-8 py-5">
                      <p className="text-xs font-bold text-primary uppercase">{audit.companyName}</p>
                      <p className="text-[9px] text-slate-400 font-bold mt-0.5">{new Date(audit.date).toLocaleDateString('pt-BR')}</p>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="text-[8px] font-black uppercase border-blue-100 text-blue-600 bg-blue-50 px-2 h-5">
                        {audit.scope}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <User className="size-3 text-slate-300" />
                        <p className="text-xs font-bold text-slate-600 uppercase">{audit.auditorName}</p>
                      </div>
                    </TableCell>
                    <TableCell className="text-center">
                      <Badge className={cn(
                        "text-[8px] font-black uppercase border-none px-3 h-5",
                        audit.status === 'finished' ? 'bg-emerald-100 text-emerald-700' :
                        audit.status === 'in_progress' ? 'bg-blue-100 text-blue-700 animate-pulse' : 'bg-slate-100 text-slate-400'
                      )}>
                        {audit.status === 'finished' ? "Finalizada" : audit.status === 'in_progress' ? "Em Curso" : "Planejada"}
                      </Badge>
                    </TableCell>
                    <TableCell className="pr-8 text-right">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-9 px-4 rounded-xl text-primary font-black uppercase text-[10px] gap-2 hover:bg-primary hover:text-white transition-all"
                        onClick={() => handleStartExecution(audit)}
                      >
                        {audit.status === 'finished' ? <FileText className="size-3.5" /> : <PlayCircle className="size-3.5" />}
                        {audit.status === 'finished' ? "Ver Resultados" : "Executar Checklist"}
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
                {filteredAudits.length === 0 && (
                  <TableRow><TableCell colSpan={5} className="py-24 text-center opacity-30 font-black uppercase text-[10px] tracking-widest">Nenhuma auditoria programada</TableCell></TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Sheet open={!!executingAudit} onOpenChange={(open) => !open && setExecutingAudit(null)}>
        <SheetContent className="sm:max-w-2xl p-0 border-none shadow-2xl flex flex-col">
          {executingAudit && activeChecklist && (
            <>
              <SheetHeader className="p-8 bg-[#001F3F] text-white relative shrink-0">
                <div className="absolute top-0 right-0 p-6 opacity-10"><ShieldCheck className="size-32 text-accent" /></div>
                <div className="relative z-10 text-left space-y-1">
                   <div className="flex items-center justify-between">
                     <Badge className="bg-accent text-primary font-black uppercase text-[8px] tracking-[0.2em]">{executingAudit.scope}</Badge>
                     <button onClick={() => setExecutingAudit(null)} className="p-2 hover:bg-white/10 rounded-xl transition-colors"><X className="size-5" /></button>
                   </div>
                   <SheetTitle className="text-2xl font-headline font-black uppercase tracking-tight text-white mt-4">{activeChecklist.title}</SheetTitle>
                   <SheetDescription className="text-white/60 font-medium italic text-xs">
                     Unidade: {executingAudit.companyName} | Auditor: {executingAudit.auditorName}
                   </SheetDescription>
                </div>
              </SheetHeader>

              <div className="flex-1 overflow-hidden flex flex-col bg-slate-50/50">
                <div className="p-8 pb-4 flex justify-between items-center px-8">
                   <div className="space-y-1">
                      <p className="text-[10px] font-black uppercase text-slate-400">Progresso da Auditoria</p>
                      <p className="text-lg font-black text-primary">
                        {Object.values(checklistResponses).filter(v => v === true).length} / {activeChecklist.items.length} Requisitos
                      </p>
                   </div>
                   <div className="size-16 rounded-full border-4 border-slate-100 flex items-center justify-center relative">
                      <span className="text-xs font-black text-primary">
                        {Math.round((Object.values(checklistResponses).filter(v => v === true).length / activeChecklist.items.length) * 100)}%
                      </span>
                   </div>
                </div>

                <ScrollArea className="flex-1 p-8 pt-0 scrollbar-thin">
                  <div className="space-y-6 pb-20">
                    {activeChecklist.items.map((item) => (
                      <Card key={item.id} className="border-none shadow-sm rounded-3xl overflow-hidden bg-white group hover:ring-2 ring-primary/5 transition-all">
                        <CardContent className="p-6 space-y-4">
                          <div className="flex justify-between items-start gap-4">
                             <div className="space-y-1 flex-1">
                               <div className="flex items-center gap-2">
                                 <Badge variant="outline" className="text-[8px] font-black uppercase bg-slate-50 border-slate-200">Requisito {item.id}</Badge>
                                 <span className="text-[9px] font-bold text-slate-400 uppercase tracking-tighter">{item.clause}</span>
                               </div>
                               <h4 className="text-sm font-bold text-primary leading-tight mt-2 text-left">{item.requirement}</h4>
                             </div>
                             <Checkbox 
                               id={`req-${item.id}`}
                               checked={!!checklistResponses[item.id]}
                               onCheckedChange={(val) => setChecklistResponses(prev => ({ ...prev, [item.id]: !!val }))}
                               disabled={executingAudit.status === 'finished'}
                               className="size-6 rounded-lg border-slate-200 data-[state=checked]:bg-emerald-500 data-[state=checked]:border-emerald-500"
                             />
                          </div>
                          <div className="p-4 bg-slate-50/50 rounded-2xl border border-slate-100 border-dashed text-left">
                             <p className="text-[10px] text-slate-500 italic leading-relaxed">
                               <span className="font-black uppercase text-[8px] text-primary/40 not-italic mr-1">Dica de Evidência:</span> 
                               {item.helpText}
                             </p>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </ScrollArea>
              </div>

              <div className="p-8 bg-white border-t shrink-0 space-y-4 shadow-[0_-10px_20px_-10px_rgba(0,0,0,0.05)]">
                {executingAudit.status !== 'finished' && (
                  <Button 
                    onClick={handleFinishAudit}
                    disabled={isSubmitting}
                    className="w-full h-16 bg-primary text-white font-black uppercase text-xs tracking-widest rounded-2xl shadow-xl gap-3"
                  >
                    {isSubmitting ? <Loader2 className="size-5 animate-spin" /> : <Save className="size-5 text-accent" />}
                    Finalizar e Protocolar Ciclo
                  </Button>
                )}
                <p className="text-[8px] font-black text-slate-300 text-center uppercase tracking-[0.4em]">Audit Compliance Protocol v3.0</p>
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>
    </div>
  )
}
