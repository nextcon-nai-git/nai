'use server';

/**
 * @fileOverview Server Action para carga de estrutura organizacional (Seed).
 * Utiliza o padrão NoSQL otimizado para o Front-end Flutter da Nextcon.
 */

import { initializeFirebase } from '@/firebase/init';
import { doc, writeBatch, collection } from 'firebase/firestore';
import { CETESB_ORG_STRUCTURE } from '@/lib/cetesb-org-data';
import { ActionResult } from '@/types/schema';

export async function seedCetesbOrganizationalStructure(): Promise<ActionResult> {
  const { firestore } = initializeFirebase();
  const batch = writeBatch(firestore);
  const companyId = CETESB_ORG_STRUCTURE.id;

  try {
    // 1. Itera sobre os locais (Prédios)
    for (const location of CETESB_ORG_STRUCTURE.locations) {
      const locationRef = doc(firestore, "companies", companyId, "locations", location.id);
      
      batch.set(locationRef, {
        name: location.name,
        companyId: companyId,
        updatedAt: new Date().toISOString()
      }, { merge: true });

      // 2. Itera sobre os setores de cada local
      for (const sector of location.sectors) {
        const sectorRef = doc(firestore, "companies", companyId, "locations", location.id, "sectors", sector.id);
        
        batch.set(sectorRef, {
          name: sector.name,
          floor: sector.floor,
          locationId: location.id,
          companyId: companyId,
          // Campos placeholders para o PGR
          ghe_id: null,
          riscos_identificados: [],
          total_colaboradores: 0,
          updatedAt: new Date().toISOString()
        }, { merge: true });
      }
    }

    await batch.commit();
    
    return {
      sucesso: true,
      mensagem: "Estrutura Organizacional Cetesb (Locais e Setores) injetada com sucesso."
    };

  } catch (error: any) {
    console.error("Erro no Seed Organizacional:", error);
    return {
      sucesso: false,
      mensagem: error.message || "Falha ao popular estrutura de locais e setores."
    };
  }
}
