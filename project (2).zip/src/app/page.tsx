"use client"

import * as React from "react"
import Link from "next/link"
import { 
  collection, 
  query, 
  orderBy,
  limit,
  doc,
  collectionGroup,
  where
} from "firebase/firestore"
import { useUser, useFirestore, useDoc, useCollection, useMemoFirebase } from '@/firebase'
import { useSgi } from "@/contexts/sgi-context"
import { cn } from "@/lib/utils"
import { 
  ShieldAlert, 
  Sparkles, 
  Building2, 
  Brain, 
  Zap, 
  Clock, 
  ChevronRight,
  Loader2,
  ShoppingCart,
  HardHat,
  HeartPulse,
  DollarSign,
  CheckCircle2
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function NaiUnifiedPlatform() {
  const { user, role } = useUser()
  const db = useFirestore()
  const { activeClientId } = useSgi()
  const [mounted, setMounted] = React.useState(false)

  React.useEffect(() => {
    setMounted(true)
  }, [])

  const isGlobalAdmin = React.useMemo(() => ['SUPER_ADMIN', 'ADMIN'].includes(role || ''), [role]);

  // Listeners reativos otimizados para subcoleções com trava de segurança
  const tasksQuery = useMemoFirebase(() => {
    if (!db || !role || activeClientId === "unauthorized") return null
    
    // Blinda a query contra acessos não autorizados à visão global
    if (activeClientId === "all") {
      if (!isGlobalAdmin) return null;
      return query(collectionGroup(db, "tasks"), orderBy("dueDate", "asc"), limit(8))
    }
    
    // Se estiver filtrado, utiliza a subcoleção direta (Alta Performance)
    return query(collection(db, "companies", activeClientId, "tasks"), orderBy("dueDate", "asc"), limit(8))
  }, [db, activeClientId, role, isGlobalAdmin])

  const { data: tasks, isLoading: loadingTasks } = useCollection(tasksQuery)

  const activeCompanyRef = useMemoFirebase(() => 
    !db || activeClientId === "all" || activeClientId === "unauthorized" ? null : doc(db, "companies", activeClientId),
    [db, activeClientId]
  )
  const { data: activeCompany } = useDoc(activeCompanyRef)

  if (!mounted) return null

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-6 border-b pb-6 text-left">
        <div>
          <h1 className="text-3xl font-black text-primary uppercase font-headline tracking-tight leading-none">Dashboard Master SGI</h1>
          <p className="text-muted-foreground font-bold uppercase text-[9px] tracking-[0.4em] mt-2">
            Engine v2.7 • {activeClientId === 'all' ? 'Rede Global' : (activeCompany?.name || 'Unidade Ativa')}
          </p>
        </div>
        <Badge className="bg-primary text-white font-black uppercase text-[10px] tracking-widest px-6 h-11 flex items-center shadow-lg">
          STATUS: {activeClientId === 'all' ? 'GLOBAL' : 'UNITÁRIO'}
        </Badge>
      </header>

      <div className="bg-slate-900/5 border border-primary/10 rounded-[2.5rem] p-6 flex items-start gap-5 relative overflow-hidden group text-left">
        <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:scale-110 transition-transform"><Sparkles className="size-24 text-primary" /></div>
        <div className="size-14 rounded-2xl bg-primary flex items-center justify-center shrink-0 shadow-lg text-white font-black text-xl">N</div>
        <div className="space-y-1 relative z-10">
          <h3 className="text-xs font-black uppercase tracking-widest text-primary flex items-center gap-2">
            <Brain className="size-4" /> NAI Expert Feedback
          </h3>
          <p className="text-sm font-medium leading-relaxed italic text-slate-700 max-w-4xl">
            "A arquitetura Multi-tenant v2.7 está ativa. Monitorando {tasks?.length || 0} ações críticas com isolamento de dados e conformidade eSocial."
          </p>
        </div>
      </div>

      <Tabs defaultValue="operacional" className="space-y-8">
        <TabsList className="grid grid-cols-1 md:grid-cols-3 bg-slate-100 p-1.5 rounded-[2rem] h-auto gap-2">
          <TabsTrigger value="comercial" className="rounded-2xl h-12 text-[10px] font-black uppercase tracking-widest">
            <ShoppingCart className="size-3.5 mr-2" /> Comercial
          </TabsTrigger>
          <TabsTrigger value="operacional" className="rounded-2xl h-12 text-[10px] font-black uppercase tracking-widest">
            <HardHat className="size-3.5 mr-2" /> Engenharia
          </TabsTrigger>
          <TabsTrigger value="saude" className="rounded-2xl h-12 text-[10px] font-black uppercase tracking-widest">
            <HeartPulse className="size-3.5 mr-2" /> Saúde
          </TabsTrigger>
        </TabsList>

        <TabsContent value="operacional" className="focus:outline-none space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
             {loadingTasks ? (
                <div className="col-span-full py-20 text-center"><Loader2 className="animate-spin mx-auto opacity-20" /></div>
             ) : tasks?.length ? tasks.map((task: any) => (
                <Card key={task.id} className="border-none shadow-sm bg-white rounded-2xl overflow-hidden hover:ring-2 ring-primary/5 transition-all border-l-[4px] border-l-blue-400 text-left">
                   <CardContent className="p-5 space-y-3">
                      <div className="flex justify-between items-start">
                        <Badge variant="outline" className="text-[7px] font-black uppercase border-slate-100">{task.type}</Badge>
                        <Badge className="bg-slate-50 text-slate-500 border-none text-[7px] font-black uppercase h-4 px-1.5">{task.status}</Badge>
                      </div>
                      <h4 className="text-[11px] font-black text-primary uppercase leading-tight line-clamp-2">{task.title}</h4>
                      <div className="pt-2 border-t border-slate-50 flex justify-between items-center text-[8px] font-black text-slate-400">
                        <span className="flex items-center gap-1"><Clock size={10} /> {task.dueDate ? new Date(task.dueDate).toLocaleDateString('pt-BR') : '---'}</span>
                        <ChevronRight size={10} />
                      </div>
                   </CardContent>
                </Card>
             )) : (
                <div className="col-span-full py-20 text-center opacity-30 flex flex-col items-center gap-4">
                   <CheckCircle2 className="size-10" />
                   <p className="text-[9px] font-black uppercase tracking-widest text-slate-400">Fila Limpa para esta Unidade</p>
                </div>
             )}
          </div>
        </TabsContent>

        <TabsContent value="comercial">
           <Card className="card-shadow border-none bg-[#090e24] text-white rounded-[2rem] p-12 relative overflow-hidden group text-left">
              <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:scale-110 transition-transform"><DollarSign size={80} className="text-accent" /></div>
              <div className="relative z-10 space-y-4">
                 <Badge className="bg-accent text-primary border-none font-black text-[8px] uppercase">Finanças Estratégicas</Badge>
                 <h3 className="text-xl font-black uppercase tracking-tight">Otimização de Custos SST</h3>
                 <p className="text-sm italic text-slate-300 max-w-lg">A redução do FAP é o maior ROI da gestão de riscos. Acompanhe a economia acumulada da rede.</p>
                 <Button asChild className="bg-accent text-primary font-black uppercase text-[10px] rounded-xl h-10 mt-4 px-6" variant="secondary">
                   <Link href="/comercial">Acessar Comercial</Link>
                 </Button>
              </div>
           </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}