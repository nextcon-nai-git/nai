/**
 * NEXTCON PLATFORM - BASE DE DADOS REAL 2026
 * Versão Expandida: Foco em Metalurgia (TESTE DB), Construção Civil (NATIVA) e Eletroportáteis (BRITÂNIA).
 */

import { Employee } from "@/types/schema";

export const REAL_COMPANIES = [
  {
    id: "TESTE_DB_2026",
    name: "A TESTE DB 2026 - METALURGIA AVANÇADA",
    cnpj: "00.000.000/0001-99",
    active: true,
    risk_degree: 4 as const,
    segment: "INDUSTRY",
    city: "Curitiba",
    state: "PR",
    address: "Av. Sete de Setembro, 2500 - Rebouças",
    scope: "Showcase Full: Engenharia, Saúde, Auditoria e Inteligência Fiscal",
    responsible_name: "Investidor de Elite",
    responsible_role: "Diretor Industrial",
  },
  {
    id: "NATIVA_EMPR",
    name: "NATIVA EMPREENDIMENTOS - CONSTRUÇÃO CIVIL",
    cnpj: "51.633.820/0001-51",
    active: true,
    risk_degree: 3 as const,
    segment: "CONSTRUCTION",
    city: "Guaratuba",
    state: "PR",
    address: "Av. Dr João Cândido, 755 - Centro",
    scope: "Gestão Integrada de Obras: Laguna & Mônaco",
    responsible_name: "Engenheiro Residente",
    responsible_role: "Gestor de Obras",
  },
  {
    id: "BRITANIA_JOINVILLE",
    name: "BRITÂNIA ELETRODOMÉSTICOS S.A.",
    cnpj: "76.492.701/0001-43",
    active: true,
    risk_degree: 3 as const,
    segment: "INDUSTRY",
    city: "Joinville",
    state: "SC",
    address: "Rua Dona Francisca, 12345 - Distrito Industrial",
    scope: "Auditoria Ergonômica e Epidemiológica - Fábrica 01",
    responsible_name: "Gerência Industrial",
    responsible_role: "Comitê COERGO",
  }
];

export const BRITANIA_AEP_DATA = {
  setor: "Linha de Montagem do Forno Elétrico",
  estatisticas: {
    totalPostos: 55,
    linhaPrincipal: 28,
    preLinha: 27,
    exposicaoSetor: 33.33
  },
  diretrizes: {
    pausa: "10 minutos a cada 2 horas",
    regra: "Recuperação de tendões e alívio postural"
  },
  postosCriticos: [
    { seq: 2, atv: "Retirar película", queixa: "Desconforto ponta dos dedos e edema", prio: "Moderado" },
    { seq: 7, atv: "Parafusar posterior", queixa: "Desconforto antebraço E e lombar", prio: "Substancial" },
    { seq: 28, atv: "Teste funcional", queixa: "Epicôndilo lateral e ombro D", prio: "Substancial" },
    { seq: 30, atv: "Colocar no isopor", queixa: "Punho E - Início de jornada", prio: "Moderado" }
  ]
};

export const REAL_EMPLOYEES: Employee[] = [
  { 
    id: "COL_PEDRO_SERRA", 
    name: "PEDRO SERRALHEIRO", 
    cpf: "111.222.333-44", 
    companyId: "TESTE_DB_2026", 
    job_role: { title: "Serralheiro Industrial" }, 
    status: "active", 
    createdAt: new Date().toISOString(),
    nextAsoDate: "2025-12-01", 
    fitnessStatus: "Apto",
    healthRisks: ["Ruído (Impacto)", "Fumos de Solda", "Radiação"],
  },
  { 
    id: "NAT_S01", 
    name: "JOÃO AJUDANTE", 
    cpf: "222.333.444-55", 
    companyId: "NATIVA_EMPR", 
    job_role: { title: "Servente 1" }, 
    status: "active", 
    createdAt: new Date().toISOString(),
    nextAsoDate: "2026-08-15",
    fitnessStatus: "Apto",
    healthRisks: ["Físicos", "Ergonômicos", "Acidentes"]
  }
];

export const INVESTOR_DEMO_DATA = {
  tasks: [
    {
      id: "demo_task_1",
      title: "Renovação PGR - Ciclo 2026/27",
      type: "pgr",
      status: "to_review",
      priority: "high",
      companyName: "A TESTE DB 2026",
      progress: 0,
      dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
    }
  ],
  employees: REAL_EMPLOYEES
};

export const BRITANIA_EXPERTISES = [
  { id: "EXP_BRIT_01", employeeName: "OPERADOR LINHA FORNO", caseNumber: "0012345-67", disease: "Epicondilite Lateral", value: 45000, status: "Em Análise" }
];

export const CETESB_SESMT_TEAM = [
  { id: "prof_1", name: "DR. RICARDO MED", specialty: "Médico do Trabalho", role: "DOCTOR", contractId: "PJ-MED-843", dailyHours: 8, contractType: "Alocado" }
];

export const REAL_CONTRACTS = [];
export const REAL_CLINICAL_RECORDS = [];
export const REAL_TRAININGS = [];
export const CETESB_OPERATION_CARDS = [];
