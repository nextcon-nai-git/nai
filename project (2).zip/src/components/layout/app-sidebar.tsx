
"use client"

import * as React from "react"
import { 
  CheckSquare, 
  LogOut,
  BarChart3,
  SearchCheck,
  ShieldCheck,
  ShieldAlert,
  Sparkles,
  DollarSign,
  ClipboardCheck,
  FileSearch,
  GraduationCap,
  HeartPulse,
  Database,
  ShoppingCart,
  Gavel,
  Video,
  HardHat,
  Zap,
  CalendarDays,
  Stethoscope,
  Wind,
  Layers,
  Activity,
  Scale,
  FileWarning,
  Trash2,
  PieChart,
  FileText,
  Building2,
  FileDigit,
  Users,
  Accessibility,
  Terminal
} from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { usePathname, useRouter } from "next/navigation"

import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarGroup,
  SidebarGroupLabel,
} from "@/components/ui/sidebar"
import { useAuth, useUser, useDoc, useMemoFirebase, useFirestore } from "@/firebase"
import { signOut } from "firebase/auth"
import { doc } from "firebase/firestore"
import { cn } from "@/lib/utils"

const BRASAO_URL = "https://firebasestorage.googleapis.com/v0/b/studio-8439299034-125c7.firebasestorage.app/o/logo%2FBrasa%CC%83o%20Logo%20NXC%20Branco.png?alt=media&token=c47decf6-fa71-4f99-b4fe-0200d3159de7";

const NAV_MODULES = [
  {
    label: "ESTRATÉGICO",
    icon: ShieldCheck,
    isRestricted: true,
    roles: ['SUPER_ADMIN', 'ADMIN'],
    items: [
      { title: "Dashboard NAI", icon: Zap, href: "/" },
      { title: "Gestão de Clientes", icon: Building2, href: "/clients" },
      { title: "Gestão de Contratos", icon: FileText, href: "/contracts" },
      { title: "Gestão de Colaboradores", icon: Users, href: "/employees" },
      { title: "BI & Analytics", icon: BarChart3, href: "/analytics" },
      { title: "Firewall e-Social", icon: SearchCheck, href: "/esocial-audit" },
      { title: "Cérebro IA", icon: Sparkles, href: "/knowledge-base" },
    ]
  },
  {
    label: "COMERCIAL",
    icon: DollarSign,
    isRestricted: true,
    roles: ['SUPER_ADMIN', 'ADMIN'],
    items: [
      { title: "Gerador Propostas", icon: ShoppingCart, href: "/comercial" },
      { title: "Financeiro ERP", icon: Database, href: "/financial" },
      { title: "ROI & Perícias", icon: Gavel, href: "/legal-financial" },
    ]
  },
  {
    label: "ENGENHARIA E SAÚDE",
    icon: HeartPulse,
    roles: ['SUPER_ADMIN', 'ADMIN', 'DOCTOR', 'PROVIDER', 'CLIENT_ADMIN'],
    items: [
      { title: "Gestão de Saúde", icon: HeartPulse, href: "/medical/health-management" },
      { title: "Clínica (ASO)", icon: Stethoscope, href: "/health-control" },
      { title: "Telemedicina", icon: Video, href: "/telemedicine" },
      { title: "Mapa Biomecânico", icon: Accessibility, href: "/medical/biomechanics" },
      { title: "Validador Forense", icon: FileSearch, href: "/medical-certificates" },
    ]
  },
  {
    label: "SEGURANÇA DO TRABALHO",
    icon: HardHat,
    roles: ['SUPER_ADMIN', 'ADMIN', 'ENGINEER', 'PROVIDER', 'CLIENT_ADMIN'],
    items: [
      { title: "Centro de Operação", icon: CheckSquare, href: "/action-plans" },
      { title: "Audit Studio (IA)", icon: Terminal, href: "/risk-management/audit-studio" },
      { title: "Documentos (eSocial)", icon: FileText, href: "/reports" },
      { title: "APR & Permissões (PT)", icon: FileDigit, href: "/risk-management/pt-apr" },
      { title: "Inventário PGR", icon: ClipboardCheck, href: "/risk-management" },
      { title: "Acidentes (CAT)", icon: FileWarning, href: "/accidents" },
      { title: "Gestão EPI/EPC", icon: ShieldCheck, href: "/ppe-management" },
      { title: "Treinamentos", icon: GraduationCap, href: "/trainings" },
    ]
  },
  {
    label: "ISO & AUDITORIA",
    icon: Layers,
    roles: ['SUPER_ADMIN', 'ADMIN', 'ENGINEER'],
    items: [
      { title: "Plan. Auditorias", icon: CalendarDays, href: "/audits" },
      { title: "Não Conformidades", icon: Activity, href: "/non-conformities" },
      { title: "Checklists ISO", icon: ClipboardCheck, href: "/checklists" },
    ]
  },
  {
    label: "GOVERNANÇA & AMBIENTAL",
    icon: Scale,
    roles: ['SUPER_ADMIN', 'ADMIN', 'ENGINEER'],
    items: [
      { title: "LIRA Legal", icon: Scale, href: "/governance" },
      { title: "Matriz AIA", icon: Wind, href: "/environmental" },
      { title: "Gestão Resíduos", icon: Trash2, href: "/environmental#waste" },
    ]
  }
]

export function AppSidebar() {
  const pathname = usePathname()
  const auth = useAuth()
  const db = useFirestore()
  const { user } = useUser()
  const router = useRouter()

  const profileRef = useMemoFirebase(() => {
    if (!db || !user) return null
    return doc(db, "users", user.uid)
  }, [db, user])

  const { data: profile } = useDoc(profileRef)

  const handleLogout = async () => {
    await signOut(auth)
    router.push("/login")
  }

  const role = (profile?.role || 'CLIENT_ADMIN').toUpperCase()
  const userEmail = (profile?.email || user?.email || '').toLowerCase()
  const isTimeNextcon = userEmail === 'nextcon@nextconsaude.com.br' || role === 'SUPER_ADMIN'
  const userName = profile?.name || user?.email?.split('@')[0] || "Usuário"
  
  return (
    <Sidebar className="border-r border-sidebar-border bg-[#001F3F] text-white">
      <SidebarHeader className="p-8 pb-4 flex flex-row items-center gap-3">
        <div className="relative size-10 shrink-0">
          <Image 
            src={BRASAO_URL} 
            alt="Nextcon Brasão" 
            fill 
            className="object-contain"
            priority
            sizes="40px"
          />
        </div>
        <div className="flex flex-col">
          <span className="text-3xl font-black tracking-tighter uppercase leading-none">NAI</span>
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.3em] mt-1">Intelligence</span>
        </div>
      </SidebarHeader>
      
      <SidebarContent className="px-3">
        {NAV_MODULES.map((module) => {
          if (module.isRestricted && !isTimeNextcon) return null;
          
          return (
            <SidebarGroup key={module.label} className="py-4">
              <SidebarGroupLabel className="text-slate-500 text-[9px] font-black uppercase tracking-widest mb-2 px-4">
                {module.label}
              </SidebarGroupLabel>
              <SidebarMenu>
                {module.items.map((item) => (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton 
                      asChild 
                      isActive={pathname === item.href} 
                      className={cn(
                        "rounded-xl px-4 h-10 transition-all duration-300",
                        pathname === item.href ? "bg-accent text-white" : "hover:bg-white/5"
                      )}
                    >
                      <Link href={item.href} className="flex items-center gap-3">
                        <item.icon className={cn("size-4", pathname === item.href ? "opacity-100" : "opacity-40")} />
                        <span className="text-xs font-bold uppercase tracking-tight">{item.title}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroup>
          )
        })}
      </SidebarContent>

      <SidebarFooter className="p-6 border-t border-white/5">
        <div className="flex items-center gap-3 p-3 bg-white/5 rounded-2xl">
          <div className="size-9 rounded-xl bg-accent text-primary flex items-center justify-center font-black text-xs uppercase shadow-lg">
            {userName.substring(0, 2)}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-[10px] font-black truncate uppercase tracking-tight">{userName}</p>
            <p className="text-[8px] text-slate-400 font-bold uppercase tracking-widest">{role}</p>
          </div>
          <button onClick={handleLogout} className="p-2 hover:bg-red-500/20 hover:text-red-400 rounded-lg transition-all group">
            <LogOut className="size-4 opacity-40 group-hover:opacity-100" />
          </button>
        </div>
      </SidebarFooter>
    </Sidebar>
  )
}
