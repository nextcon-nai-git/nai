'use client';

import * as React from 'react';
import { Lock, Loader2, Zap, ShieldCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useAuth, useFirestore } from '@/firebase';
import { signInWithEmailAndPassword, createUserWithEmailAndPassword, updateProfile } from 'firebase/auth';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';
import Image from 'next/image';

const BRASAO_URL = "https://firebasestorage.googleapis.com/v0/b/studio-8439299034-125c7.firebasestorage.app/o/logo%2FBrasa%CC%83o%20Logo%20NXC%20Branco.png?alt=media&token=c47decf6-fa71-4f99-b4fe-0200d3159de7";

export default function LoginPage() {
  const [email, setEmail] = React.useState('');
  const [password, setPassword] = React.useState('');
  const [loading, setLoading] = React.useState(false);
  const [status, setStatus] = React.useState('');
  
  const auth = useAuth();
  const db = useFirestore();
  const { toast } = useToast();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading) return;
    
    setLoading(true);
    setStatus('Autenticando...');
    
    try {
      const targetEmail = email.toLowerCase().trim();
      const isMasterEmail = targetEmail === 'nextcon@nextconsaude.com.br';
      const isAtsteEmail = targetEmail === 'atestedb@nextconsaude.com.br';
      const isNativaEmail = targetEmail === 'nativa@nextconsaude.com.br';
      const isBritaniaEmail = targetEmail === 'britania@nextconsaude.com.br';
      
      const isDemoEmail = isMasterEmail || isAtsteEmail || isNativaEmail || isBritaniaEmail;
      
      let loggedUser = null;

      try {
        const userCredential = await signInWithEmailAndPassword(auth, targetEmail, password);
        loggedUser = userCredential.user;
      } catch (signInError: any) {
        if (isDemoEmail && (signInError.code === 'auth/user-not-found' || signInError.code === 'auth/invalid-credential')) {
          setStatus('Provisionando...');
          const createCredential = await createUserWithEmailAndPassword(auth, targetEmail, password);
          loggedUser = createCredential.user;
          
          let displayName = 'Time Nextcon';
          if (isAtsteEmail) displayName = 'Gestor A TESTE';
          if (isNativaEmail) displayName = 'Gestor NATIVA';
          if (isBritaniaEmail) displayName = 'Gestor BRITÂNIA';
          
          await updateProfile(loggedUser, { displayName });
        } else {
          throw signInError;
        }
      }

      if (!loggedUser) throw new Error("Falha ao estabelecer sessão segura.");

      setStatus('Sincronizando...');
      const userRef = doc(db, "users", loggedUser.uid);
      
      const role = isMasterEmail ? 'SUPER_ADMIN' : 'CLIENT_ADMIN';
      let companyId = null;
      let companyName = null;

      if (isAtsteEmail) { companyId = 'TESTE_DB_2026'; companyName = 'A TESTE DB 2026'; }
      if (isNativaEmail) { companyId = 'NATIVA_EMPR'; companyName = 'NATIVA EMPREENDIMENTOS'; }
      if (isBritaniaEmail) { companyId = 'BRITANIA_JOINVILLE'; companyName = 'BRITÂNIA ELETRODOMÉSTICOS'; }

      await setDoc(userRef, {
        id: loggedUser.uid,
        email: loggedUser.email,
        role: role,
        companyId: companyId,
        companyName: companyName,
        name: loggedUser.displayName || 'Usuário Nextcon',
        updatedAt: serverTimestamp()
      }, { merge: true });

      setStatus('Acessando...');
      window.location.href = '/';
      
    } catch (error: any) {
      setLoading(false);
      setStatus('');
      toast({
        variant: 'destructive',
        title: 'Falha no Acesso',
        description: error.message || "Credenciais inválidas.",
      });
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#001F3F] p-6">
      <div className="w-full max-w-md space-y-8 bg-white p-10 rounded-[3rem] shadow-2xl animate-in zoom-in-95 duration-500">
        <div className="text-center space-y-2">
          <div className="size-20 rounded-[2rem] bg-primary mx-auto flex items-center justify-center shadow-xl border-2 border-primary/10 mb-4 relative overflow-hidden">
            <Image 
              src={BRASAO_URL} 
              alt="Nextcon Brasão" 
              fill 
              className="object-contain p-2"
              priority
            />
          </div>
          <h1 className="text-4xl font-black text-primary uppercase tracking-tighter">NAI</h1>
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">Inteligência em SST 2026</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          <div className="space-y-4">
            <div className="space-y-1">
              <label className="text-[10px] font-black uppercase text-slate-400 ml-1">E-mail Corporativo</label>
              <Input 
                type="email" value={email} onChange={e => setEmail(e.target.value)}
                className="h-14 bg-slate-50 border-none rounded-2xl font-bold px-6 shadow-inner focus-visible:ring-primary/10" 
                placeholder="ex: seu@email.com.br" required disabled={loading}
              />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-black uppercase text-slate-400 ml-1">Senha</label>
              <Input 
                type="password" value={password} onChange={e => setPassword(e.target.value)}
                className="h-14 bg-slate-50 border-none rounded-2xl font-bold px-6 shadow-inner focus-visible:ring-primary/10" 
                placeholder="••••••••" required disabled={loading}
              />
            </div>
          </div>

          <Button 
            type="submit" 
            disabled={loading} 
            className="w-full h-16 bg-primary text-white font-black uppercase text-xs tracking-widest rounded-2xl shadow-xl gap-3 transition-all active:scale-95"
          >
            {loading ? (
              <div className="flex items-center gap-2">
                <Loader2 className="animate-spin size-5 text-accent" />
                <span>{status}</span>
              </div>
            ) : (
              <>
                <Zap className="size-5 text-accent" />
                <span>Entrar no Portal</span>
              </>
            )}
          </Button>
        </form>

        <div className="pt-6 border-t text-center space-y-4">
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center justify-center gap-2">
            <ShieldCheck className="size-3" /> Acesso Seguro Multi-tenant 2026.
          </p>
          <div className="p-4 bg-slate-50 rounded-2xl text-[9px] font-medium text-slate-500 text-left space-y-1 border border-dashed">
            <p className="font-black text-primary uppercase mb-1">Logins de Demonstração:</p>
            <p>• Britânia: <span className="font-bold">britania@nextconsaude.com.br</span></p>
            <p>• Nativa: <span className="font-bold">nativa@nextconsaude.com.br</span></p>
            <p>• Metalurgia: <span className="font-bold">atestedb@nextconsaude.com.br</span></p>
            <p className="mt-2 text-primary">Senha: <span className="font-bold">Nextcon.2026</span></p>
          </div>
        </div>
      </div>
    </div>
  );
}
