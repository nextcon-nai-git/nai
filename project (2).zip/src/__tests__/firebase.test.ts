import { describe, it, expect } from 'vitest';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { initializeFirebase } from '@/firebase/init';

/**
 * @fileOverview Testes unitários para integração Firebase NAI.
 */

describe('Firebase Integration & Security Rules', () => {
  it('deve inicializar os serviços do Firebase com sucesso', () => {
    const { firestore, auth } = initializeFirebase();
    expect(firestore).toBeDefined();
    expect(auth).toBeDefined();
  });

  it('deve respeitar a estrutura multi-tenant na consulta de empresas', async () => {
    const { firestore } = initializeFirebase();
    const q = query(collection(firestore, 'companies'), where('active', '==', true));
    
    try {
      const snap = await getDocs(q);
      // Em ambiente de teste, o snapshot pode ser vazio, mas a chamada não deve falhar
      expect(Array.isArray(snap.docs)).toBe(true);
    } catch (e: any) {
      // Se falhar por falta de permissão, o teste documenta o bloqueio esperado sem auth
      expect(e.message).toContain('permissions');
    }
  });
});
