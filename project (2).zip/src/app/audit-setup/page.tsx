
"use client";

import * as React from "react"
import { Database, Loader2, CheckCircle2, ShieldCheck, FolderTree, ArrowLeft, MapPin, Sparkles, Zap, TrendingUp, HeartPulse, Scale, ClipboardList } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { useToast } from "@/hooks/use-toast"
import { useFirestore, useStorage } from "@/firebase"
import { doc, writeBatch, collection, getDocs, deleteDoc } from "firebase/firestore"
import { ref, uploadString } from "firebase/storage"
import { REAL_COMPANIES, INVESTOR_DEMO_DATA } from "@/lib/real-data"
import Link from "next/link"

export default function AuditSetupPage() {
  const { toast } = useToast()
  const db = useFirestore()
  const storage = useStorage()
  const [loading, setLoading] = React.useState(false)
  const [progress, setProgress] = React.useState(0)
  const [status, setStatus] = React.useState("")

  async function handleSetup() {
    if (!db || !storage) return
    setLoading(true)
    setStatus("Limpando ambiente e iniciando provisionamento...")
    
    try {
      // 1. Limpeza de Clientes Antigos
      setStatus("Consolidando Banco de Dados Multi-tenant...")
      const companiesSnap = await getDocs(collection(db, "companies"));
      for (const d of companiesSnap.docs) {
        await deleteDoc(d.ref);
      }
      
      // Limpa cards de operação globais
      const opsSnap = await getDocs(collection(db, "operation_cards"));
      for (const d of opsSnap.docs) {
        await deleteDoc(d.ref);
      }
      
      setProgress(10);

      const batch = writeBatch(db)
      const now = new Date().toISOString()
      
      // 2. Provisionar Empresas
      setStatus("Sincronizando Unidades Estratégicas...")
      REAL_COMPANIES.forEach(company => {
        batch.set(doc(db, "companies", company.id), { 
          ...company, 
          updatedAt: now,
          active: true 
        }, { merge: true })
      });
      setProgress(30)

      // 3. Injetar Tarefas (SGI) para ambas as empresas
      setStatus("Populando Centro de Operação (Kanban)...")
      INVESTOR_DEMO_DATA.tasks.forEach(task => {
        // Injeta na Teste DB
        const taskRef1 = doc(db, "companies", "TESTE_DB_2026", "tasks", task.id);
        batch.set(taskRef1, { ...task, companyId: "TESTE_DB_2026", createdAt: now }, { merge: true });
        
        // Injeta na Nativa
        const taskRef2 = doc(db, "companies", "NATIVA_EMPR", "tasks", `NAT_${task.id}`);
        batch.set(taskRef2, { ...task, title: `[OBRA] ${task.title}`, companyId: "NATIVA_EMPR", companyName: "NATIVA EMPREENDIMENTOS", createdAt: now }, { merge: true });
      });
      setProgress(50)

      // 4. Injetar Quadro de Vidas e Riscos
      setStatus("Sincronizando Quadro de Vidas e PGR...")
      INVESTOR_DEMO_DATA.employees.forEach(emp => {
        const empRef = doc(db, "companies", emp.companyId, "employees", emp.id);
        batch.set(empRef, { ...emp, createdAt: now }, { merge: true });
      });
      
      INVESTOR_DEMO_DATA.risks.forEach(risk => {
        const riskRef = doc(db, "companies", "TESTE_DB_2026", "pgr_risks", risk.id);
        batch.set(riskRef, { ...risk, companyId: "TESTE_DB_2026", updatedAt: now }, { merge: true });
      });
      setProgress(80)

      // 5. Provisionamento de Pastas Storage
      setStatus("Sincronizando Hierarquia Multi-tenant...")
      const folders = ["docs_legais", "sst_nrs/nr01_pgr", "sst_nrs/nr07_pcmso", "saude_gestao/afastados"];
      for (const company of REAL_COMPANIES) {
        for (const folder of folders) {
          await uploadString(ref(storage, `clientes/${company.id}/${folder}/.keep`), "");
        }
      }

      await batch.commit()
      setProgress(100)
      setStatus("✅ Vitrine NAI ativada com sucesso!")
      
      toast({
        title: "Setup Concluído",
        description: "Ambientes TESTE DB e NATIVA configurados com isolamento total."
      })
    } catch (error) {
      console.error(error)
      toast({ variant: "destructive", title: "Erro no Setup" })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-[80vh] flex items-center justify-center p-6 animate-in fade-in duration-700">
      <Card className="max-w-2xl w-full border-none shadow-2xl rounded-[2.5rem] overflow-hidden bg-white text-left">
        <CardHeader className="bg-primary text-white p-10 relative overflow-hidden">
          <div className="absolute top-0 right-0 p-8 opacity-10"><MapPin className="size-48 text-accent" /></div>
          <div className="relative z-10 space-y-2">
            <Link href="/">
              <Button variant="ghost" size="sm" className="text-white/60 hover:text-white -ml-2 mb-4 gap-2">
                <ArrowLeft className="size-4" /> Voltar ao Início
              </Button>
            </Link>
            <CardTitle className="text-3xl font-headline font-black uppercase tracking-tight">Provisionamento Multi-tenant</CardTitle>
            <CardDescription className="text-white/70 font-bold uppercase text-[10px] tracking-widest">Ativando Unidades: A TESTE DB e NATIVA EMPREENDIMENTOS.</CardDescription>
          </div>
        </CardHeader>

        <CardContent className="p-10 space-y-8">
          <div className="space-y-2">
            <div className="flex justify-between text-[10px] font-black uppercase text-slate-400 tracking-widest px-1">
              <span>Status do Provisionamento</span>
              <span className="text-primary">{Math.round(progress)}%</span>
            </div>
            <Progress value={progress} className="h-3 bg-slate-100" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 space-y-2">
              <div className="flex items-center gap-2 mb-1">
                <Zap className="size-4 text-accent" />
                <p className="text-[10px] font-black uppercase text-slate-400">Canal 1: Metalurgia</p>
              </div>
              <p className="text-xs font-bold text-primary uppercase leading-tight">atestedb@nextconsaude.com.br</p>
            </div>
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 space-y-2">
              <div className="flex items-center gap-2 mb-1">
                <HeartPulse className="size-4 text-red-500" />
                <p className="text-[10px] font-black uppercase text-slate-400">Canal 2: Construção</p>
              </div>
              <p className="text-xs font-bold text-primary uppercase leading-tight">nativa@nextconsaude.com.br</p>
            </div>
          </div>

          {status && (
            <div className="p-5 bg-accent/5 border border-accent/10 rounded-2xl flex items-center gap-4 text-primary">
              {loading ? <Loader2 className="size-5 animate-spin text-accent" /> : <CheckCircle2 className="size-5 text-accent" />}
              <span className="text-xs font-bold italic leading-tight">"{status}"</span>
            </div>
          )}
        </CardContent>

        <CardFooter className="p-10 bg-slate-50">
          <Button 
            onClick={handleSetup} 
            disabled={loading}
            className="w-full h-16 bg-primary text-white text-sm font-black uppercase tracking-widest rounded-2xl shadow-xl gap-3"
          >
            {loading ? <Loader2 className="size-5 animate-spin" /> : <ShieldCheck className="size-5 text-accent" />}
            Provisionar Ecossistema Demo
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
