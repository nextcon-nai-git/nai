"use client";

import * as React from "react";
import { HeartPulse, Plus, Loader2, Save, CheckCircle2, Brain, AlertTriangle, Sparkles, Mic, MicOff, Building2, User } from "lucide-react";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger, 
  DialogFooter 
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { useUser, useFirestore, useDoc, useMemoFirebase, useCollection } from "@/firebase";
import { collection, addDoc, doc, serverTimestamp, query, orderBy, where } from "firebase/firestore";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { cn } from "@/lib/utils";
import { useSgi } from "@/contexts/sgi-context";

const attendanceSchema = z.object({
  companyId: z.string().min(1, "Selecione a unidade"),
  employeeId: z.string().min(1, "Selecione um colaborador"),
  complaint: z.string().min(3, "Descreva a queixa do paciente"),
  bp_sys: z.string().min(2, "Obrigatório"),
  bp_dia: z.string().min(2, "Obrigatório"),
  heart_rate: z.string().min(1, "Obrigatório"),
  temperature: z.string().min(1, "Obrigatório"),
  spo2: z.string().min(1, "Obrigatório"),
  conduct: z.enum(["observation", "work", "emergency"]),
  medication: z.string().optional(),
  coren: z.string().min(5, "Registro COREN inválido"),
});

type AttendanceFormValues = z.infer<typeof attendanceSchema>;

export function NewAttendanceModal() {
  const { toast } = useToast();
  const { user, role } = useUser();
  const db = useFirestore();
  const { activeClientId } = useSgi();
  
  const [isOpen, setIsOpen] = React.useState(false);
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [isListening, setIsListening] = React.useState(false);

  const profileRef = useMemoFirebase(() => {
    if (!db || !user) return null;
    return doc(db, "users", user.uid);
  }, [db, user]);
  const { data: profile } = useDoc(profileRef);

  const companiesQuery = useMemoFirebase(() => {
    if (!db) return null;
    return query(collection(db, "companies"), orderBy("name", "asc"));
  }, [db]);
  const { data: companies } = useCollection(companiesQuery);

  const form = useForm<AttendanceFormValues>({
    resolver: zodResolver(attendanceSchema),
    defaultValues: {
      companyId: activeClientId !== "all" ? activeClientId : "",
      employeeId: "",
      complaint: "",
      bp_sys: "120",
      bp_dia: "80",
      heart_rate: "72",
      temperature: "36.5",
      spo2: "98",
      conduct: "observation",
      medication: "",
      coren: "",
    },
  });

  const selectedCompanyId = form.watch("companyId");
  const selectedEmployeeId = form.watch("employeeId");

  // Consulta reativa de funcionários baseada na empresa selecionada no formulário
  const employeesQuery = useMemoFirebase(() => {
    if (!db || !selectedCompanyId) return null;
    return query(collection(db, "companies", selectedCompanyId, "employees"), orderBy("name", "asc"));
  }, [db, selectedCompanyId]);
  const { data: employees, isLoading: loadingEmployees } = useCollection(employeesQuery);

  const selectedEmployee = React.useMemo(() => 
    employees?.find(e => e.id === selectedEmployeeId),
    [employees, selectedEmployeeId]
  );

  React.useEffect(() => {
    if (isOpen && activeClientId !== "all") {
      form.setValue("companyId", activeClientId);
    }
  }, [isOpen, activeClientId, form]);

  const toggleListening = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      toast({ variant: "destructive", title: "Recurso não suportado", description: "Seu navegador não suporta ditado por voz." });
      return;
    }

    if (isListening) {
      setIsListening(false);
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = 'pt-BR';
    recognition.continuous = false;
    recognition.interimResults = false;

    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      const currentComplaint = form.getValues("complaint");
      form.setValue("complaint", currentComplaint ? `${currentComplaint} ${transcript}` : transcript);
    };

    recognition.start();
  };

  async function onFormSubmit(values: AttendanceFormValues) {
    if (!db) return;
    setIsSubmitting(true);
    try {
      const emp = employees?.find(e => e.id === values.employeeId);
      const company = companies?.find(c => c.id === values.companyId);
      
      await addDoc(collection(db, "nursing_attendances"), {
        ...values,
        employeeName: emp?.name || "Colaborador",
        companyName: company?.name || "Unidade",
        nurseId: user?.uid,
        nurseName: profile?.name || user?.email,
        status_esocial: "Pendente",
        createdAt: new Date().toISOString(),
        timestamp: serverTimestamp()
      });
      toast({ title: "Atendimento Registrado", description: "Prontuário salvo e aguardando eSocial S-2220." });
      setIsOpen(false);
      form.reset();
    } catch (error) {
      toast({ variant: "destructive", title: "Erro ao Salvar", description: "Não foi possível registrar o atendimento." });
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button className="gradient-nextcon text-white h-11 px-8 rounded-xl font-black uppercase text-[10px] tracking-widest shadow-lg">
          <Plus className="size-4" /> Novo Atendimento
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[700px] rounded-[2.5rem] border-none shadow-2xl p-0 overflow-hidden bg-white">
        <DialogHeader className="p-8 bg-primary text-white space-y-2">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/10 rounded-lg text-accent"><HeartPulse className="size-5" /></div>
            <DialogTitle className="text-xl font-headline font-black uppercase">Triagem Técnica</DialogTitle>
          </div>
          <DialogDescription className="text-white/60 font-medium italic">
            Registro auditável de intercorrência e parâmetros vitais por unidade.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onFormSubmit)} className="p-8 space-y-6">
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-left">
              <FormField
                control={form.control}
                name="companyId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-[10px] font-black uppercase text-slate-400">Unidade Atendida</FormLabel>
                    <Select onValueChange={(v) => { field.onChange(v); form.setValue("employeeId", ""); }} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger className="h-11 bg-slate-50 border-none rounded-xl font-bold">
                          <div className="flex items-center gap-2">
                            <Building2 className="size-3.5 text-primary/40" />
                            <SelectValue placeholder="Selecione a Empresa..." />
                          </div>
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {companies?.map(c => <SelectItem key={c.id} value={c.id} className="text-xs font-bold uppercase">{c.name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                    <FormMessage className="text-[9px]" />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="employeeId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-[10px] font-black uppercase text-slate-400">Colaborador</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value} disabled={!selectedCompanyId || loadingEmployees}>
                      <FormControl>
                        <SelectTrigger className="h-11 bg-slate-50 border-none rounded-xl font-bold">
                          <div className="flex items-center gap-2">
                            <User className="size-3.5 text-primary/40" />
                            <SelectValue placeholder={loadingEmployees ? "Carregando..." : (!selectedCompanyId ? "Selecione a empresa" : "Escolha o paciente...")} />
                          </div>
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {employees?.map(e => <SelectItem key={e.id} value={e.id} className="text-xs font-bold uppercase">{e.name}</SelectItem>)}
                        {(!employees || employees.length === 0) && selectedCompanyId && !loadingEmployees && (
                          <div className="p-3 text-[10px] font-black text-slate-400 uppercase text-center">Nenhum colaborador encontrado</div>
                        )}
                      </SelectContent>
                    </Select>
                    <FormMessage className="text-[9px]" />
                  </FormItem>
                )}
              />
            </div>

            {selectedEmployee?.ai_risk_score && selectedEmployee.ai_risk_score > 60 && (
              <div className="p-5 bg-red-50 border-2 border-red-100 rounded-3xl flex gap-4 animate-in slide-in-from-top-2 shadow-inner">
                <div className="p-3 bg-red-600 text-white rounded-2xl h-fit shadow-lg">
                  <Brain className="size-6" />
                </div>
                <div className="text-left">
                  <p className="text-[10px] font-black uppercase text-red-600 tracking-[0.2em] mb-1 flex items-center gap-2">
                    <Sparkles className="size-3 fill-current" /> Alerta Preditivo ({selectedEmployee.ai_risk_score}% Risco)
                  </p>
                  <p className="text-xs font-bold text-red-900 leading-tight">
                    {selectedEmployee.ai_recommendation}
                  </p>
                </div>
              </div>
            )}

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-left">
              <FormField
                control={form.control}
                name="bp_sys"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-[10px] font-black uppercase text-slate-400">PAS (mmHg)</FormLabel>
                    <FormControl>
                      <Input placeholder="120" {...field} className="h-11 bg-slate-50 border-none rounded-xl font-bold text-center" />
                    </FormControl>
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="bp_dia"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-[10px] font-black uppercase text-slate-400">PAD (mmHg)</FormLabel>
                    <FormControl>
                      <Input placeholder="80" {...field} className="h-11 bg-slate-50 border-none rounded-xl font-bold text-center" />
                    </FormControl>
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="heart_rate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-[10px] font-black uppercase text-slate-400">FC (bpm)</FormLabel>
                    <FormControl>
                      <Input type="number" placeholder="72" {...field} className="h-11 bg-slate-50 border-none rounded-xl font-bold text-center" />
                    </FormControl>
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="temperature"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-[10px] font-black uppercase text-slate-400">Temp (°C)</FormLabel>
                    <FormControl>
                      <Input type="number" step="0.1" placeholder="36.5" {...field} className="h-11 bg-slate-50 border-none rounded-xl font-bold text-center" />
                    </FormControl>
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-left">
               <FormField
                control={form.control}
                name="coren"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-[10px] font-black uppercase text-slate-400">COREN do Responsável</FormLabel>
                    <FormControl>
                      <Input placeholder="Ex: 123456-TE/PR" {...field} className="h-11 bg-slate-50 border-none rounded-xl font-bold" />
                    </FormControl>
                    <FormMessage className="text-[9px]" />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="conduct"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-[10px] font-black uppercase text-slate-400">Conduta Inicial</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger className="h-11 bg-slate-50 border-none rounded-xl font-bold">
                          <SelectValue placeholder="Selecione..." />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="observation">Observação Interna</SelectItem>
                        <SelectItem value="work">Liberado para o Trabalho</SelectItem>
                        <SelectItem value="emergency">Encaminhado p/ Emergência</SelectItem>
                      </SelectContent>
                    </Select>
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="complaint"
              render={({ field }) => (
                <FormItem className="text-left">
                  <div className="flex justify-between items-center mb-1">
                    <FormLabel className="text-[10px] font-black uppercase text-slate-400">Relato / Sintomas</FormLabel>
                    <Button 
                      type="button" 
                      variant="ghost" 
                      size="sm" 
                      onClick={toggleListening}
                      className={cn(
                        "h-7 px-3 text-[9px] font-black uppercase gap-2 rounded-lg",
                        isListening ? "bg-red-50 text-red-600 animate-pulse" : "bg-primary/5 text-primary"
                      )}
                    >
                      {isListening ? <MicOff className="size-3" /> : <Mic className="size-3" />}
                      {isListening ? "Gravando..." : "Ditado Médico"}
                    </Button>
                  </div>
                  <FormControl>
                    <Textarea placeholder="Descreva o que o colaborador está sentindo..." {...field} className="min-h-[100px] bg-slate-50 border-none rounded-xl p-4 text-xs font-medium" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter className="bg-slate-50 -mx-8 -mb-8 p-8 border-t">
              <Button type="submit" disabled={isSubmitting} className="w-full h-14 bg-primary text-white font-black uppercase text-xs rounded-2xl shadow-xl gap-3">
                {isSubmitting ? <Loader2 className="size-5 animate-spin" /> : <Save className="size-5 text-accent" />}
                Protocolar Atendimento
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
