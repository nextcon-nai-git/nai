
"use client";

import * as React from "react";
import { 
  Activity, 
  AlertTriangle, 
  Timer, 
  Users, 
  Search, 
  Loader2, 
  type LucideIcon, 
  Brain,
  ShieldAlert,
  Thermometer,
  HeartPulse,
  Heart,
  ChevronRight,
  ClipboardList,
  Stethoscope,
  Info
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { 
  Sheet, 
  SheetContent, 
  SheetDescription, 
  SheetHeader, 
  SheetTitle,
  SheetTrigger
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import { REAL_EMPLOYEES } from "@/lib/real-data";
import { useUser } from "@/firebase";

interface AttendanceTabProps {
  attendances: any[];
  loading: boolean;
}

interface StatCardProps {
  label: string;
  value: string | number;
  icon: LucideIcon;
  color: string;
  bg: string;
}

export function AttendanceTab({ attendances, loading }: AttendanceTabProps) {
  const { role } = useUser();
  const [searchTerm, setSearchTerm] = React.useState("");
  const [selectedItem, setSelectedItem] = React.useState<any>(null);

  // RBAC LGPD: Apenas perfis médicos acessam dados clínicos brutos
  const isHealthPro = ['SUPER_ADMIN', 'DOCTOR', 'PROVIDER'].includes(role || '');

  const checkVitalAlarms = (item: any) => {
    const sys = Number(item.bp_sys);
    const dia = Number(item.bp_dia);
    const fc = Number(item.heart_rate);
    const temp = Number(item.temperature);

    const alarms = [];
    if (sys > 130 || dia > 90) alarms.push({ label: "Pressão Alta", color: "text-red-600 bg-red-50", type: 'pa_high' });
    if (sys < 110 || dia < 70) alarms.push({ label: "Pressão Baixa", color: "text-blue-600 bg-blue-50", type: 'pa_low' });
    if (temp > 37.0) alarms.push({ label: "Estado Febril", color: "text-orange-600 bg-orange-50", type: 'fever' });
    if (fc > 100) alarms.push({ label: "Taquicardia", color: "text-red-500 bg-red-50", type: 'fc_high' });
    if (fc < 60) alarms.push({ label: "Bradicardia", color: "text-indigo-600 bg-indigo-50", type: 'fc_low' });

    return alarms;
  };

  const filteredAttendances = React.useMemo(() => {
    let list = [...attendances];
    if (searchTerm.trim()) {
      const lowerSearch = searchTerm.toLowerCase();
      list = list.filter(a => (a.employeeName || "").toLowerCase().includes(lowerSearch));
    }
    
    return list.map(item => {
      const employeeData = REAL_EMPLOYEES.find(e => e.id === item.employeeId);
      return { 
        ...item, 
        ai_risk_score: employeeData?.ai_risk_score || 0,
        alarms: checkVitalAlarms(item)
      };
    }).sort((a, b) => (b.ai_risk_score || 0) - (a.ai_risk_score || 0));
  }, [attendances, searchTerm]);

  const stats = React.useMemo(() => ({
    triagensHoje: attendances.filter(a => new Date(a.createdAt).toDateString() === new Date().toDateString()).length,
    casosCriticos: filteredAttendances.filter(a => a.alarms.length > 0 || a.ai_risk_score > 70).length,
  }), [attendances, filteredAttendances]);

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <StatCard label="Triagens Hoje" value={stats.triagensHoje} icon={Activity} color="text-blue-600" bg="bg-blue-50" />
        <StatCard label="Casos Críticos" value={stats.casosCriticos} icon={ShieldAlert} color="text-red-600" bg="bg-red-50" />
        <StatCard label="SLA Atendimento" value="4.2 min" icon={Timer} color="text-emerald-600" bg="bg-emerald-50" />
        <StatCard label="Vidas em Vigilância" value="806" icon={Users} color="text-primary" bg="bg-slate-100" />
      </div>

      <Card className="card-shadow border-none bg-white rounded-[2rem] overflow-hidden">
        <CardHeader className="bg-slate-50 border-b py-6 px-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="text-left">
            <CardTitle className="text-lg font-black text-primary uppercase">Fila Epidemiológica NAI</CardTitle>
            <CardDescription className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Motor Sentinela: Monitoramento de parâmetros vitais e eSocial.</CardDescription>
          </div>
          <div className="relative w-full md:w-64">
            <Search className="absolute left-3 top-2.5 size-4 text-slate-300" />
            <Input 
              placeholder="Buscar colaborador..." 
              className="pl-10 h-10 border-none bg-white shadow-sm text-xs rounded-xl" 
              value={searchTerm} 
              onChange={e => setSearchTerm(e.target.value)} 
            />
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader className="bg-slate-50/50 text-[10px] uppercase font-black">
              <TableRow>
                <TableHead className="pl-8">Colaborador</TableHead>
                <TableHead>Sinais Vitais (LGPD)</TableHead>
                <TableHead>Protocolo Sentinela</TableHead>
                <TableHead>eSocial (S-2220)</TableHead>
                <th className="pr-8 text-right font-black uppercase text-[10px] text-muted-foreground">Ficha</th>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow><TableCell colSpan={5} className="py-20 text-center"><Loader2 className="size-10 animate-spin mx-auto opacity-20" /></TableCell></TableRow>
              ) : filteredAttendances.map((item) => (
                <Sheet key={item.id}>
                  <SheetTrigger asChild>
                    <TableRow className={cn(
                      "hover:bg-slate-50/50 transition-colors group cursor-pointer",
                      item.alarms.length > 0 && "bg-red-50/10"
                    )} onClick={() => setSelectedItem(item)}>
                      <TableCell className="pl-8 py-5">
                        <div className="text-left">
                          <p className="font-black text-xs text-primary uppercase leading-tight">{item.employeeName}</p>
                          <p className="text-[9px] text-slate-400 font-bold uppercase mt-1">Check-in: {new Date(item.createdAt).toLocaleTimeString('pt-BR')}</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <div className={cn(
                            "px-3 py-1.5 rounded-xl border flex flex-col items-center justify-center transition-all",
                            (Number(item.bp_sys) > 130 || Number(item.bp_sys) < 110) ? "bg-red-50 border-red-200 animate-pulse" : "bg-slate-50 border-slate-100"
                          )}>
                             <span className="text-[8px] font-black text-slate-400 uppercase">P.A.</span>
                             <span className={cn("text-xs font-black", (Number(item.bp_sys) > 130 || Number(item.bp_sys) < 110) ? "text-red-600" : "text-primary")}>
                               {isHealthPro ? `${item.bp_sys}/${item.bp_dia}` : "*** / ***"}
                             </span>
                          </div>
                          <div className={cn(
                            "px-3 py-1.5 rounded-xl border flex flex-col items-center justify-center",
                            (Number(item.heart_rate) > 100 || Number(item.heart_rate) < 60) ? "bg-orange-50 border-orange-200" : "bg-slate-50 border-slate-100"
                          )}>
                             <span className="text-[8px] font-black text-slate-400 uppercase">F.C.</span>
                             <span className={cn("text-xs font-black", (Number(item.heart_rate) > 100 || Number(item.heart_rate) < 60) ? "text-orange-600" : "text-primary")}>
                               {isHealthPro ? `${item.heart_rate}` : "***"}
                             </span>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {item.alarms.length > 0 ? item.alarms.map((alarm: any, idx: number) => (
                            <Badge key={idx} className={cn("text-[8px] font-black uppercase border-none px-2 h-5", alarm.color)}>
                              <AlertTriangle className="size-2 mr-1" /> {alarm.label}
                            </Badge>
                          )) : (
                            <Badge className="bg-emerald-100 text-emerald-700 border-none text-[8px] font-black uppercase px-2 h-5">Estável</Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className={cn(
                          "text-[8px] font-black uppercase h-5",
                          item.status_esocial === 'Enviado' ? "bg-emerald-50 text-emerald-600 border-emerald-100" : "bg-orange-50 text-orange-600 border-orange-100"
                        )}>
                          {item.status_esocial === 'Enviado' ? "PROTOCOLADO" : "PENDENTE"}
                        </Badge>
                      </TableCell>
                      <TableCell className="pr-8 text-right">
                        <Button variant="ghost" size="sm" className="h-8 rounded-xl text-primary font-black uppercase text-[9px] gap-2 hover:bg-primary hover:text-white transition-all">
                           Abrir Ficha <ChevronRight className="size-3" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  </SheetTrigger>
                  
                  <SheetContent className="sm:max-w-xl p-0 border-none shadow-2xl flex flex-col bg-white">
                    {item && (
                      <>
                        <SheetHeader className="p-10 bg-primary text-white relative shrink-0">
                          <div className="absolute top-0 right-0 p-8 opacity-10"><ShieldAlert className="size-32 text-accent" /></div>
                          <div className="relative z-10 text-left space-y-4">
                            <Badge className="bg-accent text-primary border-none text-[8px] font-black uppercase tracking-[0.3em]">Protocolo Sentinela Ativo</Badge>
                            <div className="flex items-center gap-5">
                              <div className="size-16 rounded-[1.5rem] bg-white/10 flex items-center justify-center text-3xl font-black border border-white/20 shadow-2xl">
                                {item.employeeName?.substring(0, 2).toUpperCase()}
                              </div>
                              <div>
                                <SheetTitle className="text-2xl font-headline font-black uppercase tracking-tight text-white">{item.employeeName}</SheetTitle>
                                <SheetDescription className="text-white/60 font-bold uppercase text-[10px] mt-1 tracking-widest">
                                  ID: {item.employeeId} | Registro de Triagem em {new Date(item.createdAt).toLocaleDateString('pt-BR')}
                                </SheetDescription>
                              </div>
                            </div>
                          </div>
                        </SheetHeader>

                        <ScrollArea className="flex-1 p-10 scrollbar-thin">
                          <div className="space-y-10 pb-20">
                            {/* 1. Alertas Críticos da NAI */}
                            {item.alarms.length > 0 && (
                              <div className="p-6 bg-red-50 border-2 border-red-100 rounded-[2rem] space-y-4 shadow-inner text-left">
                                <div className="flex items-center gap-3 text-red-700">
                                  <Brain className="size-5" />
                                  <h4 className="text-xs font-black uppercase tracking-widest leading-none">Protocolos Médicos Sugeridos (IA)</h4>
                                </div>
                                <div className="space-y-3">
                                  {item.alarms.map((alarm: any, i: number) => (
                                    <div key={i} className="bg-white p-4 rounded-2xl border border-red-100 shadow-sm">
                                      <p className="text-[10px] font-black text-red-600 uppercase mb-1">{alarm.label}</p>
                                      <p className="text-[11px] text-slate-600 font-medium italic leading-relaxed">
                                        {alarm.type === 'pa_high' && "Conduta AHA: Repouso imediato de 15 min. Repetir aferição. Se persistir > 140/90, suspender atividade crítica e encaminhar ao médico."}
                                        {alarm.type === 'fever' && "Protocolo Febre: Hidratação oral. Busca ativa por focos infecciosos. Se > 38.5°C ou sintomas sistêmicos, encaminhar para triagem médica."}
                                        {alarm.type === 'fc_high' && "Protocolo Taquicardia: ECG em repouso. Investigar uso de estimulantes (energéticos/pré-treino) ou stress agudo."}
                                      </p>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}

                            {/* 2. Sinais Vitais em Detalhe */}
                            <div className="space-y-4">
                              <h4 className="text-[10px] font-black uppercase text-primary tracking-[0.2em] flex items-center gap-2">
                                <HeartPulse className="size-4 text-accent" /> Parâmetros Biométricos
                              </h4>
                              <div className="grid grid-cols-2 gap-4">
                                <VitalItem label="Pressão Arterial" value={`${item.bp_sys}/${item.bp_dia}`} unit="mmHg" icon={Activity} color="text-blue-600" />
                                <VitalItem label="Freq. Cardíaca" value={item.heart_rate} unit="bpm" icon={Heart} color="text-red-600" />
                                <VitalItem label="Temperatura" value={item.temperature} unit="°C" icon={Thermometer} color="text-orange-600" />
                                <VitalItem label="Saturação SpO2" value={item.spo2} unit="%" icon={HeartPulse} color="text-blue-500" />
                              </div>
                            </div>

                            {/* 3. Queixa e Relato */}
                            <div className="space-y-4 text-left">
                               <h4 className="text-[10px] font-black uppercase text-primary tracking-[0.2em] flex items-center gap-2">
                                 <ClipboardList className="size-4 text-accent" /> Queixa do Paciente
                               </h4>
                               <div className="p-6 bg-slate-50 rounded-[2rem] border border-slate-100 italic text-sm text-slate-700 leading-relaxed shadow-inner">
                                 "{item.complaint || "Sem queixas relatadas no ato da triagem."}"
                               </div>
                            </div>

                            {/* 4. Responsabilidade Técnica */}
                            <div className="p-6 bg-white border border-slate-100 rounded-[2.5rem] flex items-center gap-4 shadow-sm text-left">
                              <div className="p-3 bg-primary/5 rounded-2xl text-primary"><Stethoscope className="size-5" /></div>
                              <div>
                                <p className="text-[8px] font-black uppercase text-slate-400">Triagem Realizada por:</p>
                                <p className="text-xs font-bold text-primary uppercase">{item.nurseName || "Time Enfermagem Nextcon"}</p>
                                <p className="text-[10px] font-mono text-slate-500 mt-0.5">COREN: {item.coren || "PR-000000"}</p>
                              </div>
                            </div>
                          </div>
                        </ScrollArea>

                        <div className="p-10 bg-slate-50 border-t shrink-0 flex flex-col gap-4">
                           <div className="flex gap-3">
                             <Button variant="outline" className="flex-1 h-14 rounded-2xl font-black uppercase text-[10px] border-primary text-primary">Imprimir Guia</Button>
                             <Button className="flex-1 h-14 bg-primary text-white font-black uppercase text-[10px] rounded-2xl shadow-xl gap-2">
                               <Info className="size-4 text-accent" /> Evoluir Prontuário
                             </Button>
                           </div>
                           <p className="text-[7px] text-slate-300 font-black uppercase text-center tracking-[0.4em]">Audit Compliance HIPAA v2.7</p>
                        </div>
                      </>
                    )}
                  </SheetContent>
                </Sheet>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}

function VitalItem({ label, value, unit, icon: Icon, color }: any) {
  return (
    <div className="p-5 bg-white border border-slate-100 rounded-3xl shadow-sm text-left group hover:ring-2 ring-primary/5 transition-all">
      <div className={cn("p-2 rounded-lg bg-slate-50 w-fit mb-3", color)}>
        <Icon className="size-4" />
      </div>
      <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest leading-none mb-1">{label}</p>
      <div className="flex items-baseline gap-1">
        <span className="text-lg font-black text-primary tabular-nums">{value}</span>
        <span className="text-[8px] font-bold text-slate-400 uppercase">{unit}</span>
      </div>
    </div>
  );
}

function StatCard({ label, value, icon: Icon, color, bg }: StatCardProps) {
  return (
    <Card className="border-none shadow-sm bg-white rounded-3xl group hover:ring-2 ring-primary/5 transition-all">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className={cn("p-3 rounded-2xl", bg, color)}><Icon className="size-5" /></div>
          <Badge variant="outline" className="text-[8px] font-black uppercase text-slate-300">Live</Badge>
        </div>
        <p className="text-[9px] font-black uppercase text-muted-foreground tracking-widest mb-1">{label}</p>
        <h3 className={cn("text-2xl font-black leading-none", color)}>{value}</h3>
      </CardContent>
    </Card>
  );
}

