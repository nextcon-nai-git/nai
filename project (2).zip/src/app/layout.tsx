'use client';

import './globals.css';
import { Toaster } from '@/components/ui/toaster';
import { FirebaseClientProvider } from '@/firebase/client-provider';
import * as React from 'react';
import { AppContent } from '@/components/layout/app-content';
import { SgiProvider } from '@/contexts/sgi-context';

/**
 * @fileOverview Root Layout da Plataforma NAI.
 * Centraliza metadados, fontes do Google e suporte a PWA.
 */
export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR" suppressHydrationWarning>
      <head>
        {/* Conexão com Google Fonts */}
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=Montserrat:wght@700;900&display=swap" rel="stylesheet" />
        
        {/* Favicon SVG Dinâmico */}
        <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><rect x='28' y='28' width='44' height='44' fill='none' stroke='%23334155' stroke-width='8'/><path d='M20 40 V85 L80 15 V60' fill='none' stroke='%23003366' stroke-width='10' stroke-linejoin='round' stroke-linecap='round'/></svg>" />
        
        <title>NAI - Nextcon AI | Inteligência em SST</title>

        {/* PWA & Offline Support */}
        <meta name="theme-color" content="#001F3F" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="default" />
        <meta name="apple-mobile-web-app-title" content="NAI Nextcon" />

        {/* Registro de Service Worker para Offline Assets */}
        <script dangerouslySetInnerHTML={{
          __html: `
            if ('serviceWorker' in navigator) {
              window.addEventListener('load', function() {
                navigator.serviceWorker.register('/sw.js').then(function(registration) {
                  console.log('NAI PWA: ServiceWorker registrado com sucesso.');
                }, function(err) {
                  console.log('NAI PWA: Falha no ServiceWorker:', err);
                });
              });
            }
          `
        }} />
      </head>
      <body className="antialiased">
        <FirebaseClientProvider>
          <SgiProvider>
            <AppContent>{children}</AppContent>
            <Toaster />
          </SgiProvider>
        </FirebaseClientProvider>
      </body>
    </html>
  );
}
