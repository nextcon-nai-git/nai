"use client"

import * as React from "react"
import Link from "next/link"
import { 
  Plus, 
  Brain,
  Building2,
  Loader2,
  Zap,
  User,
  ShieldAlert,
  Clock,
  CheckCircle2,
  ShoppingCart
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { useToast } from "@/hooks/use-toast"
import { useUser, useFirestore, useCollection, useMemoFirebase } from "@/firebase"
import { collection, query, orderBy, doc, where, collectionGroup } from "firebase/firestore"
import { updateDocumentNonBlocking } from "@/firebase/non-blocking-updates"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog"
import { OpsTask } from "@/types/schema"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import { useSgi } from "@/contexts/sgi-context"
import { 
  DndContext, 
  closestCorners, 
  PointerSensor, 
  useSensor, 
  useSensors, 
  DragEndEvent, 
  useDroppable,
  useDraggable
} from '@dnd-kit/core'

type SgiColumn = "PROPOSTAS" | "PLANEJAMENTO" | "EXECUÇÃO" | "CONCLUÍDO";

const COLUMN_CONFIG: Record<SgiColumn, { title: string; color: string; bg: string; border: string; icon: any }> = {
  PROPOSTAS: { title: "PROPOSTAS", color: "text-indigo-600", bg: "bg-indigo-500/10", border: "border-indigo-500/20", icon: ShoppingCart },
  PLANEJAMENTO: { title: "PLANEJAMENTO", color: "text-amber-600", bg: "bg-amber-500/10", border: "border-amber-500/20", icon: Clock },
  EXECUÇÃO: { title: "EXECUÇÃO", color: "text-blue-600", bg: "bg-blue-500/10", border: "border-blue-500/20", icon: ShieldAlert },
  CONCLUÍDO: { title: "CONCLUÍDO", color: "text-emerald-600", bg: "bg-emerald-500/10", border: "border-emerald-500/20", icon: CheckCircle2 }
};

function DroppableColumn({ id, tasks, loading, onTaskClick }: { id: SgiColumn, tasks: OpsTask[], loading: boolean, onTaskClick: (task: OpsTask) => void }) {
  const { setNodeRef, isOver } = useDroppable({ id });
  const config = COLUMN_CONFIG[id];
  const Icon = config.icon;

  return (
    <div ref={setNodeRef} className={cn("bg-slate-50/50 rounded-[2.5rem] p-5 border transition-all duration-300 min-h-[700px] flex flex-col shadow-inner", isOver ? "bg-primary/5 border-primary/20" : "border-slate-100")}>
      <div className={cn("flex items-center justify-between p-4 rounded-2xl mb-6 border shadow-sm", config.bg, config.border)}>
        <div className="flex items-center gap-3">
          <Icon className={cn("size-5", config.color)} />
          <span className={cn("text-xs font-black uppercase tracking-[0.15em]", config.color)}>{config.title}</span>
        </div>
        <Badge className="bg-white text-slate-900 border-none font-black text-[10px] h-6 min-w-[24px] flex items-center justify-center rounded-full shadow-sm">{tasks.length}</Badge>
      </div>
      <div className="space-y-4 flex-1">
        {loading ? <div className="py-20 text-center"><Loader2 className="animate-spin mx-auto opacity-20" /></div> : tasks.map((task) => <DraggableTaskCard key={task.id} task={task} onClick={() => onTaskClick(task)} />)}
      </div>
    </div>
  );
}

function DraggableTaskCard({ task, onClick }: { task: OpsTask, onClick?: () => void }) {
  const { attributes, listeners, setNodeRef, transform } = useDraggable({ id: task.id, data: task });
  const style = transform ? { transform: `translate3d(${transform.x}px, ${transform.y}px, 0)` } : undefined;

  return (
    <div ref={setNodeRef} style={style} className="bg-white border rounded-3xl p-5 shadow-sm hover:shadow-xl transition-all duration-300 group border-l-[6px] border-l-blue-400 cursor-pointer" onClick={onClick}>
      <div className="flex items-start justify-between gap-2 mb-3">
        <Badge variant="outline" className="text-[7px] font-black uppercase border-slate-200 text-slate-400 h-4">{task.type?.toUpperCase()}</Badge>
        <button {...listeners} {...attributes} className="p-1 text-slate-300 cursor-grab active:cursor-grabbing"><Zap className="size-3" /></button>
      </div>
      <h4 className="text-[13px] font-black text-slate-800 uppercase tracking-tight leading-tight mb-1 group-hover:text-primary transition-colors">{task.title}</h4>
      <p className="text-[8px] font-black uppercase text-slate-400 tracking-widest mb-2 flex items-center gap-1"><Building2 className="size-2" /> {task.companyName}</p>
      <div className="pt-3 border-t border-slate-50 flex justify-between items-center text-[9px] font-bold text-slate-500">
        <span className="inline-flex items-center gap-1.5"><User className="size-2.5" /> {task.companyName}</span>
        <span className="inline-flex items-center gap-1"><Clock className="size-2.5" /> {task.dueDate ? new Date(task.dueDate).toLocaleDateString('pt-BR') : '--/--'}</span>
      </div>
    </div>
  );
}

export default function SgiOperationalHub() {
  const { user, role } = useUser()
  const db = useFirestore()
  const { toast } = useToast()
  const { activeClientId } = useSgi()
  
  const [selectedTaskDetails, setSelectedTaskDetails] = React.useState<OpsTask | null>(null)
  const [isCreateOpen, setIsCreateOpen] = React.useState(false)

  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 5 } }));

  const isGlobalAdmin = React.useMemo(() => ['SUPER_ADMIN', 'ADMIN'].includes(role || ''), [role]);

  // Query otimizada com filtro de companyId mandatório para conformidade
  const tasksQuery = useMemoFirebase(() => {
    if (!db || !role || activeClientId === "unauthorized") return null;
    
    if (activeClientId === "all") {
      if (!isGlobalAdmin) return null;
      return query(collectionGroup(db, "tasks"), orderBy("dueDate", "asc"));
    }
    
    // Consulta por subcoleção direta com ID validado
    return query(collection(db, "companies", activeClientId, "tasks"), orderBy("dueDate", "asc"));
  }, [db, activeClientId, role, isGlobalAdmin]);

  const { data: tasks, isLoading: loadingTasks } = useCollection<OpsTask>(tasksQuery)

  const sgiTasks = React.useMemo(() => {
    if (!tasks) return { PROPOSTAS: [], PLANEJAMENTO: [], EXECUÇÃO: [], CONCLUÍDO: [] };
    const getCol = (s: string): SgiColumn => {
      if (['to_review', 'sent', 'approved'].includes(s)) return "PROPOSTAS";
      if (['started', 'todo', 'implementation'].includes(s)) return "PLANEJAMENTO";
      if (['doing', 'review'].includes(s)) return "EXECUÇÃO";
      return "CONCLUÍDO";
    };
    return {
      PROPOSTAS: tasks.filter(t => getCol(t.status) === "PROPOSTAS"),
      PLANEJAMENTO: tasks.filter(t => getCol(t.status) === "PLANEJAMENTO"),
      EXECUÇÃO: tasks.filter(t => getCol(t.status) === "EXECUÇÃO"),
      CONCLUÍDO: tasks.filter(t => getCol(t.status) === "CONCLUÍDO"),
    };
  }, [tasks]);

  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event;
    if (!over || !db) return;
    
    const task = active.data.current as OpsTask;
    if (!task?.companyId) return;

    const taskRef = doc(db, "companies", task.companyId, "tasks", active.id as string);
    const targetStatus = over.id === 'PROPOSTAS' ? 'to_review' : over.id === 'PLANEJAMENTO' ? 'todo' : over.id === 'EXECUÇÃO' ? 'doing' : 'done';
    
    updateDocumentNonBlocking(taskRef, { status: targetStatus });
    toast({ title: "Fluxo Atualizado", description: `Atividade movida para ${over.id}.` });
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-700 pb-20">
      <header className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
        <div className="space-y-1 text-left">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-primary rounded-xl text-accent shadow-lg"><ShieldAlert className="size-6" /></div>
            <h1 className="text-3xl font-black text-primary uppercase font-headline">Centro de Operação</h1>
          </div>
          <p className="text-muted-foreground font-medium uppercase text-[10px] tracking-widest flex items-center gap-2"><Brain className="size-4 text-accent" /> SGI Master Control</p>
        </div>
        <Button onClick={() => setIsCreateOpen(true)} className="gradient-nextcon text-white h-11 px-8 rounded-xl font-black uppercase text-[10px] tracking-widest shadow-xl">
           <Plus className="size-5 mr-2" /> Abrir OS Técnica
        </Button>
      </header>

      <DndContext sensors={sensors} collisionDetection={closestCorners} onDragEnd={handleDragEnd}>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 items-start min-h-[700px]">
          {(["PROPOSTAS", "PLANEJAMENTO", "EXECUÇÃO", "CONCLUÍDO"] as SgiColumn[]).map((colId) => (
            <DroppableColumn key={colId} id={colId} tasks={sgiTasks[colId]} loading={loadingTasks} onTaskClick={setSelectedTaskDetails} />
          ))}
        </div>
      </DndContext>

      <Dialog open={!!selectedTaskDetails} onOpenChange={() => setSelectedTaskDetails(null)}>
        <DialogContent className="max-w-3xl rounded-[2.5rem] border-none shadow-2xl p-0 overflow-hidden bg-white text-left">
          {selectedTaskDetails && (
            <>
              <div className="p-8 bg-primary text-white">
                <DialogTitle className="text-2xl font-black uppercase font-headline">{selectedTaskDetails.title}</DialogTitle>
                <DialogDescription className="text-white/60 font-bold uppercase text-[10px] mt-1">Conformidade e Protocolo SGI Nextcon</DialogDescription>
              </div>
              <div className="p-8 space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 bg-slate-50 rounded-2xl">
                    <p className="text-[9px] font-black uppercase text-slate-400 mb-1">Unidade</p>
                    <p className="text-sm font-bold text-primary">{selectedTaskDetails.companyName}</p>
                  </div>
                  <div className="p-4 bg-slate-50 rounded-2xl">
                    <p className="text-[9px] font-black uppercase text-slate-400 mb-1">Tipo</p>
                    <Badge className="bg-primary text-white text-[8px] font-black uppercase">{selectedTaskDetails.type}</Badge>
                  </div>
                </div>
              </div>
              <DialogFooter className="p-6 bg-slate-50 border-t flex justify-end">
                <Button onClick={() => setSelectedTaskDetails(null)} className="font-bold uppercase text-[10px]">Fechar</Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
