"use client"

import * as React from 'react';
import { usePathname, useRouter } from 'next/navigation';
import { 
  Bell,
  Search,
  Settings,
  ChevronDown,
  Building2,
  ShieldCheck,
  UserCircle,
  Sparkles,
  Globe,
  WifiOff,
  Wifi
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useUser, useDoc, useMemoFirebase, useFirestore, useCollection } from '@/firebase';
import { doc, collection, query, orderBy, where } from 'firebase/firestore';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Badge } from '@/components/ui/badge';
import { PlatformFeedback } from '@/components/feedback/platform-feedback';
import { cn } from '@/lib/utils';
import { useSgi } from '@/contexts/sgi-context';

/**
 * @fileOverview TopNav com Trava Multi-tenant.
 * Oculta o seletor de empresas para usuários que não são administradores da Nextcon.
 */
export function TopNav() {
  const { user, role, companyId: userCompanyId } = useUser();
  const db = useFirestore();
  const pathname = usePathname();
  const router = useRouter();
  const { activeClientId, setActiveClientId } = useSgi();
  const [searchQuery, setSearchQuery] = React.useState("");
  const [isOnline, setIsOnline] = React.useState(true);

  React.useEffect(() => {
    setIsOnline(navigator.onLine);
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const profileRef = useMemoFirebase(() => {
    if (!db || !user) return null;
    return doc(db, "users", user.uid);
  }, [db, user]);
  const { data: profile } = useDoc(profileRef);
  
  // Se for admin, carrega todas. Se for cliente, trava o filtro para evitar erro de permissão.
  const companiesQuery = useMemoFirebase(() => {
    if (!db || !role) return null;
    const isGlobalAdmin = ['SUPER_ADMIN', 'ADMIN', 'ENGINEER', 'DOCTOR'].includes(role.toUpperCase());
    
    if (isGlobalAdmin) {
      return query(collection(db, "companies"), orderBy("name", "asc"));
    }
    
    if (userCompanyId) {
      return query(collection(db, "companies"), where("__name__", "==", userCompanyId));
    }
    
    return null;
  }, [db, role, userCompanyId]);
  
  const { data: companies } = useCollection(companiesQuery);

  const isGlobalAdmin = React.useMemo(() => 
    ['SUPER_ADMIN', 'ADMIN', 'ENGINEER', 'DOCTOR'].includes(role || ''), 
  [role]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      router.push(`/employees?q=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  const activeCompanyName = React.useMemo(() => {
    if (activeClientId === "all") return "Rede Global Nextcon";
    return companies?.find(c => c.id === activeClientId)?.name || "Unidade Ativa";
  }, [activeClientId, companies]);

  return (
    <header className="h-16 border-b bg-white flex items-center justify-between px-6 sticky top-0 z-40">
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2 text-slate-400 text-xs font-medium">
          <span className="font-black uppercase tracking-widest text-[9px] text-primary/40">NAI</span>
          <span className="opacity-30">/</span>
          {!isOnline && (
            <Badge variant="destructive" className="animate-pulse bg-red-600 border-none font-black text-[8px] uppercase px-2 gap-1.5 h-6">
              <WifiOff className="size-3" /> Offline
            </Badge>
          )}
          {isOnline && (
            <span className="text-slate-900 font-bold capitalize">
              {pathname === '/' ? 'Dashboard' : pathname.split('/').pop()?.replace('-', ' ')}
            </span>
          )}
        </div>
      </div>

      <div className="flex-1 max-w-xl mx-8 flex items-center gap-4">
        {isGlobalAdmin ? (
          <div className="w-72">
            <Select value={activeClientId} onValueChange={setActiveClientId}>
              <SelectTrigger className="h-10 bg-slate-50 border-none rounded-xl font-black uppercase text-[9px] tracking-widest shadow-inner">
                <Building2 className="size-3.5 mr-2 text-primary/40" />
                <SelectValue placeholder="Selecionar Unidade" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all" className="text-[9px] font-black uppercase">Visão Global (Rede Consolida)</SelectItem>
                {companies?.map(c => (
                  <SelectItem key={c.id} value={c.id} className="text-[9px] font-bold uppercase">{c.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        ) : (
          <div className="flex items-center gap-2 px-4 py-2 bg-emerald-50 border border-emerald-100 rounded-xl text-emerald-700 shadow-sm">
             <Building2 className="size-3.5" />
             <span className="text-[10px] font-black uppercase tracking-widest truncate max-w-[300px]">
               {activeCompanyName}
             </span>
          </div>
        )}

        <form onSubmit={handleSearch} className="relative group flex-1">
          <Search className="absolute left-3 top-2.5 size-4 text-slate-400 group-focus-within:text-primary transition-colors" />
          <Input 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Pesquisar na unidade..." 
            className="pl-10 h-10 bg-slate-50 border-transparent focus:bg-white focus:border-slate-200 transition-all text-sm"
          />
        </form>
      </div>

      <div className="flex items-center gap-3">
        <PlatformFeedback />

        <Button variant="ghost" size="icon" className="relative text-slate-400 hover:bg-slate-50">
          <Bell className="size-5" />
          <span className="absolute top-2.5 right-2.5 size-2 bg-destructive rounded-full border-2 border-white"></span>
        </Button>

        <div className="h-8 w-px bg-slate-200 mx-2" />

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="hover:bg-slate-50 gap-3 px-2 h-10 rounded-lg">
              <div className="text-right hidden sm:block">
                <p className="text-xs font-bold text-slate-900 leading-none mb-1">{profile?.name || user?.email?.split('@')[0]}</p>
                <p className="text-[9px] font-black text-slate-400 uppercase tracking-tighter">{role?.replace('_', ' ')}</p>
              </div>
              <div className={cn(
                "size-8 rounded-md flex items-center justify-center text-white font-bold text-xs shadow-sm",
                isGlobalAdmin ? "bg-primary" : "bg-accent"
              )}>
                {isGlobalAdmin ? <ShieldCheck className="size-4" /> : <UserCircle className="size-4" />}
              </div>
              <ChevronDown className="size-3 text-slate-400" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56 mt-2 rounded-xl border-none shadow-2xl">
            <DropdownMenuLabel className="text-[10px] font-black uppercase text-slate-400 px-4 py-3">Meu Perfil</DropdownMenuLabel>
            <DropdownMenuItem className="gap-3 cursor-pointer text-sm px-4 py-3" onClick={() => router.push('/settings')}><Settings className="size-4 opacity-50" /> Configurações</DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem className="text-destructive gap-3 cursor-pointer text-sm font-bold px-4 py-3" onClick={() => window.location.href = '/login'}>
              Encerrar Sessão
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}