
import {genkit} from 'genkit';
import {googleAI} from '@genkit-ai/google-genai';
import { enableFirebaseTelemetry } from '@genkit-ai/firebase';

/**
 * @fileOverview Configuração central do motor Genkit 1.x para a Nextcon.
 * Ativa plugins de IA e telemetria do Firebase apenas em ambientes autorizados.
 */

// Verificação de ambiente ultra-defensiva para evitar erro de GcpLogger/Service Account
const isProduction = process.env.NODE_ENV === 'production';
const hasExplicitCredentials = !!process.env.GOOGLE_APPLICATION_CREDENTIALS || !!process.env.GOOGLE_SERVICE_ACCOUNT_JSON;
const isReal = !!process.env.K_SERVICE || !!process.env.FUNCTION_NAME;

// Só ativa telemetria se for produção real ou possuir credenciais explícitas
if (isProduction && (isReal || hasExplicitCredentials)) {
  try {
    enableFirebaseTelemetry();
    console.log("NAI Telemetry: Monitoramento de produção ativado.");
  } catch (error) {
    // Falha silenciosa para não impedir o boot do servidor
  }
}

export const ai = genkit({
  plugins: [googleAI()],
  model: 'googleai/gemini-2.5-flash',
});
