'use client';

import * as React from 'react';
import { useDraggable } from '@dnd-kit/core';
import { OpsTask, TaskType } from '@/types/schema';
import { 
  AlertCircle, 
  Calendar, 
  FileText, 
  HardHat, 
  ShieldCheck, 
  Clock, 
  Brain,
  CheckSquare,
  Zap,
  Building2,
  MapPin,
  ExternalLink,
  Tag,
  CalendarPlus,
  MessageSquare,
  CircleDollarSign,
  Briefcase,
  Sparkles
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { format, isValid } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';

const TypeIcon = ({ type }: { type: TaskType }) => {
  switch (type) {
    case 'pgr': return <FileText className="w-4 h-4 text-blue-600" />;
    case 'treinamento': return <HardHat className="w-4 h-4 text-orange-600" />;
    case 'esocial': return <Zap className="w-4 h-4 text-purple-600" />;
    case 'pcmso': return <ShieldCheck className="w-4 h-4 text-emerald-600" />;
    case 'vistoria': return <MapPin className="w-4 h-4 text-blue-500" />;
    default: return <AlertCircle className="w-4 h-4 text-gray-500" />;
  }
};

const priorityStyles = {
  low: 'border-l-slate-300',
  medium: 'border-l-blue-400',
  high: 'border-l-orange-500',
  critical: 'border-l-red-600 shadow-lg shadow-red-500/10',
};

const priorityColors = {
  low: 'text-slate-400 bg-slate-100 border-slate-200',
  medium: 'text-blue-600 bg-blue-50 border-blue-200',
  high: 'text-orange-600 bg-orange-50 border-orange-200',
  critical: 'text-red-600 bg-red-50 border-red-200',
};

function safeFormat(date: any, formatStr: string) {
  if (!date) return "";
  const d = new Date(date);
  if (!isValid(d)) return "";
  return format(d, formatStr, { locale: ptBR });
}

export function TaskCard({ task }: { task: OpsTask }) {
  const [isShaking, setIsShaking] = React.useState(false);
  const prevTaskRef = React.useRef(task);

  const { attributes, listeners, setNodeRef, transform, isDragging } = useDraggable({
    id: task.id,
    data: task,
  });

  // Gatilho visual para atualizações em tempo real (Stream Feedback)
  React.useEffect(() => {
    // Compara campos críticos para disparar o "tremer"
    if (
      prevTaskRef.current.lastComment !== task.lastComment ||
      prevTaskRef.current.progress !== task.progress ||
      prevTaskRef.current.status !== task.status
    ) {
      setIsShaking(true);
      const timer = setTimeout(() => setIsShaking(false), 800);
      prevTaskRef.current = task;
      return () => clearTimeout(timer);
    }
  }, [task]);

  const style = transform ? {
    transform: `translate3d(${transform.x}px, ${transform.y}px, 0)`,
    zIndex: 50,
  } : undefined;

  const progress = task.progress !== undefined ? task.progress : (task.status === 'done' ? 100 : 0);

  const handleOpenMap = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!task.location) return;
    const url = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(task.location)}`;
    window.open(url, '_blank');
  };

  const handleAddToCalendar = (e: React.MouseEvent) => {
    e.stopPropagation();
    const start = task.startDate ? new Date(task.startDate).toISOString().replace(/-|:|\.\d\d\d/g, "") : new Date().toISOString().replace(/-|:|\.\d\d\d/g, "");
    const end = task.endDate ? new Date(task.endDate).toISOString().replace(/-|:|\.\d\d\d/g, "") : start;
    const url = `https://www.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(task.title)}&dates=${start}/${end}&details=${encodeURIComponent(task.companyName)}&location=${encodeURIComponent(task.location || "")}`;
    window.open(url, '_blank');
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      {...listeners}
      {...attributes}
      className={cn(
        "relative p-5 mb-4 rounded-2xl cursor-grab active:cursor-grabbing transition-all",
        "bg-white border border-slate-200 hover:shadow-xl",
        "border-l-[6px]", 
        priorityStyles[task.priority],
        isDragging ? "opacity-50 rotate-1 scale-105 shadow-2xl" : "shadow-sm",
        isShaking ? "animate-shake ring-2 ring-accent border-accent" : ""
      )}
    >
      {/* Header: Prioridade e Tags */}
      <div className="flex justify-between items-start mb-3">
        <div className="flex flex-wrap gap-1">
          <Badge className={cn("text-[8px] font-black uppercase h-5 px-2 border", priorityColors[task.priority])}>
            {task.priority === 'critical' ? 'CRÍTICA' : task.priority.toUpperCase()}
          </Badge>
          {task.tags?.map((tag, i) => (
            <Badge key={i} variant="secondary" className="bg-slate-100 text-slate-500 text-[8px] font-black uppercase px-2 h-5 border-none">
              {tag}
            </Badge>
          ))}
        </div>
        {task.ai_risk_score !== undefined && (
          <div className={cn(
            "size-9 rounded-xl border flex flex-col items-center justify-center shrink-0 shadow-inner transition-colors",
            task.ai_risk_score > 60 ? "bg-red-50 border-red-100" : "bg-slate-50 border-slate-100"
          )}>
            <Brain className={cn("size-3", task.ai_risk_score > 60 ? "text-red-500" : "text-primary/40")} />
            <span className={cn("text-[8px] font-black", task.ai_risk_score > 60 ? "text-red-600" : "text-primary")}>{task.ai_risk_score}%</span>
          </div>
        )}
      </div>

      {/* Nome e Local */}
      <div className="space-y-1 mb-4">
        <h4 className="text-[13px] font-black text-slate-800 leading-tight uppercase">
          {task.title}
        </h4>
        {task.location && (
          <div className="flex items-center gap-1 text-[10px] text-slate-400 font-bold uppercase truncate">
            <MapPin className="size-3 text-blue-400" /> {task.location}
          </div>
        )}
      </div>

      {/* Monday.com: Progress Bar */}
      <div className="space-y-1.5 mb-4">
        <div className="flex justify-between items-center text-[9px] font-black uppercase text-slate-400">
          <span className="flex items-center gap-1"><Sparkles size={8} className="text-accent" /> NAI SLA Progress</span>
          <span className={cn(progress === 100 ? "text-emerald-600" : "text-primary")}>{progress}%</span>
        </div>
        <Progress value={progress} className="h-2 bg-slate-100" />
      </div>

      {/* ClickUp: Custom Fields (CNAE / Risco) */}
      <div className="flex gap-4 mb-4 pb-4 border-b border-dashed">
        <div className="flex items-center gap-1.5">
          <Briefcase className="size-3 text-slate-300" />
          <span className="text-[9px] font-black text-slate-500 uppercase">CNAE: {task.cnae || '---'}</span>
        </div>
        <div className="flex items-center gap-1.5">
          <AlertCircle className="size-3 text-slate-300" />
          <span className="text-[9px] font-black text-slate-500 uppercase">GRAU: {task.riskDegree || '---'}</span>
        </div>
      </div>

      {/* Slack: Último Comentário */}
      {task.lastComment && (
        <div className="p-3 bg-slate-50 rounded-xl mb-4 flex gap-2 border border-slate-100">
          <MessageSquare className="size-3 text-slate-300 shrink-0 mt-0.5" />
          <p className="text-[10px] text-slate-500 italic leading-snug line-clamp-2">
            "{task.lastComment}"
          </p>
        </div>
      )}

      {/* Footer: Datas e Ações */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 text-[10px] text-slate-500 font-bold">
            <Calendar className="size-3 text-slate-300" />
            <span>{safeFormat(task.startDate, 'dd/MM')} - {safeFormat(task.endDate, 'dd/MM')}</span>
          </div>
          <button 
            onClick={handleAddToCalendar} 
            className="p-1.5 hover:bg-slate-100 rounded-lg text-slate-400 transition-colors" 
            title="Ligar ao Google Calendar"
          >
            <CalendarPlus className="size-3.5" />
          </button>
        </div>

        <div className="flex items-center gap-2">
          <button onClick={handleOpenMap} className="p-1.5 hover:bg-blue-50 rounded-lg text-blue-400" title="Ver Rota">
            <MapPin className="size-4" />
          </button>
          <div className={cn(
            "p-1.5 rounded-lg",
            task.isInvoiced ? "text-emerald-500 bg-emerald-50" : "text-slate-300 bg-slate-50"
          )} title={task.isInvoiced ? "Faturado" : "Pendente Fatura"}>
            <CircleDollarSign className="size-4" />
          </div>
        </div>
      </div>
    </div>
  );
}
