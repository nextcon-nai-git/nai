"use client"

import * as React from "react"
import { 
  Building2, 
  Plus, 
  Search, 
  Loader2, 
  MoreVertical, 
  Pencil, 
  Trash2, 
  CheckCircle2, 
  AlertTriangle,
  Globe,
  MapPin,
  FileText,
  Briefcase,
  Zap,
  ShieldCheck,
  RefreshCw,
  Sparkles,
  Database,
  ExternalLink,
  UserCheck,
  Ban,
  XCircle,
  GripVertical,
  FileSearch
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import { useUser, useFirestore, useCollection, useMemoFirebase } from "@/firebase"
import { collection, query, orderBy, doc, serverTimestamp, writeBatch, where } from "firebase/firestore"
import { updateDocumentNonBlocking, setDocumentNonBlocking, deleteDocumentNonBlocking } from "@/firebase/non-blocking-updates"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { z } from "zod"
import { cn } from "@/lib/utils"
import { enriquecerDadosEmpresa } from "@/actions/company-enrichment"
import { REAL_COMPANIES } from "@/lib/real-data"
import { useSgi } from "@/contexts/sgi-context"

const companySchema = z.object({
  name: z.string().min(3, "Nome obrigatório"),
  cnpj: z.string().min(14, "CNPJ inválido"),
  segment: z.string().min(1, "Segmento obrigatório"),
  risk_degree: z.string().min(1, "Grau de risco obrigatório"),
  city: z.string().min(2, "Cidade obrigatória"),
  state: z.string().min(2, "Estado obrigatória"),
  address: z.string().optional(),
  active: z.boolean().default(true),
  scope: z.string().optional(),
  responsible_name: z.string().min(3, "Informe o responsável principal"),
  responsible_role: z.string().min(2, "Informe o cargo do responsável"),
  cnae: z.string().optional(),
})

type CompanyFormValues = z.infer<typeof companySchema>

function SwipeableClientRow({ 
  company, 
  isSelected,
  onToggleActive, 
  onDelete, 
  onEdit, 
  onViewMap,
  onSelect
}: { 
  company: any, 
  isSelected: boolean,
  onToggleActive: (c: any) => void, 
  onDelete: (c: any) => void,
  onEdit: (c: any) => void,
  onViewMap: (c: any) => void,
  onSelect: (id: string) => void
}) {
  const [offsetX, setOffsetX] = React.useState(0);
  const [isDragging, setIsDragging] = React.useState(false);
  const startX = React.useRef(0);
  const threshold = 140;

  const handleStart = (e: React.MouseEvent | React.TouchEvent) => {
    setIsDragging(true);
    startX.current = 'touches' in e ? e.touches[0].clientX : e.clientX;
  };

  const handleMove = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isDragging) return;
    const currentX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const diff = currentX - startX.current;
    setOffsetX(diff * 0.5);
  };

  const handleEnd = () => {
    if (!isDragging) return;
    setIsDragging(false);

    if (offsetX > threshold) {
      onDelete(company);
    } else if (offsetX < -threshold) {
      onToggleActive(company);
    }
    
    setOffsetX(0);
  };

  return (
    <TableRow 
      className={cn(
        "relative overflow-hidden group select-none transition-colors h-20 p-0 border-none cursor-pointer",
        company.active ? "bg-white" : "bg-slate-50/80",
        isSelected && "bg-primary/5 ring-2 ring-primary/20 ring-inset"
      )}
      onMouseDown={handleStart}
      onMouseMove={handleMove}
      onMouseUp={handleEnd}
      onMouseLeave={handleEnd}
      onTouchStart={handleStart}
      onTouchMove={handleMove}
      onTouchEnd={handleEnd}
      onClick={() => onSelect(company.id)}
    >
      <TableCell className="p-0 border-none w-full" colSpan={6}>
        <div className="absolute inset-0 flex items-center justify-between px-10 pointer-events-none z-0 bg-slate-50 shadow-inner">
          <div className={cn(
            "flex items-center gap-3 text-red-600 transition-all duration-300 transform",
            offsetX > 40 ? "opacity-100 translate-x-0 scale-110" : "opacity-0 -translate-x-8 scale-90"
          )}>
            <Trash2 size={24} className={cn(offsetX > threshold && "animate-bounce")} />
            <span className="font-black uppercase text-[10px] tracking-widest">Solte para Excluir</span>
          </div>
          <div className={cn(
            "flex items-center gap-3 text-primary transition-all duration-300 transform",
            offsetX < -40 ? "opacity-100 translate-x-0 scale-110" : "opacity-0 translate-x-8 scale-90"
          )}>
            <span className="font-black uppercase text-[10px] tracking-widest">
              {company.active ? "Desativar" : "Ativar"}
            </span>
            <RefreshCw size={24} className={cn(offsetX < -threshold && "animate-spin")} />
          </div>
        </div>

        <div 
          className={cn(
            "flex items-center w-full h-20 bg-inherit relative z-10 transition-transform duration-200 border-b",
            isDragging ? "transition-none cursor-grabbing shadow-lg" : "cursor-grab"
          )}
          style={{ transform: `translateX(${offsetX}px)` }}
        >
          <div className="grid grid-cols-[60px_1fr_200px_120px_120px_100px] w-full items-center pointer-events-none">
            <div className="flex justify-center text-slate-300">
               <GripVertical size={16} />
            </div>

            <div className="py-5 flex items-center gap-4">
              <div className={cn(
                "size-11 rounded-2xl flex items-center justify-center text-white font-black text-sm shadow-inner shrink-0 transition-all",
                isSelected ? "bg-primary scale-110" : "bg-primary/5 text-primary"
              )}>
                {isSelected ? <ShieldCheck size={20} /> : company.name?.substring(0, 2).toUpperCase()}
              </div>
              <div className="min-w-0 text-left">
                <p className="font-black text-sm text-primary uppercase leading-tight truncate max-w-[400px]">{company.name}</p>
                <p className="text-[10px] text-slate-400 font-bold uppercase mt-1">CNPJ: {company.cnpj}</p>
              </div>
            </div>
            
            <div className="text-left">
              <div className="flex flex-col">
                <div className="flex items-center gap-1.5 text-xs font-bold text-slate-600 uppercase">
                  <UserCheck className="size-3.5 text-slate-300" />
                  {company.responsible_name || 'Não Definido'}
                </div>
                <p className="text-[9px] text-slate-400 font-medium uppercase tracking-tighter mt-0.5">{company.responsible_role || '---'}</p>
              </div>
            </div>

            <div className="text-center">
              <Badge variant="outline" className={cn(
                "text-[9px] font-black uppercase border-none h-6 px-3",
                company.risk_degree >= 3 ? "bg-red-50 text-red-700" : "bg-blue-50 text-blue-700"
              )}>
                Grau {company.risk_degree || '---'}
              </Badge>
            </div>

            <div className="text-center">
              <Badge className={cn(
                "text-[9px] font-black uppercase border-none px-3 h-6",
                company.active ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-400"
              )}>
                {company.active ? "Ativo" : "Inativo"}
              </Badge>
            </div>

            <div className="pr-8 text-right flex justify-end gap-2 pointer-events-auto">
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-9 w-9 text-slate-300 hover:text-blue-600 hover:bg-blue-50"
                onClick={(e) => { e.stopPropagation(); onViewMap(company); }}
              >
                <Globe className="size-4" />
              </Button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-9 w-9 text-slate-300 hover:text-primary" onClick={e => e.stopPropagation()}><MoreVertical className="size-5" /></Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56 rounded-xl border-none shadow-2xl" onClick={e => e.stopPropagation()}>
                  <DropdownMenuItem className="gap-3 py-3 text-xs font-bold uppercase" onClick={(e) => { e.stopPropagation(); onEdit(company); }}>
                    <Pencil className="size-4 opacity-50" /> Editar Unidade
                  </DropdownMenuItem>
                  <DropdownMenuItem className="gap-3 py-3 text-xs font-bold uppercase text-orange-600 focus:bg-orange-50" onClick={(e) => { e.stopPropagation(); onToggleActive(company); }}>
                    {company.active ? <Ban className="size-4 opacity-50" /> : <CheckCircle2 className="size-4 opacity-50" />} 
                    {company.active ? "Desativar Unidade" : "Ativar Unidade"}
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </TableCell>
    </TableRow>
  );
}

export default function ClientsManagement() {
  const { toast } = useToast()
  const { user, role, companyId: userCompanyId } = useUser()
  const db = useFirestore()
  const { activeClientId, setActiveClientId } = useSgi()
  
  const [searchTerm, setSearchTerm] = React.useState("")
  const [isCreateOpen, setIsCreateOpen] = React.useState(false)
  const [editingCompany, setEditingCompany] = React.useState<any>(null)
  const [isSubmitting, setIsSubmitting] = React.useState(false)
  const [isFetchingCnpj, setIsFetchingCnpj] = React.useState(false)
  const [isSyncing, setIsSyncing] = React.useState(false)

  const isGlobalAdmin = React.useMemo(() => ['SUPER_ADMIN', 'ADMIN'].includes(role || ''), [role]);

  const companiesQuery = useMemoFirebase(() => {
    if (!db || !role) return null
    
    // Se for admin, vê tudo. Se for cliente, vê apenas a sua própria empresa.
    if (isGlobalAdmin) {
      return query(collection(db, "companies"), orderBy("name", "asc"))
    }
    
    if (userCompanyId) {
      return query(collection(db, "companies"), where("__name__", "==", userCompanyId))
    }
    
    return null;
  }, [db, isGlobalAdmin, userCompanyId, role])
  
  const { data: companies, isLoading } = useCollection(companiesQuery)

  const form = useForm<CompanyFormValues>({
    resolver: zodResolver(companySchema),
    defaultValues: {
      name: "",
      cnpj: "",
      segment: "INDUSTRY",
      risk_degree: "1",
      city: "",
      state: "",
      address: "",
      active: true,
      scope: "",
      responsible_name: "",
      responsible_role: "",
      cnae: "",
    }
  })

  React.useEffect(() => {
    if (editingCompany) {
      form.reset({
        name: editingCompany.name || "",
        cnpj: editingCompany.cnpj || "",
        segment: editingCompany.segment || "INDUSTRY",
        risk_degree: String(editingCompany.risk_degree || "1"),
        city: editingCompany.city || "",
        state: editingCompany.state || "",
        address: editingCompany.address || "",
        active: editingCompany.active ?? true,
        scope: editingCompany.scope || "",
        responsible_name: editingCompany.responsible_name || "",
        responsible_role: editingCompany.responsible_role || "",
        cnae: editingCompany.cnae || "",
      })
    }
  }, [editingCompany, form])

  async function handleSyncBase() {
    if (!db) return;
    setIsSyncing(true);
    try {
      const batch = writeBatch(db);
      const now = new Date().toISOString();
      
      REAL_COMPANIES.forEach(comp => {
        const docRef = doc(db, "companies", comp.id);
        batch.set(docRef, { 
          ...comp, 
          id: comp.id,
          updatedAt: now,
          active: true 
        }, { merge: true });
      });

      await batch.commit();
      toast({ title: "Base Sincronizada", description: "Clientes reais carregados com sucesso." });
    } catch (e) {
      toast({ variant: "destructive", title: "Erro na Sincronização" });
    } finally {
      setIsSyncing(false);
    }
  }

  async function handleFetchCnpj() {
    const cnpj = form.getValues("cnpj");
    if (!cnpj || cnpj.replace(/\D/g, '').length < 14) {
      toast({ variant: "destructive", title: "CNPJ Incompleto" });
      return;
    }

    setIsFetchingCnpj(true);
    try {
      const res = await enriquecerDadosEmpresa(cnpj, 10);
      if (res.sucesso && res.dados) {
        form.setValue("name", res.dados.razaoSocial.toUpperCase());
        form.setValue("risk_degree", String(res.dados.grauDeRisco));
        form.setValue("city", res.dados.municipio);
        form.setValue("state", res.dados.uf);
        form.setValue("address", `${res.dados.logradouro}, ${res.dados.numero} - ${res.dados.bairro}`);
        
        const rawCnae = res.dados.cnae.replace(/\D/g, '');
        const cnaeFormatted = rawCnae.replace(/^(\d{4})(\d)(\d{2})$/, "$1-$2/$3");
        form.setValue("cnae", `CNAE Principal: ${cnaeFormatted} - ${res.dados.cnaeDescricao}`);
        
        toast({ title: "Dados Localizados" });
      }
    } catch (e) {
      toast({ variant: "destructive", title: "Erro na Consulta" });
    } finally {
      setIsFetchingCnpj(false);
    }
  }

  async function handleSave(values: CompanyFormValues) {
    if (!db) return
    setIsSubmitting(true)
    try {
      const data = {
        ...values,
        risk_degree: Number(values.risk_degree),
        updatedAt: serverTimestamp()
      }

      if (editingCompany) {
        updateDocumentNonBlocking(doc(db, "companies", editingCompany.id), data)
        toast({ title: "Unidade Atualizada" })
      } else {
        const customId = values.name.toUpperCase().replace(/\s+/g, '_') + "_" + Math.random().toString(36).substring(2, 6).toUpperCase();
        const docRef = doc(db, "companies", customId);
        setDocumentNonBlocking(docRef, { ...data, id: customId, createdAt: serverTimestamp() }, { merge: true });
        toast({ title: "Nova Unidade Criada" })
      }
      setIsCreateOpen(false)
      setEditingCompany(null)
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleToggleActive = (company: any) => {
    if (!db || !company.id) return
    const newStatus = !company.active
    updateDocumentNonBlocking(doc(db, "companies", company.id), { active: newStatus })
    toast({ 
      title: newStatus ? "Unidade Ativada" : "Unidade Desativada", 
      description: `${company.name} está ${newStatus ? 'ativa' : 'inativa'}.` 
    })
  }

  const handlePermanentDelete = (company: any) => {
    if (!db || !company.id) return;
    if (confirm(`Deseja EXCLUIR permanentemente a unidade "${company.name}"?`)) {
      deleteDocumentNonBlocking(doc(db, "companies", company.id));
      toast({ title: "Unidade Excluída" });
      setIsCreateOpen(false);
      setEditingCompany(null);
    }
  }

  const handleViewOnMap = (company: any) => {
    const fullAddress = `${company.address || ''} ${company.city || ''} ${company.state || ''}`.trim()
    if (!fullAddress) {
      toast({ variant: "destructive", title: "Endereço Ausente" })
      return
    }
    window.open(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(fullAddress)}`, '_blank')
  }

  const filteredCompanies = React.useMemo(() => {
    if (!companies) return []
    const term = searchTerm.toLowerCase()
    return companies.filter(c => 
      (c.name || "").toLowerCase().includes(term) || 
      (c.cnpj || "").includes(term)
    )
  }, [companies, searchTerm])

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <h1 className="text-3xl font-headline font-black text-primary tracking-tight uppercase leading-none">Gestão de Unidades</h1>
          <p className="text-muted-foreground font-medium uppercase text-[10px] tracking-widest mt-2 flex items-center gap-2">
            <Building2 className="size-3 text-accent" /> Controle Estratégico da Rede Nextcon 2026.
          </p>
        </div>
        <div className="flex gap-2">
          {isGlobalAdmin && (
            <Button variant="outline" disabled={isSyncing} onClick={handleSyncBase} className="h-11 px-6 border-slate-200 text-slate-500 font-bold uppercase text-[10px] gap-2 rounded-xl">
              {isSyncing ? <Loader2 className="size-4 animate-spin" /> : <Database className="size-4" />} Sincronizar Base Global
            </Button>
          )}
          {isGlobalAdmin && (
            <Dialog open={isCreateOpen} onOpenChange={(open) => { setIsCreateOpen(open); if (!open) setEditingCompany(null); }}>
              <DialogTrigger asChild>
                <Button className="gradient-nextcon text-white h-11 px-8 rounded-xl font-black uppercase text-[10px] tracking-widest shadow-lg gap-2">
                  <Plus className="size-4 text-accent" /> Nova Unidade
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[700px] rounded-[2.5rem] border-none shadow-2xl p-0 overflow-hidden bg-white text-left">
                <DialogHeader className="p-8 bg-primary text-white space-y-2">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-white/10 rounded-lg text-accent"><Building2 className="size-5" /></div>
                    <DialogTitle className="text-xl font-headline font-black uppercase">
                      {editingCompany ? "Editar Unidade" : "Cadastrar Unidade"}
                    </DialogTitle>
                  </div>
                  <DialogDescription className="text-white/60 font-medium">
                    Configuração de parâmetros multi-tenant e enquadramento normativo.
                  </DialogDescription>
                </DialogHeader>
                <div className="p-8 max-h-[70vh] overflow-y-auto">
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(handleSave)} className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="cnpj"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-[10px] font-black uppercase text-slate-400">CNPJ</FormLabel>
                              <div className="relative">
                                <FormControl><Input placeholder="00.000.000/0000-00" {...field} className="h-11 bg-slate-50 border-none rounded-xl font-bold pr-12 shadow-inner" /></FormControl>
                                <Button 
                                  type="button" variant="ghost" size="icon"
                                  className="absolute right-2 top-1.5 h-8 w-8 text-primary hover:bg-primary/5"
                                  onClick={handleFetchCnpj} disabled={isFetchingCnpj}
                                >
                                  {isFetchingCnpj ? <Loader2 className="size-4 animate-spin" /> : <Search className="size-4" />}
                                </Button>
                              </div>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="risk_degree"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-[10px] font-black uppercase text-slate-400">Grau de Risco (NR-04)</FormLabel>
                              <Select onValueChange={field.onChange} value={field.value}>
                                <FormControl><SelectTrigger className="h-11 bg-slate-50 border-none rounded-xl font-bold shadow-inner"><SelectValue /></SelectTrigger></FormControl>
                                <SelectContent>
                                  <SelectItem value="1">Grau 1</SelectItem>
                                  <SelectItem value="2">Grau 2</SelectItem>
                                  <SelectItem value="3">Grau 3</SelectItem>
                                  <SelectItem value="4">Grau 4</SelectItem>
                                </SelectContent>
                              </Select>
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="name"
                          render={({ field }) => (
                            <FormItem className="md:col-span-2">
                              <FormLabel className="text-[10px] font-black uppercase text-slate-400">Razão Social</FormLabel>
                              <FormControl><Input placeholder="Ex: BRITÂNIA ELETRODOMÉSTICOS" {...field} className="h-11 bg-slate-50 border-none rounded-xl font-bold uppercase shadow-inner" /></FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="cnae"
                          render={({ field }) => (
                            <FormItem className="md:col-span-2">
                              <FormLabel className="text-[10px] font-black uppercase text-slate-400">CNAE Principal (e-Social)</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <FileSearch className="absolute left-3 top-3.5 size-4 text-slate-300" />
                                  <Input placeholder="Preenchido via CNPJ" {...field} className="h-11 bg-slate-50 border-none rounded-xl font-bold pl-10 shadow-inner" readOnly />
                                </div>
                              </FormControl>
                            </FormItem>
                          )}
                        />
                        <div className="md:col-span-2 p-6 bg-slate-50 rounded-3xl border border-dashed border-slate-200 space-y-4">
                          <p className="text-[10px] font-black uppercase text-primary/40 tracking-widest flex items-center gap-2">
                            <UserCheck className="size-3" /> Responsável pela Unidade
                          </p>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <FormField
                              control={form.control}
                              name="responsible_name"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel className="text-[10px] font-black uppercase text-slate-400">Nome</FormLabel>
                                  <FormControl><Input placeholder="João Silva" {...field} className="h-11 bg-white border-none rounded-xl font-bold shadow-sm" /></FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={form.control}
                              name="responsible_role"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel className="text-[10px] font-black uppercase text-slate-400">Cargo</FormLabel>
                                  <FormControl><Input placeholder="Gerente SST" {...field} className="h-11 bg-white border-none rounded-xl font-bold shadow-sm" /></FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                        </div>
                        <FormField
                          control={form.control}
                          name="address"
                          render={({ field }) => (
                            <FormItem className="md:col-span-2">
                              <FormLabel className="text-[10px] font-black uppercase text-slate-400">Endereço Completo</FormLabel>
                              <FormControl><Input placeholder="Rua, Número - Bairro" {...field} className="h-11 bg-slate-50 border-none rounded-xl font-bold shadow-inner" /></FormControl>
                            </FormItem>
                          )}
                        />
                      </div>
                      <div className="pt-6 space-y-4 border-t border-dashed">
                        {editingCompany && (
                          <Button 
                            type="button" 
                            variant="outline" 
                            className="w-full h-11 border-red-200 text-red-600 hover:bg-red-50 font-black uppercase text-[10px] rounded-xl gap-2"
                            onClick={() => handlePermanentDelete(editingCompany)}
                          >
                            <Trash2 size={14} /> Excluir Unidade Permanentemente
                          </Button>
                        )}
                        <DialogFooter>
                          <Button type="submit" disabled={isSubmitting} className="w-full h-14 bg-primary text-white font-black uppercase text-xs tracking-widest rounded-2xl shadow-xl gap-3">
                            {isSubmitting ? <Loader2 className="size-5 animate-spin" /> : <ShieldCheck className="size-5 text-accent" />}
                            Salvar Unidade
                          </Button>
                        </DialogFooter>
                      </div>
                    </form>
                  </Form>
                </div>
              </DialogContent>
            </Dialog>
          )}
        </div>
      </header>

      <div className="relative group">
        <Search className="absolute left-4 top-3.5 size-5 text-slate-300 group-focus-within:text-primary transition-colors" />
        <Input 
          placeholder="Pesquisar por Unidade ou CNPJ..." 
          className="pl-12 h-12 bg-white border-none shadow-sm rounded-xl font-medium"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      <div className="bg-white rounded-[2.5rem] overflow-hidden shadow-xl border">
        <div className="p-6 bg-slate-50/50 border-b flex justify-between items-center text-[10px] font-black uppercase text-slate-400">
           <div className="flex items-center gap-4">
             <div className="flex items-center gap-2"><div className="size-2 bg-red-500 rounded-full" /> Deslize Dir: Excluir</div>
             <div className="flex items-center gap-2"><div className="size-2 bg-primary rounded-full" /> Deslize Esq: Status</div>
           </div>
        </div>
        <Table>
          <TableHeader className="bg-slate-50/30">
            <TableRow className="hover:bg-transparent border-none text-[10px] font-black uppercase">
              <TableHead className="w-[60px]"></TableHead>
              <TableHead className="py-5 text-left">Unidade / Razão Social</TableHead>
              <TableHead className="text-left">Responsável SGI</TableHead>
              <TableHead className="text-center">Grau de Risco</TableHead>
              <TableHead className="text-center">Status</TableHead>
              <TableHead className="pr-8 text-right"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow><TableCell colSpan={6} className="py-20 text-center"><Loader2 className="size-10 animate-spin mx-auto text-primary opacity-20" /></TableCell></TableRow>
            ) : filteredCompanies.length > 0 ? filteredCompanies.map((company) => (
              <SwipeableClientRow 
                key={company.id} 
                company={company} 
                isSelected={activeClientId === company.id}
                onToggleActive={handleToggleActive}
                onDelete={handlePermanentDelete}
                onEdit={(c) => { setEditingCompany(c); setIsCreateOpen(true); }}
                onViewMap={handleViewOnMap}
                onSelect={setActiveClientId}
              />
            )) : (
              <TableRow>
                <TableCell colSpan={6} className="py-24 text-center opacity-30 font-black uppercase text-sm tracking-[0.4em]">Nenhuma unidade localizada</TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
