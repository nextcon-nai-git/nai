"use client"

import * as React from "react"
import { 
  Scale, 
  Target, 
  Users, 
  TrendingUp, 
  ShieldCheck, 
  FileCheck, 
  Brain, 
  PieChart,
  Zap,
  Info,
  Building2,
  CheckCircle2,
  Globe,
  Loader2,
  AlertTriangle,
  FileSearch,
  ArrowRight,
  ShieldAlert,
  SearchCheck,
  Landmark,
  ShieldQuestion,
  RefreshCw
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useUser, useFirestore, useCollection, useMemoFirebase, useDoc } from "@/firebase"
import { collection, query, orderBy, doc, where } from "firebase/firestore"
import { cn } from "@/lib/utils"
import { useSgi } from "@/contexts/sgi-context"

export default function CorporateGovernance() {
  const { user } = useUser()
  const db = useFirestore()
  const { activeClientId } = useSgi()
  const [activeTab, setActiveTab] = React.useState("lira")
  const [isScanningSystems, setIsScanningSystems] = React.useState(false)

  const profileRef = useMemoFirebase(() => {
    if (!db || !user) return null
    return doc(db, "users", user.uid)
  }, [db, user])
  const { data: profile } = useDoc(profileRef)

  const isGlobalAdmin = React.useMemo(() => {
    if (!profile) return false;
    const role = (profile.role || '').toUpperCase();
    return ['SUPER_ADMIN', 'ADMIN'].includes(role);
  }, [profile]);

  const activeCompanyName = React.useMemo(() => {
     if (activeClientId === "all") return "Rede Global (SGI Full)";
     // Buscaria o nome real aqui se necessário, mas o contexto já sincroniza
     return "Unidade Técnica Ativa";
  }, [activeClientId]);

  const handleSystemScan = () => {
    setIsScanningSystems(true)
    setTimeout(() => {
      setIsScanningSystems(false)
      toast({ title: "Varredura CADIN Concluída", description: "Status regular para a unidade ativa." })
    }, 3000)
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <h1 className="text-3xl font-headline font-black text-primary tracking-tight uppercase leading-none">Governança do SGI (Core)</h1>
          <p className="text-muted-foreground font-medium uppercase text-[10px] tracking-widest flex items-center gap-2">
            <ShieldCheck className="size-3 text-primary" /> {activeClientId === 'all' ? 'Conformidade Consolidada' : 'Filtro por Unidade Técnica'}
          </p>
        </div>
        <div className="flex gap-2">
          <Badge variant="outline" className="h-11 border-primary text-primary font-black uppercase text-[10px] bg-white px-4 flex items-center shadow-sm">
            <Building2 className="size-4 mr-2" />
            {activeClientId === 'all' ? "VISÃO GLOBAL" : "UNIDADE ATIVA"}
          </Badge>
          <Button onClick={handleSystemScan} disabled={isScanningSystems} className="gradient-nextcon text-white h-11 px-8 rounded-xl font-black uppercase text-[10px] tracking-widest shadow-lg gap-2">
            {isScanningSystems ? <Loader2 className="size-4 animate-spin" /> : <RefreshCw className="size-4 text-accent" />} 
            Consultar e-Sanções
          </Button>
        </div>
      </header>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full md:w-[900px] grid-cols-4 bg-muted/50 p-1.5 rounded-2xl h-16">
          <TabsTrigger value="lira" className="rounded-xl gap-2 text-[10px] font-black uppercase tracking-widest px-6">LIRA (Legislação)</TabsTrigger>
          <TabsTrigger value="radar_gov" className="rounded-xl gap-2 text-[10px] font-black uppercase tracking-widest px-6 text-accent"><Landmark className="size-4" /> Radar Gov / CADIN</TabsTrigger>
          <TabsTrigger value="swot" className="rounded-xl gap-2 text-[10px] font-black uppercase tracking-widest px-6">Contexto (SWOT)</TabsTrigger>
          <TabsTrigger value="alerts" className="rounded-xl gap-2 text-[10px] font-black uppercase tracking-widest px-6 text-red-600"><ShieldAlert className="size-4" /> Alertas Críticos</TabsTrigger>
        </TabsList>

        <TabsContent value="radar_gov" className="mt-8 space-y-6">
           <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 animate-in slide-in-from-bottom-4">
              <Card className="lg:col-span-2 card-shadow border-none bg-white rounded-[2.5rem] overflow-hidden">
                <CardHeader className="bg-slate-50 border-b p-8">
                   <div className="flex justify-between items-center">
                     <div>
                       <CardTitle className="text-lg font-black text-primary uppercase">Integração Sistemas Oficiais</CardTitle>
                       <CardDescription className="text-[10px] font-bold uppercase tracking-widest">Monitoramento de pendências e sanções estaduais/federais.</CardDescription>
                     </div>
                     <Badge className="bg-blue-600 text-white font-black text-[8px] h-6 px-3">NAI API HUB</Badge>
                   </div>
                </CardHeader>
                <CardContent className="p-8">
                   <div className="space-y-4">
                      <SystemStatusItem 
                        system="CADIN ESTADUAL" 
                        status="Regular" 
                        detail="Sem pendências financeiras registradas." 
                        icon={CheckCircle2} 
                        color="text-emerald-600" 
                      />
                      <SystemStatusItem 
                        system="PORTAL E-SANÇÕES" 
                        status="Vigilância Ativa" 
                        detail="Monitorando registros da Lei 12.846/2013 (Anticorrupção)." 
                        icon={ShieldCheck} 
                        color="text-primary" 
                      />
                      <SystemStatusItem 
                        system="CEIS (EMPRESAS INIDÔNEAS)" 
                        status="Limpo" 
                        detail="Não consta no Cadastro Nacional de Empresas Inidôneas." 
                        icon={ShieldQuestion} 
                        color="text-blue-600" 
                      />
                   </div>
                </CardContent>
              </Card>

              <div className="space-y-6">
                <Card className="bg-[#090e24] text-white p-8 rounded-[2.5rem] relative overflow-hidden group shadow-2xl">
                  <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:scale-110 transition-transform duration-1000"><Zap className="size-32 text-accent" /></div>
                  <div className="relative z-10 space-y-6">
                    <h3 className="text-sm font-black uppercase tracking-widest text-accent flex items-center gap-2">
                      <Zap className="size-4" /> Inteligência Regulatória
                    </h3>
                    <p className="text-xs italic text-slate-300 font-medium leading-relaxed">
                      "A NAI realiza varreduras automáticas a cada 24h em 42 bases de dados governamentais para antecipar riscos de bloqueio contratual."
                    </p>
                    <div className="pt-4 border-t border-white/10">
                       <p className="text-[8px] font-black uppercase text-white/40 tracking-[0.3em]">Status: 100% REGULAR</p>
                    </div>
                  </div>
                </Card>
              </div>
           </div>
        </TabsContent>

        <TabsContent value="lira" className="mt-8 space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
             <Card className="lg:col-span-2 card-shadow border-none bg-white rounded-[2.5rem] overflow-hidden">
                <CardHeader className="bg-slate-50 border-b p-8">
                  <div className="flex justify-between items-center">
                    <div>
                      <CardTitle className="text-lg font-black text-primary uppercase">Matriz de Aplicabilidade Legal</CardTitle>
                      <CardDescription className="text-[10px] font-bold uppercase tracking-widest text-slate-400">
                        {activeClientId === 'all' ? 'Monitoramento consolidado da rede' : `Diagnóstico unitário ativo.`}
                      </CardDescription>
                    </div>
                    <Badge className="bg-primary text-white font-black text-[8px] h-6 px-3">ATUALIZADO JAN/26</Badge>
                  </div>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="divide-y">
                    <LiraItem 
                      law="Portaria Interministerial 13/2026" 
                      scope="SST / Saúde Mental" 
                      evaluation="Atendido" 
                      status="Conforme" 
                      impact="Alto"
                    />
                    <LiraItem 
                      law="Decreto Estadual 4.500/26" 
                      scope="Ambiental / Efluentes" 
                      evaluation="Em Implantação"
                      status="Pendente" 
                      impact="Crítico"
                    />
                    <LiraItem 
                      law="Lei Municipal 843/2025" 
                      scope="Licenciamento de Operação" 
                      evaluation="Vencendo em 45 dias"
                      status="Ação Requerida" 
                      impact="Médio"
                    />
                  </div>
                </CardContent>
             </Card>

             <div className="space-y-6">
               <Card className="bg-[#001F3F] text-white border-none rounded-[2.5rem] p-8 relative overflow-hidden group shadow-2xl">
                  <div className="absolute top-0 right-0 p-6 opacity-10 group-hover:scale-110 transition-transform"><Globe className="size-32 text-accent" /></div>
                  <div className="relative z-10 space-y-6">
                    <h3 className="text-sm font-black uppercase tracking-widest text-accent flex items-center gap-2">
                      <Zap className="size-4" /> NAI Legal Scan
                    </h3>
                    <p className="text-xs italic text-slate-300 font-medium leading-relaxed">
                      "A NAI monitorou 1.204 atos normativos hoje. Identificamos que a Portaria X sobre Resíduos Químicos afeta seus processos vigentes."
                    </p>
                    <Button variant="outline" className="w-full h-11 border-white/20 text-white font-black uppercase text-[10px] hover:bg-white/10 transition-all gap-2">
                      <SearchCheck className="size-3" /> Ver Diário Oficial
                    </Button>
                  </div>
               </Card>
             </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

function SystemStatusItem({ system, status, detail, icon: Icon, color }: any) {
  return (
    <div className="p-5 bg-slate-50 rounded-2xl border border-slate-100 flex items-center justify-between hover:bg-white transition-all group">
      <div className="flex items-center gap-4">
        <div className={cn("p-2.5 rounded-xl bg-white shadow-inner", color)}>
          <Icon className="size-5" />
        </div>
        <div>
          <p className="text-xs font-black text-primary uppercase">{system}</p>
          <p className="text-[10px] text-slate-500 italic">"{detail}"</p>
        </div>
      </div>
      <Badge className={cn(
        "text-[8px] font-black uppercase border-none px-3 h-6",
        status === 'Regular' || status === 'Limpo' ? 'bg-emerald-100 text-emerald-700' : 'bg-primary text-white'
      )}>
        {status}
      </Badge>
    </div>
  )
}

function LiraItem({ law, scope, evaluation, status, impact }: any) {
  return (
    <div className="p-6 flex items-center justify-between hover:bg-slate-50 transition-colors group">
      <div className="flex items-center gap-6">
        <div className="p-3 bg-slate-50 rounded-2xl group-hover:bg-white transition-all shadow-inner"><Scale size={20} className="text-primary/40" /></div>
        <div className="space-y-1">
          <p className="text-xs font-black text-primary uppercase leading-tight">{law}</p>
          <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">{scope}</p>
          <p className="text-[10px] text-slate-500 font-medium italic">"{evaluation}"</p>
        </div>
      </div>
      <div className="flex items-center gap-4">
        <Badge variant="outline" className={cn(
          "text-[8px] font-black uppercase border-none px-2 h-5",
          impact === 'Crítico' ? 'bg-red-100 text-red-700' : 'bg-slate-100 text-slate-500'
        )}>
          Impacto {impact}
        </Badge>
        <Badge className={cn(
          "text-[8px] font-black uppercase border-none px-3 h-5",
          status === 'Conforme' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'
        )}>
          {status}
        </Badge>
      </div>
    </div>
  )
}
