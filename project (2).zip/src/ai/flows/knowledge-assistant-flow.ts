
'use server';
/**
 * @fileOverview NAI_Nextcon - Motor Central de Inteligência Corporativa.
 * Especializado nos três pilares: Comercial, Segurança e Engenharia.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const KnowledgeInputSchema = z.object({
  query: z.string().describe('A dúvida técnica, comercial ou operacional sobre SST.'),
});
export type KnowledgeInput = z.infer<typeof KnowledgeInputSchema>;

const KnowledgeOutputSchema = z.object({
  answer: z.string().describe('Resposta detalhada e técnica.'),
  references: z.array(z.string()).describe('Lista de NRs, itens ou decretos citados.'),
  advice: z.string().describe('Conselho estratégico focado no pilar ativo.'),
});
export type KnowledgeOutput = z.infer<typeof KnowledgeOutputSchema>;

const prompt = ai.definePrompt({
  name: 'NAI_Nextcon_Prompt',
  input: {schema: KnowledgeInputSchema},
  output: {schema: KnowledgeOutputSchema},
  prompt: `Você é o agente "NAI", o motor central de inteligência técnica da Nextcon Saúde Empresarial.
Sua missão é atuar como uma consultoria de elite em Saúde e Segurança do Trabalho, operando sob três pilares fundamentais na seguinte ordem de prioridade:

1. COMERCIAL - GERADOR DE PROPOSTAS:
- Foco em viabilidade financeira, orçamentos, ROI e estratégias de venda SST.
- Ajude a estruturar escopos técnicos que façam sentido para o faturamento e para o cliente.

2. SEGURANÇA DO TRABALHO:
- Foco em conformidade técnica de campo: PGR, GRO, LTCAT e NRs.
- Analise riscos, sugira medidas de controle e verifique enquadramentos legais rigorosos.

3. ENGENHARIA DE SEGURANÇA:
- Foco em gestão de saúde ocupacional: PCMSO, ASO Digital, Exames e Vigilância Epidemiológica.
- Garanta que os protocolos médicos estejam integrados aos riscos de campo.

DIRETRIZES DE ATUAÇÃO:
1. Responda estritamente de acordo com as leis e NRs vigentes em 2026.
2. Identifique a Persona/Pilar solicitada no input e adapte seu tom de voz (Vendedor, Técnico ou Clínico).
3. Utilize autoridade técnica, citando decretos e itens normativos.
4. No campo 'advice', forneça uma recomendação prática de conformidade ou ganho financeiro para o gestor.

PERGUNTA DO USUÁRIO: {{{query}}}`,
});

export async function runKnowledgeAssistant(input: KnowledgeInput): Promise<KnowledgeOutput> {
  const {output} = await prompt(input);
  if (!output) {
    throw new Error('A NAI não pôde processar sua dúvida agora.');
  }
  return output;
}

ai.defineFlow(
  {
    name: 'NAI_Nextcon_Flow',
    inputSchema: KnowledgeInputSchema,
    outputSchema: KnowledgeOutputSchema,
  },
  async input => {
    return runKnowledgeAssistant(input);
  }
);
