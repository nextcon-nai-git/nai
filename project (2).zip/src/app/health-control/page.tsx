"use client"

import * as React from "react"
import { 
  HeartPulse, 
  Stethoscope, 
  CheckCircle2, 
  Plus, 
  QrCode, 
  Zap, 
  Users, 
  Search, 
  Loader2, 
  Clock, 
  ShieldCheck, 
  Camera,
  Building2,
  User,
  Calendar as CalendarIcon,
  FileText,
  ChevronRight,
  AlertTriangle
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger,
  DialogFooter
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import { useUser, useFirestore, useCollection, useMemoFirebase } from "@/firebase"
import { collection, query, orderBy, doc, limit, addDoc, serverTimestamp, where, collectionGroup, getDoc } from "firebase/firestore"
import { cn } from "@/lib/utils"
import { updateDocumentNonBlocking } from "@/firebase/non-blocking-updates"
import { DigitalSignatureDialog } from "@/components/medical/digital-signature-dialog"
import type { MedicalAppointment, S2220Event } from "@/types/schema"
import { useSgi } from "@/contexts/sgi-context"
import { ESOCIAL_TP_ASO, ESOCIAL_RES_ASO, ESOCIAL_IND_RESULT, NR35_MANDATORY_EXAMS } from "@/lib/esocial-codes"

export default function HealthControl() {
  const { toast } = useToast()
  const { user, role, companyId: userCompanyId } = useUser()
  const db = useFirestore()
  const { activeClientId } = useSgi()
  
  const [searchTerm, setSearchTerm] = React.useState("")
  const [isSignDialogOpen, setIsSignDialogOpen] = React.useState(false)
  const [selectedApptForSign, setSelectedApptForSign] = React.useState<MedicalAppointment | null>(null)
  
  const [isAsoFormOpen, setIsAsoFormOpen] = React.useState(false)
  const [asoPayload, setAsoPayload] = React.useState<any>(null)

  const [isScheduleOpen, setIsScheduleOpen] = React.useState(false)
  const [isScheduling, setIsScheduling] = React.useState(false)
  const [newAppt, setNewAppt] = React.useState({
    employeeId: "",
    companyId: "",
    type: "Periódico" as const,
    date: new Date().toISOString().split('T')[0],
    time: "08:00"
  })

  const isGlobalAdmin = React.useMemo(() => ['SUPER_ADMIN', 'ADMIN', 'ENGINEER'].includes(role || ''), [role]);

  const companiesQuery = useMemoFirebase(() => {
    if (!db || !role) return null;
    if (isGlobalAdmin) {
      return query(collection(db, "companies"), orderBy("name", "asc"));
    }
    if (userCompanyId) {
      return query(collection(db, "companies"), where("__name__", "==", userCompanyId));
    }
    return null;
  }, [db, isGlobalAdmin, userCompanyId, role]);

  const { data: companies } = useCollection(companiesQuery)

  const appointmentsQuery = useMemoFirebase(() => {
    if (!db || !role || activeClientId === "unauthorized") return null
    
    if (activeClientId === "all") {
      if (!isGlobalAdmin) return null;
      return query(collectionGroup(db, "agendamentos"), orderBy("data_hora", "asc"), limit(50))
    }
    
    return query(collection(db, "companies", activeClientId, "agendamentos"), orderBy("data_hora", "asc"), limit(50))
  }, [db, activeClientId, role, isGlobalAdmin])
  
  const { data: appointments, isLoading } = useCollection<MedicalAppointment>(appointmentsQuery)

  const filteredAppointments = React.useMemo(() => {
    if (!appointments) return []
    const term = searchTerm.toLowerCase()
    return appointments.filter(a => 
      (a.colaborador_nome || "").toLowerCase().includes(term)
    )
  }, [appointments, searchTerm])

  const handleCheckIn = (appt: MedicalAppointment) => {
    if (!db || !appt.companyId) return
    const docRef = doc(db, "companies", appt.companyId, "agendamentos", appt.id)
    updateDocumentNonBlocking(docRef, {
      status: "Em Espera",
      check_in_realizado: true,
      check_in_at: new Date().toISOString()
    })
    toast({ title: "Check-in Realizado", description: `${appt.colaborador_nome} entrou na fila.` })
  }

  const handleStartConsultation = (appt: MedicalAppointment) => {
    if (!db || !appt.companyId) return
    const docRef = doc(db, "companies", appt.companyId, "agendamentos", appt.id)
    updateDocumentNonBlocking(docRef, { status: "Em Atendimento" })
    setSelectedApptForSign(appt)
    setIsAsoFormOpen(true)
  }

  // Prepara o payload S-2220 para assinatura
  const prepareAsoFinalization = async (formData: any) => {
    if (!selectedApptForSign || !db) return;

    // Busca dados da empresa e funcionário para o payload
    const companyRef = doc(db, "companies", selectedApptForSign.companyId);
    const companySnap = await getDoc(companyRef);
    const employeeRef = doc(db, "companies", selectedApptForSign.companyId, "employees", selectedApptForSign.colaborador_id);
    const employeeSnap = await getDoc(employeeRef);

    if (!companySnap.exists() || !employeeSnap.exists()) {
      toast({ variant: "destructive", title: "Erro de Vínculo", description: "Dados de empresa ou colaborador não localizados." });
      return;
    }

    const companyData = companySnap.data();
    const empData = employeeSnap.data();

    // REGRA NAI: Validação NR-35
    if (empData.isHeightWork) {
      const examCodes = formData.exames.map((e: any) => e.procExm);
      const missingCodes = NR35_MANDATORY_EXAMS.filter(m => !examCodes.includes(m.code));
      if (missingCodes.length > 0) {
        toast({ 
          variant: "destructive", 
          title: "Bloqueio NR-35", 
          description: `Para Trabalho em Altura, os exames [${missingCodes.map(m => m.name).join(', ')}] são obrigatórios.` 
        });
        return;
      }
    }

    const payload: S2220Event = {
      evtMonit: {
        id: `NAI-${Date.now()}-${selectedApptForSign.colaborador_id}`,
        ideEmpregador: {
          tpInsc: 1,
          nrInsc: companyData.cnpj.replace(/\D/g, '')
        },
        ideTrabalhador: {
          cpfTrab: empData.cpf.replace(/\D/g, ''),
          matricula: empData.id
        },
        aso: {
          dtAso: new Date().toISOString().split('T')[0],
          tpAso: formData.tpAso,
          resAso: formData.resAso,
          exame: formData.exames.map((ex: any) => ({
            ...ex,
            ordExme: 1
          })),
          medico: {
            nmMed: user?.displayName || "Médico Examinador",
            nrCrm: "12345", // Mock de perfil
            ufCrm: "PR"
          }
        }
      }
    };

    setAsoPayload(payload);
    setIsAsoFormOpen(false);
    setIsSignDialogOpen(true);
  }

  const handleFinalizeWithSignature = async (signatureData: any) => {
    if (!db || !user || !selectedApptForSign || !asoPayload) return
    
    const appt = selectedApptForSign
    const docRef = doc(db, "companies", appt.companyId, "agendamentos", appt.id)
    updateDocumentNonBlocking(docRef, { status: "Concluído" })

    const asoRef = collection(db, "companies", appt.companyId, "aso_attendances")
    await addDoc(asoRef, {
      ...asoPayload,
      agendamento_id: appt.id,
      medico_id: user.uid,
      employeeName: appt.colaborador_nome,
      companyId: appt.companyId,
      data_emissao: new Date().toISOString(),
      resultado: asoPayload.evtMonit.aso.resAso === 1 ? "Apto" : "Inapto",
      signature_info: signatureData,
      status_esocial: "Pendente",
      createdAt: serverTimestamp()
    });

    toast({ title: "ASO Protocolado", description: "Evento S-2220 gerado e assinado." });
    setSelectedApptForSign(null)
    setAsoPayload(null)
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4 text-left">
        <div className="space-y-1">
          <h1 className="text-3xl font-headline font-black text-primary tracking-tight uppercase">Clínica (ASO)</h1>
          <p className="text-muted-foreground font-medium uppercase text-[10px] tracking-widest flex items-center gap-2">
            <Zap className="size-3 text-accent" /> Gestão Multi-tenant de Atendimentos.
          </p>
        </div>
        <Button onClick={() => setIsScheduleOpen(true)} className="gradient-nextcon text-white h-11 px-6 rounded-xl font-black uppercase text-[10px] tracking-widest shadow-lg gap-2">
          <Plus className="size-4" /> Agendar Exame
        </Button>
      </header>

      <div className="relative group">
        <Search className="absolute left-4 top-3.5 size-5 text-slate-300 group-focus-within:text-primary transition-colors" />
        <Input 
          placeholder="Pesquisar paciente na fila..." 
          className="pl-12 h-12 bg-white border-none shadow-sm rounded-xl font-medium"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      <Card className="card-shadow border-none bg-white rounded-[2rem] overflow-hidden">
        <CardHeader className="bg-slate-50 border-b py-6 px-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="text-left w-full">
            <CardTitle className="text-lg font-black text-primary uppercase">Fila de Atendimento</CardTitle>
            <CardDescription className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Status em tempo real das triagens e ASOs.</CardDescription>
          </div>
          <Badge className="bg-emerald-100 text-emerald-700 border-none font-black uppercase text-[8px] h-6 px-3 whitespace-nowrap">
            Live Feed: {activeClientId === 'all' ? 'Rede Global' : 'Unidade Ativa'}
          </Badge>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader className="bg-slate-50/50">
              <TableRow className="hover:bg-transparent border-none text-[10px] font-black uppercase">
                <TableHead className="pl-8 py-4">Colaborador / Unidade</TableHead>
                <TableHead>Tipo de Exame</TableHead>
                <TableHead className="text-center">Status</TableHead>
                <TableHead className="pr-8 text-right">Ação</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow><TableCell colSpan={4} className="py-20 text-center"><Loader2 className="size-10 animate-spin mx-auto opacity-20 text-primary" /></TableCell></TableRow>
              ) : filteredAppointments.length > 0 ? filteredAppointments.map((appt) => (
                <TableRow key={appt.id} className="hover:bg-slate-50/50 transition-colors">
                  <TableCell className="pl-8 py-5">
                    <p className="font-black text-xs text-primary uppercase leading-tight">{appt.colaborador_nome}</p>
                    <p className="text-[9px] text-slate-400 font-bold uppercase mt-1">ID: {appt.colaborador_id}</p>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className="text-[9px] font-black uppercase border-primary/10 text-primary/60 px-2 h-5">
                      {appt.tipo}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-center">
                    <Badge className={cn(
                      "text-[8px] font-black uppercase border-none px-3 h-6",
                      appt.status === 'Concluído' ? 'bg-emerald-100 text-emerald-700' : 
                      appt.status === 'Em Espera' ? 'bg-amber-100 text-amber-700 animate-pulse' : 'bg-blue-100 text-blue-700'
                    )}>
                      {appt.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="pr-8 text-right">
                    <div className="flex justify-end gap-2">
                       {appt.status === 'Agendado' && (
                         <Button onClick={() => handleCheckIn(appt)} size="sm" className="h-9 px-4 font-black uppercase text-[9px] rounded-xl bg-primary text-white shadow-md">
                           Check-in
                         </Button>
                       )}
                       {appt.status === 'Em Espera' && (
                         <Button onClick={() => handleStartConsultation(appt)} size="sm" className="h-9 px-4 font-black uppercase text-[9px] rounded-xl bg-blue-600 text-white shadow-md">
                           Iniciar Atendimento
                         </Button>
                       )}
                    </div>
                  </TableCell>
                </TableRow>
              )) : (
                <TableRow>
                  <TableCell colSpan={4} className="py-24 text-center opacity-30 font-black uppercase text-[10px] tracking-widest">
                    Nenhum paciente na fila de hoje
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* MODAL E-SOCIAL S-2220 */}
      <Dialog open={isAsoFormOpen} onOpenChange={setIsAsoFormOpen}>
        <DialogContent className="sm:max-w-[700px] rounded-[2.5rem] border-none shadow-2xl p-0 overflow-hidden bg-white text-left">
          <DialogHeader className="p-8 bg-primary text-white space-y-2">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-white/10 rounded-lg text-accent"><FileText className="size-5" /></div>
              <DialogTitle className="text-xl font-headline font-black uppercase">Finalização ASO (S-2220)</DialogTitle>
            </div>
            <DialogDescription className="text-white/60 font-medium italic">Estruture os dados para protocolo eSocial.</DialogDescription>
          </DialogHeader>
          <div className="p-8 space-y-6">
            <div className="p-4 bg-slate-50 rounded-2xl border-l-4 border-accent">
              <p className="text-[10px] font-black uppercase text-slate-400">Paciente</p>
              <p className="text-sm font-bold text-primary uppercase">{selectedApptForSign?.colaborador_nome}</p>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-[10px] font-black uppercase text-slate-400 ml-1">Tipo de ASO (Tabela 20)</label>
                <Select defaultValue="2" onValueChange={(v) => {}}>
                  <SelectTrigger className="h-12 bg-slate-50 border-none rounded-xl font-bold shadow-inner">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {ESOCIAL_TP_ASO.map(t => <SelectItem key={t.value} value={String(t.value)}>{t.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-black uppercase text-slate-400 ml-1">Resultado (Tabela 20)</label>
                <Select defaultValue="1">
                  <SelectTrigger className="h-12 bg-slate-50 border-none rounded-xl font-bold shadow-inner">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {ESOCIAL_RES_ASO.map(t => <SelectItem key={t.value} value={String(t.value)}>{t.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="p-6 bg-slate-50 rounded-3xl border space-y-4">
               <h4 className="text-[10px] font-black uppercase text-primary tracking-widest flex items-center gap-2">
                 <ShieldCheck className="size-3" /> Exames Realizados
               </h4>
               <div className="space-y-2">
                 <div className="flex items-center justify-between p-3 bg-white border rounded-xl shadow-sm">
                    <div className="text-[10px] font-bold text-slate-600">0001 - AVALIAÇÃO CLÍNICA</div>
                    <Badge className="bg-emerald-100 text-emerald-700 h-5 text-[8px] uppercase">Normal</Badge>
                 </div>
                 {/* Exemplo de Exame NR-35 */}
                 <div className="flex items-center justify-between p-3 bg-white border rounded-xl shadow-sm">
                    <div className="text-[10px] font-bold text-slate-600">0462 - ELETROCARDIOGRAMA</div>
                    <Badge className="bg-emerald-100 text-emerald-700 h-5 text-[8px] uppercase">Normal</Badge>
                 </div>
               </div>
            </div>

            <Button 
              onClick={() => prepareAsoFinalization({
                tpAso: 2,
                resAso: 1,
                exames: [
                  { dtExm: new Date().toISOString().split('T')[0], procExm: "0001", indResult: 1 },
                  { dtExm: new Date().toISOString().split('T')[0], procExm: "0462", indResult: 1 }
                ]
              })}
              className="w-full h-16 bg-primary text-white font-black uppercase text-xs tracking-widest rounded-2xl shadow-xl"
            >
              Prosseguir p/ Assinatura Digital
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <DigitalSignatureDialog 
        isOpen={isSignDialogOpen}
        onOpenChange={setIsSignDialogOpen}
        onSign={handleFinalizeWithSignature}
        patientName={selectedApptForSign?.colaborador_nome || ""}
        doctorProfile={null}
      />
    </div>
  )
}
