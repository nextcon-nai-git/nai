"use client";

import * as React from "react"
import { 
  Users, 
  UserPlus, 
  Search, 
  Loader2, 
  MoreVertical, 
  Trash2, 
  Pencil, 
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Zap,
  Globe,
  Stethoscope,
  Calendar,
  AlertTriangle,
  HeartPulse,
  ChevronRight,
  ClipboardList,
  ShieldCheck,
  Activity,
  FileText
} from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog"
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
  SheetFooter,
} from "@/components/ui/sheet"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form"
import { useCollection, useUser, useMemoFirebase, useFirestore, useDoc } from "@/firebase"
import { collection, query, orderBy, collectionGroup, doc, where } from "firebase/firestore"
import { addDocumentNonBlocking, deleteDocumentNonBlocking } from "@/firebase/non-blocking-updates"
import { useToast } from "@/hooks/use-toast"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { z } from "zod"
import { Skeleton } from "@/components/ui/skeleton"
import { cn } from "@/lib/utils"
import { extractEmployeesFromText } from "@/ai/flows/employee-extraction-flow"
import { useSearchParams } from "next/navigation"
import { ScrollArea } from "@/components/ui/scroll-area"

// Schema de validação eSocial Ready
const employeeFormSchema = z.object({
  name: z.string().min(3, "Nome deve ter pelo menos 3 caracteres"),
  cpf: z.string().regex(/^\d{3}\.\d{3}\.\d{3}-\d{2}$/, "CPF deve estar no formato 000.000.000-00"),
  companyId: z.string().min(1, "Selecione uma unidade"),
  jobTitle: z.string().min(2, "Informe o cargo"),
  jobCbo: z.string().optional(),
  status: z.enum(["active", "leave", "fired"]),
})

type EmployeeFormValues = z.infer<typeof employeeFormSchema>

function EmployeesList() {
  const { user } = useUser()
  const db = useFirestore()
  const { toast } = useToast()
  const searchParams = useSearchParams()
  const queryFromUrl = searchParams.get('q') || ""
  
  const [searchTerm, setSearchTerm] = React.useState(queryFromUrl)
  const [selectedCompanyId, setSelectedCompanyId] = React.useState<string>("all")
  const [isCreateOpen, setIsCreateOpen] = React.useState(false)
  const [isAiImportOpen, setIsAiImportOpen] = React.useState(false)
  const [isSubmitting, setIsSubmitting] = React.useState(false)
  const [isAiLoading, setIsAiLoading] = React.useState(false)
  const [aiRawText, setAiRawText] = React.useState("")
  const [selectedEmployee, setSelectedEmployee] = React.useState<any | null>(null)

  // 1. Perfil do Usuário para RBAC rigoroso
  const profileRef = useMemoFirebase(() => {
    if (!db || !user) return null
    return doc(db, "users", user.uid)
  }, [db, user])
  const { data: profile } = useDoc(profileRef)

  const isGlobalAdmin = React.useMemo(() => {
    if (!profile) return false;
    const role = (profile.role || '').toUpperCase();
    return ['SUPER_ADMIN', 'ADMIN', 'ENGINEER', 'DOCTOR'].includes(role);
  }, [profile]);

  // 2. Consultas Firestore protegidas
  const companiesQuery = useMemoFirebase(() => {
    if (!db || !profile) return null
    if (isGlobalAdmin) {
      return query(collection(db, "companies"), orderBy("name", "asc"))
    }
    if (profile.companyId) {
      return query(collection(db, "companies"), where("__name__", "==", profile.companyId))
    }
    return null
  }, [db, profile, isGlobalAdmin])
  const { data: companies } = useCollection(companiesQuery)

  const employeesQuery = useMemoFirebase(() => {
    if (!db || !profile) return null
    
    if (isGlobalAdmin && selectedCompanyId === "all") {
      return query(collectionGroup(db, "employees"))
    } 
    
    const companyIdToFilter = selectedCompanyId !== "all" ? selectedCompanyId : profile.companyId;
    
    if (companyIdToFilter) {
      return query(collection(db, "companies", companyIdToFilter, "employees"), orderBy("name", "asc"))
    }
    
    return null
  }, [db, profile, selectedCompanyId, isGlobalAdmin])

  const { data: employees, isLoading: loadingEmployees } = useCollection(employeesQuery)

  // 3. Lógica de Saúde (Calculada em Memória para Performance)
  const getHealthStatus = (nextAsoDate?: string) => {
    if (!nextAsoDate) return { label: "Pendente", color: "text-slate-400 bg-slate-100" };
    
    const today = new Date();
    const nextDate = new Date(nextAsoDate);
    const diffDays = Math.ceil((nextDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));

    if (diffDays < 0) return { label: "Vencido", color: "text-red-700 bg-red-100", icon: AlertTriangle };
    if (diffDays <= 30) return { label: "A Vencer", color: "text-amber-700 bg-amber-100", icon: Clock };
    return { label: "Regular", color: "text-emerald-700 bg-emerald-100", icon: CheckCircle2 };
  };

  // 4. Checklists Médicos Dinâmicos por Atividade
  const getClinicalChecklist = (jobTitle: string | undefined | null) => {
    const title = (jobTitle || "").toLowerCase();
    const isHeight = title.includes("altura") || title.includes("montador") || title.includes("pedreiro");
    const isElectric = title.includes("eletricista") || title.includes("manutenção");
    const isIndustry = title.includes("operador") || title.includes("mecânico") || title.includes("soldador") || title.includes("serralheiro");

    const baseItems = [
      { id: "v1", label: "PAS/PAD em repouso < 140x90mmHg", mandatory: true },
      { id: "v2", label: "Meatoscopia sem obstrução total", mandatory: true },
      { id: "v3", label: "Frequência Cardíaca (60-100 bpm)", mandatory: true },
      { id: "v4", label: "Ausência de queixas álgicas incapacitantes", mandatory: false }
    ];

    if (isHeight) return [
      ...baseItems,
      { id: "h1", label: "Teste de Romberg (Estabilidade)", mandatory: true },
      { id: "h2", label: "Coordenação motora e equilíbrio dinâmico", mandatory: true },
      { id: "h3", label: "Glicemia Capilar (Jejum ou Aleatória)", mandatory: true }
    ];

    if (isElectric) return [
      ...baseItems,
      { id: "e1", label: "Eletrocardiograma (ECG) laudado", mandatory: true },
      { id: "e2", label: "Teste de acuidade visual", mandatory: true }
    ];

    if (isIndustry) return [
      ...baseItems,
      { id: "i1", label: "Acuidade Visual (Tabela de Snellen)", mandatory: true },
      { id: "i2", label: "Avaliação Osteomuscular (Membros Superiores)", mandatory: true }
    ];

    return baseItems;
  };

  const filteredEmployees = React.useMemo(() => {
    if (!employees) return []
    const term = searchTerm.toLowerCase()
    return employees.filter(emp => 
      (emp.name || "").toLowerCase().includes(term) || 
      (emp.cpf || "").includes(term)
    ).sort((a, b) => (a.name || "").localeCompare(b.name || ""))
  }, [employees, searchTerm])

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 text-left">
        <div className="space-y-1">
          <h1 className="text-3xl font-headline font-black text-primary tracking-tight uppercase leading-none">Quadro de Vidas</h1>
          <p className="text-muted-foreground font-medium uppercase text-[9px] tracking-widest mt-2 flex items-center gap-2">
            <Stethoscope className="size-3 text-accent" /> Vigilância Médica e eSocial Compliance.
          </p>
        </div>

        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setIsAiImportOpen(true)} className="border-primary text-primary font-black uppercase text-[10px] tracking-widest h-12 px-6 rounded-xl gap-2">
            <Sparkles className="size-4 text-accent" /> Captura NAI
          </Button>
          <Button onClick={() => setIsCreateOpen(true)} className="bg-primary text-white font-black uppercase text-[10px] tracking-widest h-12 px-8 rounded-xl shadow-lg gap-2">
            <UserPlus className="size-4 text-accent" /> Novo Colaborador
          </Button>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1 group">
          <Search className="absolute left-4 top-3.5 size-4 text-slate-300 group-focus-within:text-primary transition-colors" />
          <Input 
            placeholder="Pesquisar por nome ou CPF..." 
            className="pl-12 h-12 bg-white border-none shadow-sm rounded-xl font-medium" 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        {isGlobalAdmin && (
          <div className="w-full md:w-72">
            <Select value={selectedCompanyId} onValueChange={setSelectedCompanyId}>
              <SelectTrigger className="h-12 bg-white border-none shadow-sm rounded-xl font-bold uppercase text-[10px]">
                <Globe className="size-4 mr-2 text-slate-400" />
                <SelectValue placeholder="Filtrar Unidade" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Visão Global</SelectItem>
                {companies?.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        )}
      </div>

      <Card className="card-shadow border-none bg-white rounded-[2rem] overflow-hidden">
        <CardContent className="p-0">
          <Table>
            <TableHeader className="bg-slate-50/50">
              <TableRow>
                <TableHead className="text-[10px] font-black uppercase py-5 pl-8 text-left">Colaborador</TableHead>
                <TableHead className="text-[10px] font-black uppercase text-left">Vencimento ASO</TableHead>
                <TableHead className="text-[10px] font-black uppercase text-center">Status Saúde</TableHead>
                <TableHead className="text-[10px] font-black uppercase text-center">Aptidão</TableHead>
                <TableHead className="text-right pr-8"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loadingEmployees ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <TableRow key={i}><TableCell colSpan={5} className="pl-8 py-6"><Skeleton className="h-8 w-full" /></TableCell></TableRow>
                ))
              ) : filteredEmployees.length > 0 ? filteredEmployees.map((emp) => {
                const healthStatus = getHealthStatus(emp.nextAsoDate);
                const StatusIcon = healthStatus.icon;

                return (
                  <Sheet key={`${emp.companyId}_${emp.id}`}>
                    <SheetTrigger asChild>
                      <TableRow 
                        className="hover:bg-slate-50/50 transition-colors group cursor-pointer border-b last:border-none"
                        onClick={() => setSelectedEmployee(emp)}
                      >
                        <TableCell className="pl-8 py-5">
                          <div className="flex items-center gap-4">
                            <div className="size-11 rounded-2xl bg-primary/5 flex items-center justify-center text-primary font-black text-sm shadow-inner shrink-0 group-hover:bg-primary group-hover:text-white transition-all">
                              {emp.name?.substring(0, 2).toUpperCase()}
                            </div>
                            <div className="text-left">
                              <p className="font-black text-xs text-primary uppercase leading-tight">{emp.name}</p>
                              <p className="text-[9px] text-slate-400 font-bold uppercase mt-1">Cargo: {emp.job_role?.title || 'Não definido'}</p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="text-left">
                          <div className="space-y-1">
                            <p className="text-xs font-black text-primary">
                              {emp.nextAsoDate ? new Date(emp.nextAsoDate).toLocaleDateString('pt-BR') : "NÃO DEFINIDO"}
                            </p>
                            <div className="flex items-center gap-1.5">
                               <Calendar className="size-3 text-slate-300" />
                               <span className="text-[9px] font-bold text-slate-400 uppercase">Periódico NR-07</span>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="text-center">
                          <Badge className={cn("text-[9px] font-black uppercase border-none px-3 h-6", healthStatus.color)}>
                            {StatusIcon && <StatusIcon className="size-2.5 mr-1" />}
                            {healthStatus.label}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-center">
                          <Badge className={cn(
                            "text-[9px] font-black uppercase border-none px-3 h-6",
                            emp.fitnessStatus === 'Apto' ? 'bg-emerald-100 text-emerald-700' :
                            emp.fitnessStatus === 'Inapto' ? 'bg-red-100 text-red-700' : 'bg-slate-100 text-slate-400'
                          )}>
                            {emp.fitnessStatus || "PENDENTE"}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right pr-8">
                          <ChevronRight className="size-5 text-slate-200 group-hover:text-primary transition-colors ml-auto" />
                        </TableCell>
                      </TableRow>
                    </SheetTrigger>
                    
                    <SheetContent className="sm:max-w-xl p-0 border-none shadow-2xl flex flex-col bg-white">
                      {emp && (
                        <>
                          <SheetHeader className="p-10 bg-primary text-white relative shrink-0">
                            <div className="absolute top-0 right-0 p-8 opacity-10"><HeartPulse className="size-32 text-accent" /></div>
                            <div className="relative z-10 text-left space-y-4">
                              <Badge className="bg-accent text-primary border-none text-[8px] font-black uppercase tracking-[0.3em]">Prontuário Digital v2.6</Badge>
                              <div className="flex items-center gap-5">
                                <div className="size-16 rounded-[1.5rem] bg-white/10 flex items-center justify-center text-3xl font-black border border-white/20 shadow-2xl">
                                  {emp.name?.substring(0, 2).toUpperCase()}
                                </div>
                                <div>
                                  <SheetTitle className="text-2xl font-headline font-black uppercase tracking-tight text-white">{emp.name}</SheetTitle>
                                  <SheetDescription className="text-white/60 font-bold uppercase text-[10px] mt-1 tracking-widest">
                                    {emp.job_role?.title || 'Não definido'} | CPF: {emp.cpf}
                                  </SheetDescription>
                                </div>
                              </div>
                            </div>
                          </SheetHeader>

                          <ScrollArea className="flex-1 p-10 scrollbar-thin">
                            <div className="space-y-10 pb-20">
                              {/* 1. Protocolo de Exame Clínico */}
                              <div className="space-y-4">
                                <h4 className="text-[10px] font-black uppercase text-primary tracking-[0.2em] flex items-center gap-2">
                                  <ClipboardList className="size-4 text-accent" /> Protocolo de Exame Clínico
                                </h4>
                                <div className="p-6 bg-slate-50 rounded-[2rem] border border-slate-100 space-y-4 shadow-inner text-left">
                                  <p className="text-[9px] font-bold text-slate-500 italic mb-4 uppercase">Roteiro baseado na atividade: {emp.job_role?.title || 'Geral'}</p>
                                  <div className="space-y-3">
                                    {getClinicalChecklist(emp.job_role?.title).map((item) => (
                                      <div key={item.id} className="flex items-center gap-3 group">
                                        <div className="size-5 rounded border-2 border-slate-200 group-hover:border-primary/20 transition-all flex items-center justify-center bg-white shadow-sm">
                                          <CheckCircle2 className="size-3.5 text-emerald-500 opacity-20" />
                                        </div>
                                        <span className="text-xs font-bold text-slate-600 leading-tight">
                                          {item.label}
                                          {item.mandatory && <span className="text-red-500 ml-1">*</span>}
                                        </span>
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              </div>

                              {/* 2. Riscos Ocupacionais (PGR) */}
                              <div className="space-y-4">
                                <h4 className="text-[10px] font-black uppercase text-primary tracking-[0.2em] flex items-center gap-2">
                                  <ShieldCheck className="size-4 text-accent" /> Exposição Ocupacional (PGR)
                                </h4>
                                <div className="grid grid-cols-2 gap-3">
                                  {emp.healthRisks?.map((risk: string, i: number) => (
                                    <Badge key={i} variant="outline" className="bg-white border-slate-100 text-slate-500 text-[8px] font-black h-8 px-3 uppercase rounded-xl shadow-sm">
                                      {risk}
                                    </Badge>
                                  )) || <p className="text-[9px] text-slate-400 italic">Mapeando riscos no PGR...</p>}
                                </div>
                              </div>

                              {/* 3. Indicadores de Saúde */}
                              <div className="space-y-4">
                                <h4 className="text-[10px] font-black uppercase text-primary tracking-[0.2em] flex items-center gap-2">
                                  <Activity className="size-4 text-accent" /> Histórico Biométrico
                                </h4>
                                <div className="grid grid-cols-2 gap-4">
                                  <div className="p-5 bg-white border border-slate-100 rounded-3xl shadow-sm">
                                    <p className="text-[8px] font-black text-slate-400 uppercase mb-1">Última P.A.</p>
                                    <p className="text-lg font-black text-primary">128/84 <span className="text-[8px] font-bold text-slate-400 ml-1">mmHg</span></p>
                                  </div>
                                  <div className="p-5 bg-white border border-slate-100 rounded-3xl shadow-sm">
                                    <p className="text-[8px] font-black text-slate-400 uppercase mb-1">Freq. Cardíaca</p>
                                    <p className="text-lg font-black text-primary">74 <span className="text-[8px] font-bold text-slate-400 ml-1">bpm</span></p>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </ScrollArea>

                          <SheetFooter className="p-10 bg-slate-50 border-t shrink-0 flex flex-col gap-4">
                            <div className="flex gap-3 w-full">
                              <Button variant="outline" className="flex-1 h-14 rounded-2xl font-black uppercase text-[10px] border-primary text-primary">
                                Editar Cadastro
                              </Button>
                              <Button className="flex-1 h-14 bg-primary text-white font-black uppercase text-[10px] rounded-2xl shadow-xl gap-2">
                                <FileText className="size-4 text-accent" /> Abrir ASO Atual
                              </Button>
                            </div>
                            <p className="text-[7px] text-slate-300 font-black uppercase text-center tracking-[0.4em]">Protocolo HIPAA Compliance v2.7</p>
                          </SheetFooter>
                        </>
                      )}
                    </SheetContent>
                  </Sheet>
                )
              }) : (
                <TableRow>
                  <TableCell colSpan={5} className="py-24 text-center opacity-30">
                    <AlertCircle className="size-16 mx-auto mb-4 text-primary" />
                    <p className="font-black uppercase text-sm tracking-widest">Nenhum registro localizado</p>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* MODAL DE IMPORTAÇÃO IA */}
      <Dialog open={isAiImportOpen} onOpenChange={setIsAiImportOpen}>
        <DialogContent className="sm:max-w-[600px] rounded-[2.5rem] border-none shadow-2xl p-0 overflow-hidden bg-white">
          <DialogHeader className="p-8 bg-primary text-white space-y-2">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-white/10 rounded-lg"><Zap className="size-5 text-accent" /></div>
              <DialogTitle className="text-xl font-headline font-black uppercase">Captura Massiva NAI</DialogTitle>
            </div>
            <DialogDescription className="text-white/60 font-medium">Cole o texto bruto para extração de nomes, CPFs e cargos via IA.</DialogDescription>
          </DialogHeader>
          <div className="p-8 space-y-6">
             <Textarea 
                placeholder="Cole o quadro de vidas aqui..." 
                className="min-h-[200px] bg-slate-50 border-none rounded-2xl p-4 text-xs"
                value={aiRawText}
                onChange={e => setAiRawText(e.target.value)}
             />
             <Button className="w-full h-14 bg-primary text-white font-black uppercase text-xs rounded-2xl shadow-xl">
               Processar Extração Inteligente
             </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}

export default function EmployeesPage() {
  return (
    <React.Suspense fallback={<div className="p-20 text-center"><Loader2 className="animate-spin mx-auto opacity-20" /></div>}>
      <div className="pb-20 animate-in fade-in duration-500">
        <EmployeesList />
      </div>
    </React.Suspense>
  )
}
