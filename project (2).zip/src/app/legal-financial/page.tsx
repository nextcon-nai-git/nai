"use client"

import * as React from "react"
import { Scale, Calculator, TrendingDown, Landmark, FileText, Loader2, Gavel, DollarSign, User } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Badge } from "@/components/ui/badge"
import { useCollection, useUser, useMemoFirebase, useFirestore, useDoc } from "@/firebase"
import { collection, query, orderBy, collectionGroup, doc, where } from "firebase/firestore"
import { cn } from "@/lib/utils"
import { useSgi } from "@/contexts/sgi-context"

export default function LegalFinancial() {
  const { user } = useUser()
  const db = useFirestore()
  const { activeClientId } = useSgi()
  const [fapValue, setFapValue] = React.useState([0.74])
  const [payroll, setPayroll] = React.useState(150000)

  const profileRef = useMemoFirebase(() => {
    if (!db || !user) return null
    return doc(db, "users", user.uid)
  }, [db, user])
  const { data: profile } = useDoc(profileRef)

  // Busca perícias reais do Firestore protegendo a hierarquia multi-tenant
  const expertisesQuery = useMemoFirebase(() => {
    if (!db) return null
    
    // Se for Visão Global, utiliza collectionGroup para cruzar todos os processos
    if (activeClientId === "all") {
      return query(collectionGroup(db, "legalExpertises"), orderBy("date", "desc"))
    } 
    
    // Filtro cirúrgico por unidade selecionada
    return query(collection(db, "companies", activeClientId, "legalExpertises"), orderBy("date", "desc"))
  }, [db, activeClientId])

  const { data: expertises, isLoading: loadingExpertises } = useCollection(expertisesQuery)

  const totalRiskValue = React.useMemo(() => {
    if (!expertises) return 0
    return expertises.reduce((acc, curr) => acc + (Number(curr.value) || 0), 0)
  }, [expertises])

  const potentialSavings = (payroll * 0.02 * (1 - fapValue[0])).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })

  return (
    <div className="space-y-6 animate-in slide-in-from-right-4 duration-500 pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 text-left">
        <div>
          <h1 className="text-3xl font-headline font-bold text-primary tracking-tight uppercase">ROI Jurídico & Estratégico</h1>
          <p className="text-muted-foreground font-medium uppercase text-[10px] tracking-widest mt-1 flex items-center gap-2">
            <Landmark className="size-3 text-accent" /> {activeClientId === 'all' ? 'Rede Global Consolidada' : 'Unidade Técnica Ativa'}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge className="bg-[#090e24] text-[#f59e0b] font-black uppercase text-[10px] tracking-widest px-4 h-10 flex items-center border border-[#f59e0b]/20 shadow-lg">
            Risco em Monitoramento: {totalRiskValue.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
          </Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="card-shadow border-none rounded-[2.5rem] bg-white overflow-hidden">
          <CardHeader className="bg-primary text-white p-8">
            <div className="flex items-center gap-2">
              <Calculator className="size-5 text-accent" />
              <CardTitle className="text-lg uppercase font-headline">Calculadora FAP</CardTitle>
            </div>
            <CardDescription className="text-white/60">Simule reduções tributárias via Gestão NAI.</CardDescription>
          </CardHeader>
          <CardContent className="p-8 space-y-8 text-left">
            <div className="space-y-4">
              <div className="flex justify-between">
                <label className="text-[10px] font-black uppercase text-slate-400">Folha Mensal Estimada</label>
                <span className="text-sm font-bold text-primary">R$ {payroll.toLocaleString('pt-BR')}</span>
              </div>
              <Input 
                type="number" 
                value={payroll} 
                onChange={(e) => setPayroll(Number(e.target.value))}
                className="h-12 bg-slate-50 border-none rounded-xl font-bold shadow-inner"
              />
            </div>

            <div className="space-y-4">
              <div className="flex justify-between">
                <label className="text-[10px] font-black uppercase text-slate-400">Fator FAP Alvo</label>
                <span className="text-sm font-bold text-accent">{fapValue[0].toFixed(2)}</span>
              </div>
              <Slider 
                value={fapValue} 
                onValueChange={setFapValue} 
                max={2} 
                min={0.5} 
                step={0.01} 
              />
            </div>

            <div className="p-6 bg-primary/5 rounded-[2rem] border-2 border-primary/10 flex flex-col items-center gap-2 shadow-inner">
              <p className="text-[9px] text-muted-foreground font-black uppercase tracking-widest">Economia Anual Estimada</p>
              <h2 className="text-4xl font-headline font-black text-primary">{potentialSavings}</h2>
            </div>
          </CardContent>
        </Card>

        <Card className="card-shadow border-none bg-white rounded-[2.5rem] overflow-hidden flex flex-col">
          <CardHeader className="bg-slate-50 border-b p-8">
            <div className="flex items-center gap-2">
              <Scale className="size-5 text-primary" />
              <CardTitle className="text-lg font-black uppercase text-primary">Controle de Perícias (Real)</CardTitle>
            </div>
            <CardDescription className="text-[10px] font-bold uppercase tracking-widest">Monitoramento real-time de processos multi-tenant.</CardDescription>
          </CardHeader>
          <CardContent className="p-0 flex-1 overflow-y-auto max-h-[600px] scrollbar-thin">
            {loadingExpertises ? (
              <div className="flex flex-col items-center py-20 gap-2 opacity-20">
                <Loader2 className="size-10 animate-spin text-primary" />
                <p className="text-[10px] font-black uppercase tracking-widest">Sincronizando Base Jurídica...</p>
              </div>
            ) : expertises && expertises.length > 0 ? (
              <div className="divide-y">
                {expertises.map((item) => (
                  <div key={item.id} className="p-6 hover:bg-slate-50 transition-colors group text-left">
                    <div className="flex justify-between items-start mb-4">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-primary/5 text-primary rounded-xl group-hover:bg-primary group-hover:text-white transition-all shadow-inner">
                          <Gavel className="size-4" />
                        </div>
                        <div>
                          <p className="text-[9px] font-black uppercase text-slate-400">Processo {item.caseNumber}</p>
                          <p className="text-sm font-black text-primary uppercase">{item.employeeName}</p>
                        </div>
                      </div>
                      <Badge className={cn("text-[8px] font-black uppercase", item.status === 'Concluído' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700')}>
                        {item.status}
                      </Badge>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                        <p className="text-[8px] font-black text-slate-400 uppercase mb-1">Alegado</p>
                        <p className="text-[10px] font-bold text-primary truncate italic">"{item.disease}"</p>
                      </div>
                      <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                        <p className="text-[8px] font-black text-slate-400 uppercase mb-1">Custo Estimado</p>
                        <p className="text-[11px] font-black text-red-600">{(Number(item.value) || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="py-32 text-center opacity-30 flex flex-col items-center gap-4">
                 <Landmark size={48} />
                 <p className="text-[10px] font-black uppercase tracking-[0.3em]">Aguardando Registros Reais</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
