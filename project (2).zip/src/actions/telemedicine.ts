
'use server';

/**
 * @fileOverview Server Action para integração com Google Meet API e Sincronização de Calendários.
 * Garante que o evento apareça na agenda real do paciente e do médico.
 */

import { google } from 'googleapis';
import { ActionResult } from '@/types/schema';

interface MeetBookingData {
  pacienteEmail: string;
  medicoEmail: string;
  dataHoraInicio: string;
  dataHoraFim: string;
  tituloConsulta?: string;
}

export async function gerarLinkMeet(data: MeetBookingData): Promise<ActionResult> {
  const { pacienteEmail, medicoEmail, dataHoraInicio, dataHoraFim, tituloConsulta } = data;

  try {
    let auth;
    let isMockMode = false;

    const dateInicio = new Date(dataHoraInicio);
    const dateFim = new Date(dataHoraFim);

    if (isNaN(dateInicio.getTime()) || isNaN(dateFim.getTime())) {
      throw new Error("Data/Hora inválida para agendamento.");
    }

    const serviceAccountJson = process.env.GOOGLE_SERVICE_ACCOUNT_JSON;

    if (serviceAccountJson && serviceAccountJson.trim() !== "") {
      try {
        const credentials = JSON.parse(serviceAccountJson);
        auth = new google.auth.GoogleAuth({
          credentials,
          scopes: [
            "https://www.googleapis.com/auth/calendar.events",
            "https://www.googleapis.com/auth/calendar"
          ],
        });
      } catch (parseError) {
        console.warn("NAI Telemedicine: Erro nas credenciais HIPAA.");
        isMockMode = true;
      }
    } else {
      console.warn("NAI Telemedicine: GOOGLE_SERVICE_ACCOUNT_JSON ausente. Ativando Mock Mode.");
      isMockMode = true;
    }

    let linkDoMeet = "";

    if (auth && !isMockMode) {
      try {
        const calendar = google.calendar({ version: "v3", auth });
        const event = {
          summary: tituloConsulta || "Videoconsulta Nextcon",
          description: `Consulta agendada via NAI Health. 
          Link de acesso: https://meet.google.com/
          Protocolo de segurança e-Social S-2220 ativado.`,
          start: { dateTime: dateInicio.toISOString(), timeZone: 'America/Sao_Paulo' },
          end: { dateTime: dateFim.toISOString(), timeZone: 'America/Sao_Paulo' },
          attendees: [
            { email: medicoEmail, responseStatus: 'accepted' }, 
            { email: pacienteEmail }
          ],
          conferenceData: {
            createRequest: {
              requestId: `nai-meet-${Date.now()}`,
              conferenceSolutionKey: { type: "hangoutsMeet" },
            },
          },
          reminders: {
            useDefault: false,
            overrides: [
              { method: 'email', minutes: 24 * 60 },
              { method: 'popup', minutes: 15 },
            ],
          },
          status: 'confirmed'
        };

        const responseGoogle = await calendar.events.insert({
          calendarId: "primary",
          conferenceDataVersion: 1,
          sendUpdates: 'all', // CRÍTICO: Dispara o convite real para o Gmail do paciente
          requestBody: event,
        });

        linkDoMeet = responseGoogle.data.hangoutLink || "";
      } catch (apiError: any) {
        console.error("NAI Telemedicine API Error:", apiError.message);
        isMockMode = true;
      }
    }

    if (isMockMode || !linkDoMeet) {
      linkDoMeet = `https://meet.google.com/nai-hp-${Math.random().toString(36).substring(2, 5)}-${Math.random().toString(36).substring(2, 5)}`;
    }

    return {
      sucesso: true,
      link_meet: linkDoMeet,
      simulado: isMockMode
    };

  } catch (error: any) {
    const errorMessage = error instanceof Error ? error.message : "Erro desconhecido";
    console.error("Falha Crítica Telemedicina:", errorMessage);
    return {
      sucesso: false,
      mensagem: errorMessage || "Erro interno ao gerar link de consulta."
    };
  }
}
