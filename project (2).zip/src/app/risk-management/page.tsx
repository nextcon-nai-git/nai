"use client"

import * as React from "react"
import {
  ShieldAlert, ShieldCheck, Activity, Brain, Sparkles, FileUp,
  AlertTriangle, CheckCircle2, XCircle, TrendingDown, Zap, Eye,
  Wand2, Loader2, Building2, RefreshCw
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger, 
  DialogFooter 
} from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import { useUser, useMemoFirebase, useFirestore, useDoc, useCollection } from "@/firebase"
import { doc, collection, query, orderBy, collectionGroup, where } from "firebase/firestore"
import { cn } from "@/lib/utils"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { getRiskScore, getRiskLevel, getCategoryColor, KPI_DATA } from "./risk-data"
import { architectPgrData } from "@/ai/flows/pgr-data-architect-flow"
import { useSgi } from "@/contexts/sgi-context"
import Link from "next/link"

/**
 * @fileOverview Inventário de Riscos Ocupacionais (PGR).
 * Filtra dados estritamente pela unidade ativa selecionada no SGI.
 */

export default function RiskInventoryPGR() {
  const { user } = useUser()
  const db = useFirestore()
  const { toast } = useToast()
  const { activeClientId } = useSgi()
  
  const [selectedRisk, setSelectedRisk] = React.useState<string | null>(null)
  
  // AI Architect State
  const [isArchitectOpen, setIsArchitectOpen] = React.useState(false)
  const [architectInput, setArchitectInput] = React.useState("")
  const [isArchitecting, setIsArchitecting] = React.useState(false)
  const [architectResult, setArchitectResult] = React.useState<any>(null)

  const profileRef = useMemoFirebase(() => {
    if (!db || !user) return null
    return doc(db, "users", user.uid)
  }, [db, user])
  const { data: profile } = useDoc(profileRef)

  // Query reativa blindada pelo contexto SGI
  const risksQuery = useMemoFirebase(() => {
    if (!db || activeClientId === "unauthorized") return null;
    
    // Se for visão global, usa collectionGroup, mas as regras de segurança já barram se não for admin
    if (activeClientId === "all") {
      return query(collectionGroup(db, "pgr_risks"), orderBy("hazard", "asc"));
    }
    
    // Consulta direta na subcoleção da empresa selecionada (Alta Performance)
    return query(collection(db, "companies", activeClientId, "pgr_risks"), orderBy("hazard", "asc"));
  }, [db, activeClientId]);

  const { data: risks, isLoading: loadingRisks } = useCollection(risksQuery)

  const activeCompanyRef = useMemoFirebase(() => 
    !db || activeClientId === "all" || activeClientId === "unauthorized" ? null : doc(db, "companies", activeClientId),
    [db, activeClientId]
  )
  const { data: activeCompany } = useDoc(activeCompanyRef)

  const handleArchitect = async () => {
    if (!architectInput.trim()) return
    setIsArchitecting(true)
    try {
      const res = await architectPgrData({ rawInput: architectInput })
      setArchitectResult(res)
      toast({ title: "Registro Estruturado", description: "A NAI mapeou a matriz de risco e plano de ação." })
    } catch (e) {
      toast({ variant: "destructive", title: "Erro na IA Architect" })
    } finally {
      setIsArchitecting(false)
    }
  }

  return (
    <div className="space-y-8 pb-20 animate-in fade-in duration-500 max-w-[1600px] mx-auto">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6 border-b pb-8">
        <div className="space-y-4 text-left">
          <div className="flex items-center gap-3 mb-1">
            <div className="p-2.5 bg-primary text-white rounded-xl shadow-xl shadow-primary/20"><ShieldAlert size={20} /></div>
            <h1 className="text-3xl font-black tracking-tight text-slate-900 uppercase font-headline leading-none">
              Inventário de Riscos
            </h1>
          </div>
          
          <div className="flex flex-col sm:flex-row items-center gap-4">
            <Badge variant="outline" className="bg-slate-50 border-primary/10 text-primary font-black uppercase text-[9px] h-9 px-4 rounded-xl flex items-center gap-2 shadow-sm">
              <Building2 className="size-3.5" />
              {activeClientId === 'all' ? "Rede Global Consolidada" : (activeCompany?.name || "Carregando Unidade...")}
            </Badge>

            {activeCompany?.risk_degree && (
              <Badge className="bg-red-100 text-red-700 border-none font-black uppercase text-[8px] h-6 px-3">
                Grau de Risco {activeCompany.risk_degree}
              </Badge>
            )}
          </div>
        </div>
        
        <div className="flex flex-wrap gap-3 mt-auto">
          <Dialog open={isArchitectOpen} onOpenChange={setIsArchitectOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" className="rounded-2xl gap-2 font-black text-[10px] uppercase tracking-widest border-primary text-primary h-12 px-6 hover:bg-primary hover:text-white transition-all">
                <Wand2 className="size-4 text-accent" /> NAI Risk Architect
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[650px] rounded-[2.5rem] border-none shadow-2xl p-0 overflow-hidden bg-white text-left">
              <DialogHeader className="p-8 bg-primary text-white relative">
                <div className="absolute top-0 right-0 p-8 opacity-10"><Brain className="size-32 text-accent" /></div>
                <div className="relative z-10 space-y-1">
                  <DialogTitle className="text-2xl font-black uppercase tracking-tight font-headline">Risk Architect 2026</DialogTitle>
                  <DialogDescription className="text-white/60 font-medium italic">Transforme anotações de campo em registros estruturados NR-01.</DialogDescription>
                </div>
              </DialogHeader>
              <div className="p-8 space-y-6">
                {!architectResult ? (
                  <div className="space-y-4">
                    <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest ml-1">Descreva o perigo observado:</label>
                    <Textarea 
                      placeholder="Ex: No setor de manutenção, o operador usa uma esmerilhadeira antiga sem coifa. Faz muito barulho..."
                      className="min-h-[150px] bg-slate-50 border-none rounded-2xl p-4 text-xs font-medium shadow-inner"
                      value={architectInput}
                      onChange={e => setArchitectInput(e.target.value)}
                    />
                    <Button onClick={handleArchitect} disabled={isArchitecting || !architectInput} className="w-full h-14 bg-primary text-white font-black uppercase text-xs rounded-2xl shadow-xl gap-3">
                      {isArchitecting ? <Loader2 className="size-5 animate-spin" /> : <Sparkles className="size-5 text-accent" />}
                      Estruturar via NAI
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-6 animate-in zoom-in-95 text-left">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-4 bg-slate-50 rounded-2xl border">
                        <span className="text-[8px] font-black uppercase text-slate-400">Risco Identificado</span>
                        <p className="text-sm font-bold text-primary uppercase">{architectResult.inventario.risco_associado}</p>
                      </div>
                      <div className="p-4 bg-slate-50 rounded-2xl border">
                        <span className="text-[8px] font-black uppercase text-slate-400">Nível Final</span>
                        <p className="text-sm font-black text-red-600 uppercase">{architectResult.inventario.avaliacao.nivel_final} - {architectResult.inventario.avaliacao.prioridade}</p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" className="flex-1 rounded-xl font-bold uppercase text-[10px]" onClick={() => setArchitectResult(null)}>Novo Scan</Button>
                      <Button className="flex-1 bg-primary text-white rounded-xl font-black uppercase text-[10px] shadow-lg">Salvar no Inventário</Button>
                    </div>
                  </div>
                )}
              </div>
            </DialogContent>
          </Dialog>

          <Button variant="outline" asChild className="rounded-2xl gap-2 font-black text-[10px] uppercase tracking-widest bg-white h-12 px-6 shadow-sm border-slate-200 text-primary">
            <Link href="/risk-management/pgr-analysis">
              <FileUp className="size-4" /> Importar PGR
            </Link>
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard icon={ShieldAlert} label="Riscos Mapeados" value={risks?.length || 0} color="bg-blue-600" delay={100} />
        <KpiCard icon={ShieldCheck} label="Conformidade S-2240" value={`${KPI_DATA.complianceRate}%`} color="bg-emerald-600" delay={200} />
        <KpiCard icon={TrendingDown} label="Saving RAT Estimado" value="R$ 42.8k" color="bg-accent" delay={300} />
        <KpiCard icon={XCircle} label="Nível Crítico" value={risks?.filter((r: any) => getRiskScore(r.probability, r.severity) >= 15).length || 0} color="bg-rose-600" delay={400} />
      </div>

      <Card className="border-none bg-white rounded-[2.5rem] overflow-hidden shadow-md">
        <CardHeader className="bg-slate-50/70 border-b py-6 px-8 flex flex-row items-center justify-between gap-4 flex-wrap">
          <div className="text-left">
            <CardTitle className="text-base font-black text-slate-900 uppercase tracking-tight">Vigilância Ativa (SGI Firestore)</CardTitle>
            <CardDescription className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mt-1">
              {risks?.length || 0} perigos identificados sob o contexto desta unidade.
            </CardDescription>
          </div>
        </CardHeader>
        <CardContent className="p-0 overflow-x-auto">
          {loadingRisks ? (
            <div className="py-24 flex flex-col items-center justify-center gap-4 text-primary">
              <Loader2 className="size-12 animate-spin opacity-20" />
              <p className="text-[10px] font-black uppercase tracking-widest">Sincronizando Base de Engenharia...</p>
            </div>
          ) : (
            <Table>
              <TableHeader className="bg-slate-50/40 text-[9px] uppercase font-black tracking-wider">
                <TableRow>
                  <TableHead className="pl-8 w-[280px]">Perigo / Agente</TableHead>
                  <TableHead>Setor / GHE</TableHead>
                  <TableHead className="text-center">Matriz P×S</TableHead>
                  <TableHead className="text-center">Status</TableHead>
                  <TableHead className="pr-8 text-right">Controle Principal</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {risks?.map((risk: any) => {
                  const score = getRiskScore(risk.probability, risk.severity)
                  const level = getRiskLevel(score)
                  const cat = getCategoryColor(risk.category)
                  const isSelected = selectedRisk === risk.id
                  return (
                    <TableRow
                      key={risk.id}
                      className={cn(
                        "hover:bg-slate-50/80 transition-colors cursor-pointer border-b last:border-0",
                        isSelected && "bg-slate-50"
                      )}
                      onClick={() => setSelectedRisk(isSelected ? null : risk.id)}
                    >
                      <TableCell className="pl-8 py-4">
                        <div className="flex items-center gap-3">
                          <span className="text-xl shrink-0 p-1 bg-slate-100 rounded-xl">{cat.icon}</span>
                          <div className="text-left">
                            <p className="font-black text-xs text-slate-900 uppercase tracking-tight">{risk.hazard}</p>
                            <Badge variant="outline" className={cn("text-[7px] font-black uppercase border-none px-2 h-4 mt-1 rounded-sm shadow-inner", cat.bg, cat.text)}>
                              {risk.category}
                            </Badge>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell><p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider text-left">{risk.ghe}</p></TableCell>
                      <TableCell className="text-center">
                        <Badge className={cn("text-[9px] font-black border-none px-2.5 h-5 rounded-full shadow-sm", level.color, level.text)}>
                          {score} · {level.label}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-center">
                        <Badge variant="outline" className={cn("text-[8px] font-black uppercase border-none px-2.5 h-5 inline-flex items-center rounded-full",
                          risk.status === 'controlado' ? 'bg-emerald-50 text-emerald-600' :
                          risk.status === 'atenção' ? 'bg-amber-50 text-amber-600' : 'bg-rose-50 text-rose-600'
                        )}>
                          {risk.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="pr-8 text-right">
                        <p className="text-[10px] font-bold text-slate-400 italic max-w-[180px] ml-auto truncate">"{risk.control}"</p>
                      </TableCell>
                    </TableRow>
                  )
                })}
                {(!risks || risks.length === 0) && (
                  <TableRow><TableCell colSpan={5} className="py-24 text-center opacity-30 font-black uppercase text-xs tracking-widest">Aguardando Importação de PGR</TableCell></TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

function KpiCard({ icon: Icon, label, value, color, delay }: any) {
  return (
    <Card className="border-none bg-white rounded-[2rem] overflow-hidden shadow-md" style={{ animationDelay: `${delay}ms` }}>
      <CardContent className="p-6 flex items-center gap-4">
        <div className={cn("p-3 rounded-2xl shadow-lg text-white", color)}>
          <Icon className="size-5" />
        </div>
        <div className="text-left">
          <p className="text-[9px] font-black uppercase text-slate-400 tracking-widest">{label}</p>
          <h3 className="text-2xl font-black text-slate-900 tracking-tighter">{value}</h3>
        </div>
      </CardContent>
    </Card>
  )
}
