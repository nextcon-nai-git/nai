"use client";

import { firebaseConfig } from '@/firebase/config';
import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import { getAuth, Auth } from 'firebase/auth';
import { 
  Firestore, 
  getFirestore, 
  initializeFirestore, 
  persistentLocalCache, 
  persistentSingleTabManager 
} from 'firebase/firestore'
import { getStorage, FirebaseStorage } from 'firebase/storage';

/**
 * Interface para os serviços core inicializados.
 */
export interface FirebaseSdks {
  firebaseApp: FirebaseApp;
  auth: Auth;
  firestore: Firestore;
  storage: FirebaseStorage;
}

// Variável de cache para garantir inicialização única (Singleton)
let initializedSdks: FirebaseSdks | null = null;

/**
 * Inicializa os serviços do Firebase com Persistência Offline Resiliente.
 * Utiliza persistentSingleTabManager para evitar erros de asserção interna (Unexpected state)
 * comuns em ambientes de desenvolvimento e produção com múltiplas instâncias.
 */
export function initializeFirebase(): FirebaseSdks {
  // Retorna cache se já existir (Garante Singleton e evita re-inicialização)
  if (initializedSdks) {
    return initializedSdks;
  }

  // 1. Inicializa o App ou recupera o existente
  const firebaseApp = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();

  // 2. Inicialização Segura do Firestore
  let firestore: Firestore;
  const isServer = typeof window === 'undefined';

  if (isServer) {
    firestore = getFirestore(firebaseApp);
  } else {
    try {
      // Tenta inicializar com cache persistente. 
      // Usamos SingleTabManager por ser mais estável contra o erro "Unexpected state (ID: ca9)"
      firestore = initializeFirestore(firebaseApp, {
        localCache: persistentLocalCache({
          tabManager: persistentSingleTabManager()
        })
      });
    } catch (e: any) {
      // Se já houver uma instância inicializada ou erro de estado, recupera a instância ativa
      // Isso previne falhas críticas durante Hot Reload no Next.js
      firestore = getFirestore(firebaseApp);
    }
  }

  // 3. Consolida e exporta os SDKs
  initializedSdks = {
    firebaseApp,
    auth: getAuth(firebaseApp),
    firestore,
    storage: getStorage(firebaseApp, firebaseConfig.storageBucket)
  };

  return initializedSdks;
}

/**
 * Mantém compatibilidade com exportações existentes de SDKs brutos.
 */
export function getSdks(firebaseApp: FirebaseApp): FirebaseSdks {
  return initializeFirebase();
}
