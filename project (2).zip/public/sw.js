/**
 * NAI - Service Worker Minimalista para Caching de Assets.
 * Foco: Permitir o carregamento da shell do app em canteiros de obra sem rede.
 */

const CACHE_NAME = 'nai-v2-cache';
const ASSETS_TO_CACHE = [
  '/',
  '/login',
  '/globals.css',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(ASSETS_TO_CACHE);
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cache) => {
          if (cache !== CACHE_NAME) {
            return caches.delete(cache);
          }
        })
      );
    })
  );
});

self.addEventListener('fetch', (event) => {
  // Ignora requests de extensões ou externos não-essenciais
  if (!event.request.url.startsWith(self.location.origin)) return;

  event.respondWith(
    caches.match(event.request).then((response) => {
      return response || fetch(event.request).catch(() => {
        // Fallback para a raiz se for uma navegação de página
        if (event.request.mode === 'navigate') {
          return caches.match('/');
        }
      });
    })
  );
});
