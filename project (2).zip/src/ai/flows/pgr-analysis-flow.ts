'use server';
/**
 * @fileOverview NAI Master PGR Analyzer - Versão 2.7 SGI Core.
 * Realiza a auditoria técnica de documentos PGR e gera gatilhos para o Plano de Ação (Kanban).
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const PgrAnalysisInputSchema = z.object({
  pdfDataUri: z.string().describe("O arquivo PGR em formato PDF codificado em Base64 ou URL pública."),
  fileName: z.string().optional(),
});
export type PgrAnalysisInput = z.infer<typeof PgrAnalysisInputSchema>;

const PgrAnalysisOutputSchema = z.object({
  systemSync: z.object({
    companyName: z.string().describe("Razão Social identificada."),
    cnpj: z.string().describe("CNPJ formatado."),
    cnae: z.string().describe("Código CNAE (ex: 41.20-4)."),
    riskDegree: z.number().describe("Grau de Risco (1-4)."),
    address: z.string().describe("Endereço completo."),
    validity: z.string().describe("Vigência do documento."),
  }),
  // O segredo do SGI: Gatilhos para o Centro de Operação
  actionPlanTriggers: z.array(z.object({
    origin: z.string().default("PGR NR-01"),
    category: z.enum(['Engenharia', 'Medicina', 'Treinamento', 'Higiene']),
    title: z.string().describe("Título da tarefa para o Kanban"),
    reason: z.string().describe("Justificativa técnica da necessidade"),
    column: z.enum(['todo', 'doing', 'review']).describe("Coluna sugerida no Kanban"),
    priority: z.enum(['high', 'critical', 'medium']),
    legalRef: z.string().describe("Item da NR correspondente")
  })).describe("Ações técnicas a serem injetadas no Centro de Operação."),
  aiInsight: z.string().describe("Parecer executivo estratégico focado em ROI."),
});

export type PgrAnalysisOutput = z.infer<typeof PgrAnalysisOutputSchema>;

export async function analyzePgrPdf(input: PgrAnalysisInput): Promise<PgrAnalysisOutput> {
  const {output} = await prompt(input);
  if (!output) throw new Error('A NAI falhou ao estruturar a análise técnica.');
  return output;
}

const prompt = ai.definePrompt({
  name: 'pgrTechnicalAnalysisPrompt',
  input: {schema: PgrAnalysisInputSchema},
  output: {schema: PgrAnalysisOutputSchema},
  prompt: `Você é a NAI, Inteligência sênior de Engenharia da Nextcon.
Analise o PGR em anexo e extraia:
1. Dados para o sistema (CNPJ, CNAE, Risco).
2. Um plano de ação estruturado para o SGI (actionPlanTriggers).
3. Identifique o que é urgente para a Engenharia (coluna 'doing') e o que é planejamento de Medicina (coluna 'todo').
4. Um parecer focado em ROI e blindagem jurídica.

REGRAS SGI:
- Se houver riscos críticos sem controle, gere um gatilho para 'doing' (Engenharia).
- Se houver necessidade de exames, gere um gatilho para 'todo' (Medicina).

Documento: {{media url=pdfDataUri contentType="application/pdf"}}`,
});

ai.defineFlow(
  {
    name: 'pgrAnalysisFlow',
    inputSchema: PgrAnalysisInputSchema,
    outputSchema: PgrAnalysisOutputSchema,
  },
  async input => {
    return analyzePgrPdf(input);
  }
);
