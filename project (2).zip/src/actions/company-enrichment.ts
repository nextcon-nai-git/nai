'use server';

/**
 * @fileOverview NAI Enrichment Engine - Processamento de CNPJ e enquadramento de NRs.
 * Versão 2.0: Captura de endereço completo para geoprocessamento.
 */

import { ActionResult } from '@/types/schema';

interface CompanyEnrichmentData {
  razaoSocial: string;
  cnae: string;
  cnaeDescricao: string;
  grauDeRisco: number;
  exigeSesmt: boolean;
  exigeCipa: boolean;
  isIsentoDir: boolean;
  // Endereço Completo
  logradouro: string;
  numero: string;
  bairro: string;
  municipio: string;
  uf: string;
  cep: string;
}

/**
 * Busca dados na BrasilAPI e aplica a lógica de enquadramento das NRs.
 */
export async function enriquecerDadosEmpresa(cnpj: string, totalVidas: number): Promise<ActionResult<CompanyEnrichmentData>> {
  try {
    const cleanCnpj = cnpj.replace(/\D/g, '');
    
    // 1. Chamada para BrasilAPI (CNPJ v1)
    const response = await fetch(`https://brasilapi.com.br/api/cnpj/v1/${cleanCnpj}`);
    
    if (!response.ok) {
      throw new Error("CNPJ não localizado na base da Receita Federal.");
    }

    const data = await response.json();
    const cnaePrincipal = data.cnae_fiscal;
    
    // 2. Lógica de Grau de Risco (Simulação de Tabela NR-04 Quadro I)
    let grauDeRisco = 3; 
    if (['412', '421', '432', '439'].some(p => cnaePrincipal.startsWith(p))) grauDeRisco = 4; // Construção Civil
    if (['46', '47'].some(p => cnaePrincipal.startsWith(p))) grauDeRisco = 2; // Comércio
    if (['62', '63'].some(p => cnaePrincipal.startsWith(p))) grauDeRisco = 1; // Tecnologia/Admin

    // 3. Lógica SESMT (NR-04) & CIPA (NR-05)
    const exigeCipa = (grauDeRisco >= 3 && totalVidas >= 20) || (grauDeRisco < 3 && totalVidas >= 51);
    const exigeSesmt = (grauDeRisco === 4 && totalVidas >= 50) || (grauDeRisco === 3 && totalVidas >= 100);

    // 4. Gatilho de Isenção DIR (NR-01)
    const isIsentoDir = (grauDeRisco <= 2 && totalVidas <= 50);

    return {
      sucesso: true,
      dados: {
        razaoSocial: data.razao_social,
        cnae: cnaePrincipal,
        cnaeDescricao: data.cnae_fiscal_descricao,
        grauDeRisco,
        exigeCipa,
        exigeSesmt,
        isIsentoDir,
        logradouro: data.logradouro,
        numero: data.numero,
        bairro: data.bairro,
        municipio: data.municipio,
        uf: data.uf,
        cep: data.cep
      }
    };

  } catch (error: any) {
    console.error("Erro no Enriquecimento NAI:", error.message);
    return {
      sucesso: false,
      mensagem: "A NAI não conseguiu capturar os dados via Receita Federal."
    };
  }
}
