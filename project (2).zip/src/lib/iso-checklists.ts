/**
 * NEXTCON PLATFORM - CÉREBRO DE AUDITORIA ISO PROFISSIONAL 2026
 * Definição exaustiva de requisitos baseada nas cláusulas 4 a 10 das normas ISO.
 * Versão Expandida v3.0 - Full Compliance
 */

export interface IsoChecklistItem {
  id: string;
  clause: string;
  requirement: string;
  helpText: string;
}

export interface IsoChecklist {
  id: string;
  title: string;
  items: IsoChecklistItem[];
}

export const ISO_CHECKLISTS: Record<string, IsoChecklist> = {
  "ISO 9001:2015": {
    id: "iso9001",
    title: "Sistema de Gestão da Qualidade (SGQ)",
    items: [
      { id: "9001-4.1", clause: "Contexto", requirement: "A organização determinou questões externas e internas pertinentes ao seu propósito?", helpText: "Verificar análise SWOT ou PESTEL atualizada." },
      { id: "9001-4.2", clause: "Partes Interessadas", requirement: "Foram identificadas as necessidades e expectativas das partes interessadas?", helpText: "Auditar matriz de partes interessadas e requisitos legais." },
      { id: "9001-4.4.1", clause: "Processos", requirement: "Os processos necessários para o SGQ e suas interações foram estabelecidos?", helpText: "Verificar mapa de processos e entradas/saídas." },
      { id: "9001-5.1.1", clause: "Liderança", requirement: "A alta direção demonstra liderança e comprometimento com o SGQ?", helpText: "Verificar envolvimento em reuniões e eficácia do sistema." },
      { id: "9001-5.2.1", clause: "Política", requirement: "A política da qualidade é apropriada ao propósito e contexto da organização?", helpText: "Verificar se a política está disponível e comunicada." },
      { id: "9001-5.3", clause: "Papéis e Autoridades", requirement: "Responsabilidades e autoridades foram atribuídas e comunicadas?", helpText: "Verificar descrições de cargo e organograma." },
      { id: "9001-6.1.1", clause: "Riscos e Oportunidades", requirement: "A organização determinou riscos e oportunidades para assegurar resultados?", helpText: "Avaliar matriz de riscos do negócio e plano de mitigação." },
      { id: "9001-6.2.1", clause: "Objetivos da Qualidade", requirement: "Os objetivos da qualidade são mensuráveis e coerentes com a política?", helpText: "Verificar KPIs e metas estabelecidas por setor." },
      { id: "9001-6.3", clause: "Planejamento de Mudanças", requirement: "As mudanças no SGQ são realizadas de maneira planejada?", helpText: "Verificar registros de controle de mudanças recentes." },
      { id: "9001-7.1.5", clause: "Monitoramento e Medição", requirement: "Os recursos de medição são calibrados e rastreáveis a padrões nacionais/internacionais?", helpText: "Verificar certificados de calibração de balanças, paquímetros, etc." },
      { id: "9001-7.1.6", clause: "Conhecimento Organizacional", requirement: "A organização determinou o conhecimento necessário para a operação de seus processos?", helpText: "Verificar gestão de conhecimento e lições aprendidas." },
      { id: "9001-7.2", clause: "Competência", requirement: "As pessoas que realizam trabalho sob o controle da organização são competentes?", helpText: "Auditar matriz de competências e registros de treinamentos." },
      { id: "9001-7.3", clause: "Conscientização", requirement: "As pessoas estão cientes da política, objetivos e sua contribuição?", helpText: "Realizar entrevistas com colaboradores de diferentes níveis." },
      { id: "9001-7.5.3", clause: "Informação Documentada", requirement: "A informação documental é controlada quanto à disponibilidade, proteção e recuperação?", helpText: "Verificar lista mestra e controle de revisões." },
      { id: "9001-8.1", clause: "Operação", requirement: "Os processos necessários para prover produtos/serviços foram planejados e controlados?", helpText: "Verificar plano de controle de produção." },
      { id: "9001-8.2.3", clause: "Requisitos de Produtos", requirement: "A organização tem a capacidade de atender aos requisitos antes de se comprometer?", helpText: "Verificar análise crítica de pedidos e contratos." },
      { id: "9001-8.4.1", clause: "Provedores Externos", requirement: "A organização assegura que processos fornecidos externamente estão conformes?", helpText: "Auditar homologação e avaliação de fornecedores." },
      { id: "9001-8.5.1", clause: "Produção", requirement: "A produção ocorre sob condições controladas (instruções, equipamentos, monitoramento)?", helpText: "Verificar check-ins de produção e liberação de lotes." },
      { id: "9001-8.5.2", clause: "Identificação e Rastreabilidade", requirement: "A organização usa meios adequados para identificar saídas para assegurar conformidade?", helpText: "Verificar etiquetas de rastreabilidade e histórico de lotes." },
      { id: "9001-8.5.4", clause: "Preservação", requirement: "A organização preserva as saídas durante a produção e entrega?", helpText: "Verificar armazenamento, embalagem e transporte." },
      { id: "9001-8.7", clause: "Saídas Não Conformes", requirement: "Saídas não conforme são identificadas e controladas para prevenir seu uso não pretendido?", helpText: "Verificar área de segregação de produtos reprovados." },
      { id: "9001-9.1.2", clause: "Satisfação do Cliente", requirement: "A organização monitora a percepção dos clientes sobre o atendimento de suas necessidades?", helpText: "Analisar pesquisas de satisfação (NPS) e tratativa de reclamações." },
      { id: "9001-9.2", clause: "Auditoria Interna", requirement: "Auditorias internas são realizadas em intervalos planejados para prover info do SGQ?", helpText: "Verificar cronograma e relatórios de auditorias anteriores." },
      { id: "9001-9.3", clause: "Análise Crítica", requirement: "A alta direção analisa o SGQ para assegurar sua contínua adequação e eficácia?", helpText: "Verificar ata da última reunião de análise crítica da direção." },
      { id: "9001-10.2", clause: "Não Conformidade", requirement: "Ações corretivas são tomadas para eliminar causas de não conformidades?", helpText: "Auditar eficácia das RNCs fechadas nos últimos 12 meses." },
      { id: "9001-10.3", clause: "Melhoria Contínua", requirement: "A organização melhora continuamente a adequação, suficiência e eficácia do SGQ?", helpText: "Verificar evidências de Kaizen ou projetos de melhoria." }
    ]
  },
  "ISO 14001:2015": {
    id: "iso14001",
    title: "Sistema de Gestão Ambiental (SGA)",
    items: [
      { id: "14001-4.1", clause: "Contexto", requirement: "A organização determinou questões ambientais externas e internas pertinentes?", helpText: "Verificar SWOT ambiental." },
      { id: "14001-4.2", clause: "Partes Interessadas", requirement: "Necessidades das partes interessadas que se tornam requisitos legais foram identificadas?", helpText: "Verificar matriz LIRA." },
      { id: "14001-5.1", clause: "Liderança", requirement: "A alta direção demonstra comprometimento com o SGA e proteção ambiental?", helpText: "Avaliar recursos alocados para projetos ambientais." },
      { id: "14001-5.2", clause: "Política Ambiental", requirement: "A política inclui compromisso com a proteção do meio ambiente e prevenção da poluição?", helpText: "Verificar conformidade da política escrita." },
      { id: "14001-6.1.1", clause: "Ações para Riscos", requirement: "Riscos e oportunidades relacionados aos aspectos ambientais foram determinados?", helpText: "Verificar matriz de riscos ambientais." },
      { id: "14001-6.1.2", clause: "Aspectos Ambientais", requirement: "Aspectos ambientais foram determinados sob uma perspectiva de ciclo de vida?", helpText: "Auditar Matriz AIA (Aspectos e Impactos Ambientais)." },
      { id: "14001-6.1.3", clause: "Requisitos Legais", requirement: "A organização tem acesso aos requisitos legais e outros requisitos?", helpText: "Verificar licenças de operação e outorgas." },
      { id: "14001-6.2.1", clause: "Objetivos Ambiental", requirement: "Objetivos ambientais são estabelecidos e coerentes com a política?", helpText: "Verificar metas de redução de resíduos/energia." },
      { id: "14001-7.1", clause: "Recursos", requirement: "A organização determinou os recursos para o SGA?", helpText: "Avaliar orçamento e infraestrutura ambiental." },
      { id: "14001-7.2", clause: "Competência", requirement: "Colaboradores com tarefas de impacto ambiental significativo são competentes?", helpText: "Verificar treinamentos de operadores de caldeiras/ETE." },
      { id: "14001-7.4.2", clause: "Comunicação Interna", requirement: "O processo de comunicação ambiental interna é eficaz?", helpText: "Verificar canais de denúncia ambiental." },
      { id: "14001-7.5.3", clause: "Controle de Info", requirement: "A informação documentada é controlada adequadamente?", helpText: "Verificar guarda de manifestos de transporte de resíduos (MTR)." },
      { id: "14001-8.1.1", clause: "Controle Operacional", requirement: "Existem controles para os aspectos ambientais significativos?", helpText: "Verificar bacias de contenção, filtros e manutenção." },
      { id: "14001-8.1.2", clause: "Ciclo de Vida", requirement: "Controles ambientais foram aplicados no design, desenvolvimento e aquisição?", helpText: "Verificar compras sustentáveis." },
      { id: "14001-8.2", clause: "Emergência", requirement: "Processos para responder a situações de emergência ambiental foram estabelecidos?", helpText: "Verificar PAE e evidências de simulados de derramamento." },
      { id: "14001-9.1.1", clause: "Monitoramento", requirement: "Operações com impacto ambiental significativo são monitoradas?", helpText: "Verificar laudos de emissões atmosféricas e efluentes." },
      { id: "14001-9.1.2", clause: "Conformidade", requirement: "A conformidade com requisitos legais é avaliada periodicamente?", helpText: "Auditar relatórios de atendimento à LIRA." },
      { id: "14001-9.2.2", clause: "Auditoria Interna", requirement: "Auditorias internas de SGA são realizadas?", helpText: "Verificar registros de auditorias focadas em meio ambiente." },
      { id: "14001-9.3", clause: "Análise Crítica", requirement: "A alta direção analisa o SGA?", helpText: "Verificar ata de reunião focada em desempenho ambiental." },
      { id: "14001-10.2", clause: "Não Conformidade", requirement: "Ações corretivas para desvios ambientais são tomadas?", helpText: "Verificar eficácia das RNCs ambientais." }
    ]
  },
  "ISO 45001:2018": {
    id: "iso45001",
    title: "Saúde e Segurança Ocupacional (SSO)",
    items: [
      { id: "45001-4.1", clause: "Contexto", requirement: "A organização determinou questões de SSO pertinentes?", helpText: "Verificar análise de contexto focada em segurança." },
      { id: "45001-4.2", clause: "Trabalhadores e Partes", requirement: "As necessidades de trabalhadores e partes interessadas foram identificadas?", helpText: "Verificar expectativas sindicais e legais." },
      { id: "45001-5.1", clause: "Liderança e Participação", requirement: "A alta direção assume a responsabilidade pela prevenção de lesões e doenças?", helpText: "Avaliar cultura de segurança da liderança." },
      { id: "45001-5.2", clause: "Política de SSO", requirement: "A política inclui compromisso com a consulta e participação dos trabalhadores?", helpText: "Requisito fundamental da 45001." },
      { id: "45001-5.4", clause: "Consulta e Participação", requirement: "Existem processos eficazes para consulta e participação de trabalhadores não gerenciais?", helpText: "Auditar atas de CIPA e canais de sugestões." },
      { id: "45001-6.1.1", clause: "Ações para SSO", requirement: "Riscos e oportunidades para o sistema de SSO foram identificados?", helpText: "Verificar matriz de riscos do sistema." },
      { id: "45001-6.1.2.1", clause: "Identificação de Perigos", requirement: "Há um processo contínuo e proativo de identificação de perigos?", helpText: "Cruzar com o PGR (NR-01)." },
      { id: "45001-6.1.2.2", clause: "Avaliação de Riscos", requirement: "Riscos de SSO são avaliados sistematicamente?", helpText: "Verificar metodologia de matriz de risco." },
      { id: "45001-6.1.3", clause: "Requisitos Legais", requirement: "As NRs e outros requisitos legais de SSO são monitorados?", helpText: "Verificar conformidade com NRs 10, 12, 33, 35." },
      { id: "45001-6.2.1", clause: "Objetivos de SSO", requirement: "Objetivos são estabelecidos para manter e melhorar o sistema?", helpText: "Verificar taxa de frequência e gravidade (TF/TG)." },
      { id: "45001-7.1", clause: "Recursos", requirement: "Recursos para o sistema de SSO foram providos?", helpText: "Avaliar EPIs, EPCs e time SESMT." },
      { id: "45001-7.2", clause: "Competência", requirement: "Trabalhadores são competentes para identificar perigos?", helpText: "Verificar registros de integração e treinamentos de NRs." },
      { id: "45001-7.3", clause: "Conscientização", requirement: "Trabalhadores conhecem a capacidade de se afastar de perigo iminente?", helpText: "Entrevistar sobre o Direito de Recusa." },
      { id: "45001-7.4", clause: "Comunicação", requirement: "A comunicação interna e externa de SSO é eficaz?", helpText: "Verificar quadros de avisos, DDS e reportes." },
      { id: "45001-8.1.1", clause: "Operação de SSO", requirement: "Processos para atender aos requisitos de SSO foram estabelecidos?", helpText: "Verificar permissões de trabalho (PT) e APRs." },
      { id: "45001-8.1.2", clause: "Hierarquia de Controles", requirement: "Eliminação e substituição são priorizadas sobre o uso de EPI?", helpText: "Auditar eficácia do plano de ação do PGR." },
      { id: "45001-8.1.3", clause: "Gestão de Mudanças", requirement: "Impactos em SSO são avaliados antes de mudanças operacionais?", helpText: "Verificar registros de novas máquinas ou processos." },
      { id: "45001-8.1.4.1", clause: "Aquisição", requirement: "Os requisitos de SSO são considerados na compra de produtos e serviços?", helpText: "Verificar especificação de segurança em compras." },
      { id: "45001-8.1.4.2", clause: "Contratados", requirement: "Processos de SSO são coordenados com os contratados (terceiros)?", helpText: "Auditar integração de terceiros e ASOs de prestadores." },
      { id: "45001-8.2", clause: "Emergência", requirement: "Processos para responder a situações de emergência de SSO estão ativos?", helpText: "Verificar brigada, hidrantes, extintores e simulados." },
      { id: "45001-9.1.1", clause: "Monitoramento e Medição", requirement: "O desempenho de SSO e eficácia dos controles são monitorados?", helpText: "Verificar cronograma do PCMSO e avaliações ambientais." },
      { id: "45001-9.1.2", clause: "Avaliação de Conformidade", requirement: "A conformidade legal é avaliada?", helpText: "Auditar LIRA de segurança." },
      { id: "45001-9.2.2", clause: "Auditoria Interna", requirement: "Auditorias de SSO são realizadas periodicamente?", helpText: "Verificar relatórios de auditoria focados em segurança." },
      { id: "45001-9.3", clause: "Análise Crítica", requirement: "Alta direção analisa o sistema de SSO?", helpText: "Verificar ata com indicadores de acidentes e doenças." },
      { id: "45001-10.2", clause: "Incidentes", requirement: "Incidentes e não conformidades são investigados para determinar causas raízes?", helpText: "Verificar relatórios de CAT e investigação de quase-acidentes." },
      { id: "45001-10.3", clause: "Melhoria Contínua", requirement: "A organização melhora continuamente o desempenho de SSO?", helpText: "Avaliar redução de riscos críticos ao longo do tempo." }
    ]
  }
};

export const getGenericChecklist = (nr: string, title: string) => ({
  nr,
  title,
  items: [
    { 
      id: `${nr}-g1`, 
      category: "Documentação Geral",
      question: "A documentação técnica exigida por esta norma está disponível para fiscalização?", 
      legal_ref: "Geral",
      criticality: "low",
      help_text: "Verifique a organização de pastas físicas ou digitais."
    }
  ]
});
