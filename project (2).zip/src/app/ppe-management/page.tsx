"use client"

import * as React from "react"
import { 
  ShieldCheck, 
  UserCheck, 
  AlertTriangle, 
  History, 
  FileDown, 
  Plus, 
  Fingerprint, 
  Search,
  Loader2,
  Zap,
  Building2,
  CheckCircle2,
  Clock
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import { cn } from "@/lib/utils"
import Link from "next/link"

export default function PpeManagement() {
  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <h1 className="text-3xl font-headline font-black text-primary tracking-tight uppercase leading-none">Controle Digital de EPI/EPC</h1>
          <p className="text-muted-foreground font-medium uppercase text-[10px] tracking-widest flex items-center gap-2">
            <ShieldCheck className="size-3 text-emerald-500" /> Gestão de Fichas Eletrônicas e Validade de C.A.
          </p>
        </div>
        <div className="flex gap-2">
          <Button asChild variant="outline" className="h-11 px-6 border-primary text-primary font-black uppercase text-[10px] gap-2">
            <Link href="/ppe-kiosk"><Fingerprint className="size-4" /> Abrir Quiosque Entrega</Link>
          </Button>
          <Button className="gradient-nextcon text-white h-11 px-8 rounded-xl font-black uppercase text-[10px] tracking-widest shadow-lg gap-2">
            <Plus className="size-4 text-accent" /> Cadastrar Estoque
          </Button>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="card-shadow border-none bg-white rounded-3xl p-6 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="p-3 bg-red-50 rounded-xl w-fit text-red-600"><AlertTriangle className="size-6" /></div>
            <div>
              <p className="text-[10px] font-black uppercase text-slate-400">Certificados (C.A.) Vencendo</p>
              <h3 className="text-2xl font-black text-primary">04 Itens</h3>
            </div>
          </div>
          <Badge className="mt-4 bg-red-100 text-red-700 border-none text-[8px] font-black uppercase w-fit">Atenção Crítica</Badge>
        </Card>
        <Card className="card-shadow border-none bg-white rounded-3xl p-6 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="p-3 bg-blue-50 rounded-xl w-fit text-blue-600"><UserCheck className="size-6" /></div>
            <div>
              <p className="text-[10px] font-black uppercase text-slate-400">Entregas Biométricas (30d)</p>
              <h3 className="text-2xl font-black text-primary">142 Registros</h3>
            </div>
          </div>
          <Badge className="mt-4 bg-blue-50 text-blue-700 border-none text-[8px] font-black uppercase w-fit">Blindagem 100%</Badge>
        </Card>
        <Card className="card-shadow border-none bg-emerald-50 rounded-3xl p-6 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="p-3 bg-emerald-100 rounded-xl w-fit text-emerald-700"><CheckCircle2 className="size-6" /></div>
            <div>
              <p className="text-[10px] font-black uppercase text-emerald-800">Conformidade NR-06</p>
              <h3 className="text-2xl font-black text-emerald-900">Plena</h3>
            </div>
          </div>
          <Badge className="mt-4 bg-white text-emerald-700 border-none text-[8px] font-black uppercase w-fit">Auditoria OK</Badge>
        </Card>
      </div>

      <Card className="card-shadow border-none bg-white rounded-[2.5rem] overflow-hidden">
        <CardHeader className="bg-slate-50 border-b p-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <div>
            <CardTitle className="text-lg font-black text-primary uppercase">Histórico de Entregas</CardTitle>
            <CardDescription className="text-[10px] font-bold uppercase tracking-widest">Rastreabilidade total de insumos de proteção.</CardDescription>
          </div>
          <div className="relative w-full md:w-72">
            <Search className="absolute left-3 top-2.5 size-4 text-slate-300" />
            <Input placeholder="Buscar por colaborador ou EPI..." className="pl-10 h-10 border-none bg-white shadow-sm text-xs rounded-xl" />
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader className="bg-slate-50/50">
              <TableRow>
                <TableHead className="pl-8 text-[9px] font-black uppercase">Data / Hora</TableHead>
                <TableHead className="text-[9px] font-black uppercase">Colaborador</TableHead>
                <TableHead className="text-[9px] font-black uppercase">EPI / Marca</TableHead>
                <TableHead className="text-[9px] font-black uppercase text-center">C.A.</TableHead>
                <TableHead className="pr-8 text-right">Assinatura</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <TableRow className="hover:bg-slate-50">
                <TableCell className="pl-8 py-5">
                   <p className="text-xs font-bold text-primary">12/02/2026</p>
                   <p className="text-[9px] text-slate-400 font-bold uppercase">10:45 AM</p>
                </TableCell>
                <TableCell>
                  <p className="font-black text-xs text-primary uppercase">ERICK HENRIQUE</p>
                  <p className="text-[8px] text-slate-400 font-bold uppercase">SETOR OPERACIONAL</p>
                </TableCell>
                <TableCell>
                  <p className="text-xs font-bold text-slate-600">CAPACETE ABA FRONTAL</p>
                  <p className="text-[9px] text-slate-400 font-bold uppercase">MARCA: MSA - CLASSE B</p>
                </TableCell>
                <TableCell className="text-center">
                  <Badge variant="outline" className="font-mono text-primary border-primary/10">45678</Badge>
                </TableCell>
                <TableCell className="pr-8 text-right">
                  <Badge className="bg-emerald-100 text-emerald-700 border-none text-[8px] font-black uppercase gap-1.5 px-2">
                    <Zap className="size-2.5" /> Biometria Facial
                  </Badge>
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
