
"use client"

import * as React from "react"
import { 
  FileWarning, 
  Plus, 
  Search, 
  Loader2, 
  Zap, 
  Brain, 
  ArrowRight, 
  ShieldAlert, 
  CheckCircle2,
  TrendingUp,
  AlertTriangle,
  GitBranch,
  XCircle,
  FileText
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { useUser, useFirestore, useCollection, useMemoFirebase, useDoc } from "@/firebase"
import { collection, query, orderBy, collectionGroup, limit } from "firebase/firestore"
import { cn } from "@/lib/utils"
import { useSgi } from "@/contexts/sgi-context"

/**
 * @fileOverview Gestão de Acidentes (CAT) - Auditoria Firestore Real.
 */

export default function AccidentsCAT() {
  const { user } = useUser()
  const db = useFirestore()
  const { activeClientId } = useSgi()
  const [activeTab, setActiveTab] = React.useState("queue")

  const accidentsQuery = useMemoFirebase(() => {
    if (!db) return null
    const collRef = collection(db, "accidents")
    if (activeClientId === "all") {
      return query(collectionGroup(db, "accidents"), orderBy("date", "desc"), limit(50))
    }
    return query(collection(db, "companies", activeClientId, "accidents"), orderBy("date", "desc"))
  }, [db, activeClientId])

  const { data: accidents, isLoading } = useCollection(accidentsQuery)

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1 text-left">
          <h1 className="text-3xl font-headline font-black text-primary tracking-tight uppercase leading-none">Gestão de Acidentes (CAT)</h1>
          <p className="text-muted-foreground font-medium uppercase text-[10px] tracking-widest flex items-center gap-2">
            <FileWarning className="size-3 text-red-500" /> Transmissão eSocial S-2210 {activeClientId === 'all' ? 'Global' : 'Unidade'}.
          </p>
        </div>
        <div className="flex gap-2">
          <Dialog>
            <DialogTrigger asChild>
              <Button className="bg-red-600 hover:bg-red-700 text-white h-11 px-8 rounded-xl font-black uppercase text-[10px] tracking-widest shadow-lg shadow-red-600/20 gap-2">
                <Plus className="size-4" /> Abrir CAT Online
              </Button>
            </DialogTrigger>
            <DialogContent className="rounded-[2.5rem] border-none shadow-2xl p-0 overflow-hidden bg-white max-w-2xl">
              <DialogHeader className="p-8 bg-red-600 text-white">
                <DialogTitle className="text-xl font-black uppercase">Abertura de Evento S-2210</DialogTitle>
                <DialogDescription className="text-white/60 font-bold uppercase text-[10px] mt-1">Protocolo de comunicação obrigatória de acidente de trabalho.</DialogDescription>
              </DialogHeader>
              <div className="p-8">
                <p className="text-sm font-medium text-slate-400 italic">Formulário eSocial Ready em sincronização...</p>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="border-none shadow-sm bg-white rounded-3xl p-6 flex flex-col justify-between group hover:ring-2 ring-red-500/10 transition-all">
          <div className="space-y-4">
            <div className="p-3 bg-red-50 rounded-xl w-fit text-red-600"><Zap className="size-6" /></div>
            <div className="text-left">
              <p className="text-[10px] font-black uppercase text-slate-400">Pendentes eSocial</p>
              <h3 className="text-2xl font-black text-primary">{accidents?.filter(a => a.status === 'pending').length || 0} Eventos</h3>
            </div>
          </div>
          <Badge className="mt-4 bg-red-100 text-red-700 border-none text-[8px] font-black uppercase w-fit">Prazo 24h</Badge>
        </Card>
        <Card className="border-none shadow-sm bg-white rounded-3xl p-6 flex flex-col justify-between group hover:ring-2 ring-emerald-500/10 transition-all">
          <div className="space-y-4">
            <div className="p-3 bg-emerald-50 rounded-xl w-fit text-emerald-600"><CheckCircle2 className="size-6" /></div>
            <div className="text-left">
              <p className="text-[10px] font-black uppercase text-slate-400">SLA Transmissão</p>
              <h3 className="text-2xl font-black text-primary">100% OK</h3>
            </div>
          </div>
          <Badge className="mt-4 bg-emerald-100 text-emerald-700 border-none text-[8px] font-black uppercase w-fit">Conforme</Badge>
        </Card>
        <Card className="bg-[#090e24] text-white border-none rounded-3xl p-6 relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:scale-110 transition-transform"><TrendingUp className="size-20" /></div>
          <div className="space-y-4 relative z-10 text-left">
            <div className="p-3 bg-white/10 rounded-xl w-fit text-accent"><Brain className="size-6" /></div>
            <div>
              <p className="text-[10px] font-black uppercase text-white/40">Retroalimentação PGR</p>
              <h3 className="text-2xl font-black">NAI Ativa</h3>
            </div>
          </div>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full md:w-[800px] grid-cols-3 bg-muted/50 p-1.5 rounded-2xl h-16">
          <TabsTrigger value="queue" className="rounded-xl gap-2 text-[10px] font-black uppercase tracking-widest">Fila CAT S-2210</TabsTrigger>
          <TabsTrigger value="investigation" className="rounded-xl gap-2 text-[10px] font-black uppercase tracking-widest text-accent"><GitBranch className="size-4" /> Ishikawa 6M</TabsTrigger>
          <TabsTrigger value="stats" className="rounded-xl gap-2 text-[10px] font-black uppercase tracking-widest">Estatísticas</TabsTrigger>
        </TabsList>

        <TabsContent value="queue" className="mt-8">
          <Card className="card-shadow border-none bg-white rounded-[2.5rem] overflow-hidden">
            <CardHeader className="bg-slate-50 border-b py-6 px-8">
              <CardTitle className="text-lg font-black text-primary uppercase text-left">Eventos CAT em Aberto</CardTitle>
              <CardDescription className="text-[10px] font-bold uppercase tracking-widest text-left">Monitoramento de prazos legais eSocial.</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              {isLoading ? (
                <div className="py-24 flex flex-col items-center justify-center gap-4 text-primary">
                  <Loader2 className="size-12 animate-spin opacity-20" />
                  <p className="text-[10px] font-black uppercase tracking-widest">Sincronizando Sinistros...</p>
                </div>
              ) : (
                <Table>
                  <TableHeader className="bg-slate-50/50 text-[10px] uppercase font-black">
                    <TableRow>
                      <TableHead className="pl-8">Ocorrência</TableHead>
                      <TableHead>Colaborador</TableHead>
                      <TableHead>Status Investigação</TableHead>
                      <TableHead className="pr-8 text-right">Ação</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {accidents?.map((acc: any) => (
                      <TableRow key={acc.id} className="hover:bg-slate-50 transition-colors">
                        <TableCell className="pl-8 py-5 font-bold text-xs">{new Date(acc.date).toLocaleDateString('pt-BR')}</TableCell>
                        <TableCell><p className="font-black text-xs text-primary uppercase">{acc.employeeName}</p></TableCell>
                        <TableCell><Badge className="bg-amber-100 text-amber-700 border-none text-[8px] font-black uppercase">{acc.status}</Badge></TableCell>
                        <TableCell className="pr-8 text-right">
                          <Button variant="ghost" size="sm" className="text-primary font-black uppercase text-[10px]">Investigar</Button>
                        </TableCell>
                      </TableRow>
                    ))}
                    {(!accidents || accidents.length === 0) && (
                      <TableRow><TableCell colSpan={4} className="py-24 text-center opacity-30 font-black uppercase text-xs tracking-widest">Nenhum sinistro registrado no período</TableCell></TableRow>
                    )}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

