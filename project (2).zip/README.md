
# NAI - Nextcon AI | Inteligência 2026

Esta é a plataforma **Nextcon Intelligence**, um ecossistema Google-Native de alta performance para gestão estratégica de Saúde, Segurança do Trabalho (SST) e Auditoria Médica.

## 🚀 Infraestrutura Google de Elite
Acesse o portal oficial hospedado integralmente no Google Cloud: [https://nai--studio-8439299034-125c7.us-central1.hosted.app/](https://nai--studio-8439299034-125c7.us-central1.hosted.app/)

## 🧠 Motores de Inteligência NAI
A plataforma opera sob uma tríade de autoridade técnica:
1.  **Comercial**: Gerador de orçamentos e análise de viabilidade SST via IA.
2.  **Segurança do Trabalho**: Auditoria de PGR, GRO e conformidade com NRs (01 a 38).
3.  **Engenharia de Segurança**: Gestão de PCMSO, ASO Digital e Vigilância Epidemiológica Preditiva.

## 🛠️ Tecnologias e Motores Ativos
- **Core**: Next.js 15 (App Router), React 19, TypeScript.
- **AI Engine**: Genkit 1.x + Gemini 2.0 Flash (Streaming, Voice TTS, Vision).
- **Backend**: Firebase Firestore (Multi-tenant), Cloud Functions v2 (Node.js 22), Storage.
- **Security**: reCAPTCHA Enterprise, RBAC rigoroso, Firewall e-Social.

## 📈 Dados Reais Integrados (Benchmark 2026)
- **COCEL**: Gestão ativa de contrato aditivo (R$ 12.794,07 mensais).
- **Britânia**: Auditoria forense e consultoria de ergonomia (Joinville-SC).
- **Time Now**: Gestão de ordens de serviço e medições quantitativas de campo.

---
© 2026 Nextcon Saúde Empresarial • Inteligência NAI aplicada à salvaguarda de vidas.
