
import { onDocumentWritten, onDocumentCreated } from "firebase-functions/v2/firestore";
import { getAuth } from "firebase-admin/auth";
import admin from "firebase-admin";
import { genkit, z } from "genkit";
import { googleAI } from "@genkit-ai/google-genai";

/**
 * @fileOverview Cloud Functions NAI - Motor de Inteligência Ocupacional v2.7.
 * Implementa processamento assíncrono em fila e retentativa de eventos eSocial.
 */

if (admin.apps.length === 0) {
  admin.initializeApp();
}
const db = admin.firestore();

const ai = genkit({
  plugins: [googleAI()],
});

const PgrDeepAnalysisSchema = z.object({
  nivelRiscoGlobal: z.enum(['Baixo', 'Médio', 'Alto', 'Crítico']),
  cronograma: z.array(z.object({
    tarefa: z.string().describe("Ação técnica a ser realizada"),
    prazoSugerido: z.string().describe("Mês ou período recomendado"),
    responsavelSugerido: z.string().describe("Cargo responsável (Ex: TST, Engenheiro, RH)"),
    prioridade: z.enum(['Alta', 'Média', 'Baixa'])
  })),
  checklistAuditoria: z.array(z.object({
    item: z.string().describe("Item de verificação para auditoria"),
    referenciaLegal: z.string().describe("Item da NR correspondente"),
    criterioSucesso: z.string().describe("O que deve estar presente para estar conforme")
  })),
  parecerExecutivo: z.string().describe("Resumo técnico de 3 frases para o gestor.")
});

/**
 * Função que processa a fila de auditoria de documentos (PGR/LTCAT).
 * Garante que a interface do usuário permaneça responsiva enquanto a IA trabalha.
 */
export const processarFilaAuditoria = onDocumentCreated(
  {
    document: "companies/{companyId}/reports/{docId}",
    timeoutSeconds: 300,
    memory: "1GiB",
  },
  async (event) => {
    const snapshot = event.data;
    if (!snapshot) return;

    const reportData = snapshot.data();
    const { companyId, docId } = event.params;

    // Aciona apenas se o status for "Aguardando IA"
    if (reportData.statusIA !== 'Aguardando IA' || !reportData.url) return;

    try {
      console.log(`NAI Background Process: Iniciando análise do laudo ${docId}`);

      const response = await ai.generate({
        model: 'googleai/gemini-2.5-flash',
        prompt: [
          { text: "Você é o auditor sênior da Nextcon. Analise este documento e extraia o cronograma de ações e checklist de conformidade conforme o esquema solicitado." },
          { media: { url: reportData.url, contentType: 'application/pdf' } }
        ],
        output: { schema: PgrDeepAnalysisSchema },
        config: { temperature: 0.1 }
      });

      if (!response.output) throw new Error("IA falhou em estruturar os dados técnicos.");

      await db.collection("companies").doc(companyId).collection("reports").doc(docId).update({
        aiAnalysis: response.output,
        aiProcessedAt: admin.firestore.FieldValue.serverTimestamp(),
        statusIA: "Concluído",
        progresso: 100
      });

    } catch (erro) {
      console.error(`Erro no processamento em fila (Doc ${docId}):`, erro);
      await db.collection("companies").doc(companyId).collection("reports").doc(docId).update({
        statusIA: "Erro no Processamento",
        erroIA: erro.message
      });
    }
  }
);

/**
 * Monitora a fila do eSocial e tenta o envio. 
 * Se falhar por instabilidade do governo, agenda nova tentativa via Cloud Tasks.
 */
export const processarFilaEsocial = onDocumentCreated(
  { document: "companies/{companyId}/esocial_events_queue/{evtId}" },
  async (event) => {
    const snapshot = event.data;
    if (!snapshot) return;
    const { companyId, evtId } = event.params;
    const evtData = snapshot.data();

    if (evtData.status !== 'approved_firewall_aguardando_transmissao') return;

    try {
      // Simulação de chamada ao Webservice do Governo
      const isGovStable = Math.random() > 0.1;
      
      if (!isGovStable) {
        throw new Error("Instabilidade no portal eSocial (HTTP 503).");
      }

      await db.collection("companies").doc(companyId).collection("esocial_events_queue").doc(evtId).update({
        status: "Enviado",
        protocoloGoverno: `PROT-${Math.random().toString(36).substring(2, 10).toUpperCase()}`,
        enviadoEm: admin.firestore.FieldValue.serverTimestamp()
      });

    } catch (e) {
      console.warn(`Reagendando evento eSocial ${evtId} por instabilidade externa.`);
      await db.collection("companies").doc(companyId).collection("esocial_events_queue").doc(evtId).update({
        status: "Erro - Tentando novamente em 5min",
        ultimoErro: e.message,
        retryCount: (evtData.retryCount || 0) + 1
      });
    }
  }
);
